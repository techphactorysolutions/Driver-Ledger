# DriveLedger PWA

DriveLedger is a simple gig-driver earnings and mileage tracker for iPhone and iPad, built as a Progressive Web App so it needs no Mac, no Xcode, and no App Store.

## Why the app looks dead if you tap index.html in the Files app

Tapping an HTML file in the Files app opens a *preview* that does not run JavaScript. Nothing is wrong with the app — it just needs to be served like a website. Every method below works entirely from an iPhone or iPad.

## Option 1 — Netlify Drop (recommended, about 2 minutes, real HTTPS install)

1. On your iPad or iPhone, open Safari and go to: https://app.netlify.com/drop
2. Tap the upload area and choose **DriveLedger_upload_me.zip** from Files (that zip has the site files at its root, ready to publish).
3. Netlify publishes an HTTPS link. Open it, tap **Share → Add to Home Screen**.
4. Open **DriveLedger** from your Home Screen. Icon, full-screen mode, and offline caching all work.

Create a free Netlify account when prompted so the site stays up permanently. To update later: open the site in Netlify → Deploys → drop a new zip.

## Option 2 — GitHub Pages (free forever, a few more steps)

Works in Safari on iPad (turn on **Request Desktop Website** if the buttons are missing).

1. Create a free account at github.com, then a new **public** repository (any name, e.g. `driveledger`).
2. **Add file → Upload files** → select `index.html`, `styles.css`, `app.js`, `manifest.json`, `service-worker.js` from Files → Commit.
3. Icons need their folder: **Add file → Create new file**, name it `icons/notes.md`, type anything, Commit. Open the new `icons` folder → **Add file → Upload files** → select `icon-192.png` and `icon-512.png` → Commit.
4. **Settings → Pages** → Source: *Deploy from a branch* → Branch: `main`, folder `/ (root)` → Save.
5. After a minute, open `https://YOUR-USERNAME.github.io/driveledger/` → **Share → Add to Home Screen**.

## Option 3 — Run it locally on the device (no hosting at all)

- **WorldWideWeb** (free app by The Iconfactory): unzip the `DriveLedger_PWA` folder in Files (long-press the zip → Uncompress), open WorldWideWeb, choose that folder as the website folder, tap **Start Server**, then **Open in Safari**. The app runs at `http://localhost:8080` while the server is on.
- **a-Shell** (free terminal app): move the folder into a-Shell's Documents via Files, then run `cd DriveLedger_PWA` and `python3 -m http.server 8080`, and open `http://localhost:8080` in Safari.

Service workers and Add to Home Screen work on `localhost`, so this is a full test environment — but the app is only reachable while the server app is running, so use Option 1 or 2 for daily driving.

## About DriveLedger_Single_File.html

The single-file build has the styles and code inlined — handy for quickly hosting or sharing one file. It behaves identically, minus the home-screen icon and offline cache (those need the folder version's manifest, icons, and service worker).

## Things to know

- Your saved deliveries live in the browser's storage **for the exact web address you use**. If you move the app to a new address, export a CSV first — the new address starts empty.
- Screenshot OCR downloads the Tesseract library from the internet on first use. Manual entry always works, even offline once installed.
- Export CSV opens the iOS share sheet, so you can save to Files, AirDrop, Numbers, or email it.

## What was fixed in this version

- **Evening deliveries no longer disappear from Today.** Dates were computed in UTC, so in US time zones anything saved after roughly 5–8 PM was filed under *tomorrow* — exactly during dinner rush. Dates are now local.
- **"Scan Screenshot" on the Today tab now opens the photo picker on iOS.** The picker was triggered inside a `setTimeout`, which iOS Safari ignores; it now fires directly from your tap. Same fix for the keyboard on "Add Manually."
- **OCR mileage parsing:** "5.42 mi" used to be read as **42 miles**; "10 min" could be misread too. Fixed.
- **OCR earnings parsing:** "$1,234.56" used to be read as **$1.23**. Amounts with thousands separators are handled, and amounts written without a `$` (common in OCR) are caught when next to words like *total* or *payout*.
- **Export CSV now works in the installed app.** iOS home-screen web apps can't use normal downloads; export now uses the native share sheet, with a regular download as fallback in the browser.
- **Time Working / Avg per Hour freeze when you tap End Day** instead of drifting all night, and the Today screen resets itself at midnight and when you re-open the app.
- **Typing your goal in Settings no longer gets erased** by the once-a-minute background refresh, and that refresh no longer rebuilds the history list (which could jump your scroll position mid-scroll).
- **Service worker fixes:** it now also registers on `localhost` (so local testing works), only caches this app's own files, serves pages network-first so updates actually arrive, and the cache version was bumped so old cached copies are replaced.
- **iOS polish:** inputs are 16px so Safari doesn't zoom in on focus, selects have a proper chevron, the layout respects the notch and home-indicator safe areas in portrait and landscape, buttons don't trigger double-tap zoom, phone-number auto-linking is off (it was mangling numbers like mileage), delete buttons meet the 44pt touch size, and stats use three columns on iPad.
- Alerts were replaced with small in-app toasts; entering "18,75" now reads as 18.75.

## Files

- index.html — app markup
- styles.css — mobile UI
- app.js — storage, calculations, OCR parser, UI logic
- manifest.json — PWA install metadata
- service-worker.js — offline cache
- icons/ — app icons
