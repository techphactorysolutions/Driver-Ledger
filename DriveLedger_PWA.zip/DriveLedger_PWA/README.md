# DriveLedger PWA

DriveLedger is a simple gig-driver earnings and mileage tracker for iPhone and iPad. It is built as a Progressive Web App so it can be tested without a Mac or Xcode.

## What works now

- Today dashboard
- Daily earnings goal
- Manual delivery entry
- Screenshot selection from Photos
- Browser OCR using Tesseract.js
- Auto-fill company, earnings, and miles when detected
- DoorDash / Uber Eats / Grubhub / Catering / Instacart / Spark / Roadie categories
- Average per delivery
- Average per mile
- Average per hour
- “Average went up/down” trend after each delivery
- Company breakdown
- History list
- Delete entries
- Export CSV
- Local device storage
- PWA manifest and service worker

## Best way to test on iPad without a Mac

### Option A: Local Wi-Fi test from a Windows PC

1. Unzip this folder on your Windows PC.
2. Open Command Prompt inside the DriveLedger_PWA folder.
3. Run:

```bash
python -m http.server 8080
```

4. Find your PC's local IP address:

```bash
ipconfig
```

5. On your iPad, open Safari and go to:

```text
http://YOUR-PC-IP:8080
```

Example:

```text
http://192.168.1.25:8080
```

Manual entry and OCR should work if your iPad has internet access. Install-to-home-screen and offline service worker features are best tested over HTTPS.

### Option B: Proper iPad PWA test using HTTPS

Upload the folder contents to a static host like Netlify, Cloudflare Pages, GitHub Pages, Vercel, or your own website.

Then on iPad:

1. Open the HTTPS link in Safari.
2. Tap Share.
3. Tap Add to Home Screen.
4. Open DriveLedger from the Home Screen.

This gives the closest app-like experience without the App Store.

## Notes about screenshot scanning

The app uses OCR to read text from screenshots. Screenshot formats from DoorDash, Uber Eats, Grubhub, and catering apps can vary, so DriveLedger always fills the form first and expects the driver to confirm or correct the numbers before saving.

OCR requires the Tesseract.js library to load from CDN the first time. Manual entry works without OCR.

## Files

- index.html — app markup
- styles.css — modern mobile UI
- app.js — storage, calculations, OCR parser, UI logic
- manifest.json — PWA install metadata
- service-worker.js — offline cache when hosted over HTTPS
- icons/ — app icons
