(() => {
  const STORE_KEY = "driveledger.deliveries.v1";
  const SETTINGS_KEY = "driveledger.settings.v1";
  const SHIFT_KEY = "driveledger.shift.v1";

  const money = new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" });
  const $ = (id) => document.getElementById(id);

  const defaultSettings = {
    dailyGoal: 200,
    defaultCompany: "DoorDash"
  };

  let deliveries = readJSON(STORE_KEY, []);
  let settings = { ...defaultSettings, ...readJSON(SETTINGS_KEY, {}) };
  let shift = readJSON(SHIFT_KEY, { active: false, startedAt: null });
  let lastOCRText = "";

  const els = {
    todayEarned: $("todayEarned"),
    goalPercent: $("goalPercent"),
    goalBar: $("goalBar"),
    goalText: $("goalText"),
    goalRemaining: $("goalRemaining"),
    ordersCount: $("ordersCount"),
    milesToday: $("milesToday"),
    avgOrder: $("avgOrder"),
    avgMile: $("avgMile"),
    avgHour: $("avgHour"),
    timeWorking: $("timeWorking"),
    trendTitle: $("trendTitle"),
    trendDetail: $("trendDetail"),
    trendCard: document.querySelector(".trend-card"),
    companyBreakdown: $("companyBreakdown"),
    historyList: $("historyList"),
    goalInput: $("goalInput"),
    defaultCompanyInput: $("defaultCompanyInput"),
    companyInput: $("companyInput"),
    earningsInput: $("earningsInput"),
    milesInput: $("milesInput"),
    notesInput: $("notesInput"),
    screenshotInput: $("screenshotInput"),
    previewImage: $("previewImage"),
    scanStatus: $("scanStatus"),
    ocrDetails: $("ocrDetails"),
    ocrText: $("ocrText"),
    shiftBtn: $("shiftBtn")
  };

  function readJSON(key, fallback) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch {
      return fallback;
    }
  }

  function writeJSON(key, value) {
    localStorage.setItem(key, JSON.stringify(value));
  }

  function todayKey(date = new Date()) {
    return date.toISOString().slice(0, 10);
  }

  function isToday(value) {
    return todayKey(new Date(value)) === todayKey();
  }

  function num(value) {
    const clean = String(value ?? "").replace(/[^0-9.]/g, "");
    const parsed = Number.parseFloat(clean);
    return Number.isFinite(parsed) ? parsed : 0;
  }

  function todayDeliveries() {
    return deliveries
      .filter((d) => isToday(d.createdAt))
      .sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
  }

  function getWorkStart(todays) {
    if (shift.active && shift.startedAt && isToday(shift.startedAt)) return new Date(shift.startedAt);
    if (todays.length) return new Date(todays[0].createdAt);
    return null;
  }

  function calculate(todays) {
    const earnings = todays.reduce((sum, d) => sum + Number(d.earnings || 0), 0);
    const miles = todays.reduce((sum, d) => sum + Number(d.miles || 0), 0);
    const orders = todays.length;
    const avgOrder = orders ? earnings / orders : 0;
    const avgMile = miles ? earnings / miles : 0;
    const start = getWorkStart(todays);
    const hours = start ? Math.max((Date.now() - start.getTime()) / 36e5, 1 / 60) : 0;
    const avgHour = hours ? earnings / hours : 0;
    return { earnings, miles, orders, avgOrder, avgMile, avgHour, hours };
  }

  function render() {
    const todays = todayDeliveries();
    const c = calculate(todays);
    const goal = Number(settings.dailyGoal || 0);
    const pct = goal ? Math.min((c.earnings / goal) * 100, 999) : 0;
    const remaining = Math.max(goal - c.earnings, 0);

    els.todayEarned.textContent = money.format(c.earnings);
    els.goalPercent.textContent = `${Math.round(Math.min(pct, 100))}%`;
    els.goalBar.style.width = `${Math.min(pct, 100)}%`;
    els.goalText.textContent = money.format(goal);
    els.goalRemaining.textContent = goal
      ? remaining > 0
        ? `${money.format(remaining)} left to hit today's goal.`
        : `Goal hit. You're ${money.format(c.earnings - goal)} over target.`
      : "Set a daily goal in Settings.";

    els.ordersCount.textContent = String(c.orders);
    els.milesToday.textContent = c.miles.toFixed(1);
    els.avgOrder.textContent = money.format(c.avgOrder);
    els.avgMile.textContent = money.format(c.avgMile);
    els.avgHour.textContent = money.format(c.avgHour);
    els.timeWorking.textContent = formatHours(c.hours);

    renderTrend(todays);
    renderHistory();
    renderCompanyBreakdown(todays);
    renderSettings();
    renderShiftButton();
  }

  function formatHours(hours) {
    if (!hours) return "0h 00m";
    const totalMinutes = Math.max(0, Math.round(hours * 60));
    const h = Math.floor(totalMinutes / 60);
    const m = totalMinutes % 60;
    return `${h}h ${String(m).padStart(2, "0")}m`;
  }

  function renderTrend(todays) {
    els.trendCard.classList.remove("trend-up", "trend-down");
    if (todays.length === 0) {
      els.trendTitle.textContent = "No deliveries yet";
      els.trendDetail.textContent = "After each delivery, DriveLedger shows whether that delivery raised or lowered your average.";
      return;
    }
    if (todays.length === 1) {
      const only = todays[0];
      els.trendTitle.textContent = `${money.format(only.earnings)} first delivery`;
      els.trendDetail.textContent = `Your starting average is ${money.format(only.earnings)} per delivery and ${money.format(only.miles ? only.earnings / only.miles : 0)} per mile.`;
      return;
    }

    const before = todays.slice(0, -1);
    const last = todays[todays.length - 1];
    const beforeAvg = before.reduce((s, d) => s + Number(d.earnings || 0), 0) / before.length;
    const afterAvg = todays.reduce((s, d) => s + Number(d.earnings || 0), 0) / todays.length;
    const diff = afterAvg - beforeAvg;
    const perMile = last.miles ? last.earnings / last.miles : 0;

    if (diff >= 0) {
      els.trendCard.classList.add("trend-up");
      els.trendTitle.textContent = `Average went up by ${money.format(diff)}`;
      els.trendDetail.textContent = `Last delivery: ${money.format(last.earnings)} from ${last.company}, ${Number(last.miles).toFixed(1)} miles, ${money.format(perMile)} per mile.`;
    } else {
      els.trendCard.classList.add("trend-down");
      els.trendTitle.textContent = `Average went down by ${money.format(Math.abs(diff))}`;
      els.trendDetail.textContent = `Last delivery: ${money.format(last.earnings)} from ${last.company}, ${Number(last.miles).toFixed(1)} miles, ${money.format(perMile)} per mile.`;
    }
  }

  function renderCompanyBreakdown(todays) {
    if (!todays.length) {
      els.companyBreakdown.className = "breakdown empty";
      els.companyBreakdown.textContent = "No company data yet.";
      return;
    }
    els.companyBreakdown.className = "breakdown";
    const grouped = new Map();
    for (const d of todays) {
      const row = grouped.get(d.company) || { earnings: 0, miles: 0, count: 0 };
      row.earnings += Number(d.earnings || 0);
      row.miles += Number(d.miles || 0);
      row.count += 1;
      grouped.set(d.company, row);
    }
    els.companyBreakdown.innerHTML = [...grouped.entries()]
      .sort((a, b) => b[1].earnings - a[1].earnings)
      .map(([company, row]) => `
        <div class="breakdown-item">
          <div class="breakdown-top"><span>${escapeHTML(company)}</span><strong>${money.format(row.earnings)}</strong></div>
          <div class="breakdown-meta">${row.count} deliveries · ${row.miles.toFixed(1)} mi · ${money.format(row.miles ? row.earnings / row.miles : 0)}/mi</div>
        </div>
      `).join("");
  }

  function renderHistory() {
    if (!deliveries.length) {
      els.historyList.className = "history-list empty";
      els.historyList.textContent = "No deliveries saved yet.";
      return;
    }
    els.historyList.className = "history-list";
    els.historyList.innerHTML = [...deliveries]
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
      .map((d) => {
        const perMile = d.miles ? d.earnings / d.miles : 0;
        const date = new Date(d.createdAt).toLocaleString([], { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });
        return `
          <article class="history-item">
            <div class="history-top"><span>${escapeHTML(d.company)}</span><strong>${money.format(d.earnings)}</strong></div>
            <div class="history-meta">${Number(d.miles).toFixed(1)} mi · ${money.format(perMile)}/mi · ${date}</div>
            ${d.notes ? `<div class="history-meta">${escapeHTML(d.notes)}</div>` : ""}
            <div class="history-actions"><button class="delete-mini" data-delete="${d.id}" type="button">Delete</button></div>
          </article>
        `;
      }).join("");
  }

  function renderSettings() {
    els.goalInput.value = settings.dailyGoal ?? "";
    els.defaultCompanyInput.value = settings.defaultCompany || "DoorDash";
  }

  function renderShiftButton() {
    if (shift.active && shift.startedAt && isToday(shift.startedAt)) {
      els.shiftBtn.textContent = "End Day";
    } else {
      els.shiftBtn.textContent = "Start Day";
    }
  }

  function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>'"]/g, (ch) => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#039;", '"': "&quot;"
    }[ch]));
  }

  function showTab(tab) {
    document.querySelectorAll(".tab-screen").forEach((screen) => screen.classList.remove("active"));
    document.querySelectorAll(".tab-btn").forEach((btn) => btn.classList.remove("active"));
    $(`tab-${tab}`).classList.add("active");
    document.querySelector(`.tab-btn[data-tab="${tab}"]`).classList.add("active");
  }

  function openAdd(mode) {
    showTab("add");
    els.companyInput.value = settings.defaultCompany || "DoorDash";
    if (mode === "scan") {
      setTimeout(() => els.screenshotInput.click(), 150);
    } else {
      setTimeout(() => els.earningsInput.focus(), 150);
    }
  }

  async function scanScreenshot(file) {
    if (!file) return;
    lastOCRText = "";
    els.previewImage.src = URL.createObjectURL(file);
    els.previewImage.classList.remove("hidden");
    els.ocrDetails.classList.add("hidden");
    els.scanStatus.classList.remove("hidden");

    if (!window.Tesseract) {
      els.scanStatus.textContent = "OCR library did not load. Check internet, or add the delivery manually.";
      return;
    }

    try {
      els.scanStatus.textContent = "Scanning screenshot…";
      const result = await Tesseract.recognize(file, "eng", {
        logger: (m) => {
          if (m.status === "recognizing text" && m.progress) {
            els.scanStatus.textContent = `Scanning screenshot… ${Math.round(m.progress * 100)}%`;
          }
        }
      });
      lastOCRText = result?.data?.text || "";
      const parsed = parseScreenshotText(lastOCRText);
      applyParsedResult(parsed);
      els.ocrText.textContent = lastOCRText.trim() || "No text found.";
      els.ocrDetails.classList.remove("hidden");
      els.scanStatus.textContent = parsed.confidence > 0
        ? "Scan complete. Confirm the company, earnings, and miles before saving."
        : "Scan complete, but I could not confidently find all values. Please type or correct them.";
    } catch (err) {
      console.error(err);
      els.scanStatus.textContent = "Could not scan this screenshot. Add it manually or try a clearer screenshot.";
    }
  }

  function parseScreenshotText(text) {
    const original = String(text || "");
    const normalized = original.replace(/\s+/g, " ").trim();
    const lower = normalized.toLowerCase();
    const platform = detectPlatform(lower);
    const earnings = detectEarnings(original);
    const miles = detectMiles(original);
    let confidence = 0;
    if (platform) confidence += 1;
    if (earnings) confidence += 1;
    if (miles) confidence += 1;
    return { platform, earnings, miles, confidence };
  }

  function detectPlatform(lowerText) {
    const tests = [
      ["DoorDash", /door\s*dash|doordash|dash/i],
      ["Uber Eats", /uber\s*eats|ubereats|uber/i],
      ["Grubhub", /grub\s*hub|grubhub/i],
      ["Instacart", /instacart/i],
      ["Spark", /walmart\s*spark|spark\s*driver|spark/i],
      ["Roadie", /roadie/i],
      ["Catering", /ezcater|catering|deliverthat|dlivrd|foodja|cater/i]
    ];
    for (const [name, re] of tests) {
      if (re.test(lowerText)) return name;
    }
    return settings.defaultCompany || "Other";
  }

  function detectEarnings(text) {
    const matches = [];
    const dollarRegex = /(?:\$|usd\s*)\s*([0-9]{1,4}(?:[,.][0-9]{2})?)/gi;
    let m;
    while ((m = dollarRegex.exec(text)) !== null) {
      const value = Number.parseFloat(m[1].replace(",", "."));
      if (!Number.isFinite(value) || value <= 0 || value > 1000) continue;
      const context = text.slice(Math.max(0, m.index - 70), Math.min(text.length, m.index + 90)).toLowerCase();
      let score = 1;
      if (/total|earn|earning|payout|pay|paid|estimate|offer|guarantee|including|tip|fare|base/.test(context)) score += 3;
      if (/balance|cash\s*out|weekly|month|year|tax|fee|subscription|debt/.test(context)) score -= 2;
      if (value >= 2 && value <= 80) score += 1;
      matches.push({ value, score, index: m.index });
    }
    if (!matches.length) return 0;
    matches.sort((a, b) => b.score - a.score || b.value - a.value || a.index - b.index);
    return round2(matches[0].value);
  }

  function detectMiles(text) {
    const matches = [];
    const mileRegex = /([0-9]{1,3}(?:[,.][0-9])?)\s*(?:mi|mile|miles)\b/gi;
    let m;
    while ((m = mileRegex.exec(text)) !== null) {
      const value = Number.parseFloat(m[1].replace(",", "."));
      if (!Number.isFinite(value) || value <= 0 || value > 300) continue;
      const context = text.slice(Math.max(0, m.index - 60), Math.min(text.length, m.index + 60)).toLowerCase();
      let score = 1;
      if (/total|trip|delivery|distance|route|miles|mi/.test(context)) score += 2;
      if (/mph|minutes|minute|away|radius/.test(context)) score -= 1;
      matches.push({ value, score, index: m.index });
    }
    if (!matches.length) return 0;
    matches.sort((a, b) => b.score - a.score || a.value - b.value);
    return round1(matches[0].value);
  }

  function round2(v) { return Math.round(v * 100) / 100; }
  function round1(v) { return Math.round(v * 10) / 10; }

  function applyParsedResult(parsed) {
    if (parsed.platform) els.companyInput.value = parsed.platform;
    if (parsed.earnings) els.earningsInput.value = String(parsed.earnings.toFixed(2));
    if (parsed.miles) els.milesInput.value = String(parsed.miles.toFixed(1));
  }

  function saveDelivery(event) {
    event.preventDefault();
    const earnings = num(els.earningsInput.value);
    const miles = num(els.milesInput.value);
    const company = els.companyInput.value || settings.defaultCompany || "Other";

    if (!earnings || earnings <= 0) {
      alert("Enter the delivery earnings first.");
      els.earningsInput.focus();
      return;
    }
    if (!miles || miles <= 0) {
      alert("Enter the delivery miles first.");
      els.milesInput.focus();
      return;
    }

    const delivery = {
      id: crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random()}`,
      company,
      earnings: round2(earnings),
      miles: round1(miles),
      notes: els.notesInput.value.trim(),
      ocrText: lastOCRText,
      createdAt: new Date().toISOString()
    };

    deliveries.push(delivery);
    writeJSON(STORE_KEY, deliveries);
    clearForm(false);
    render();
    showTab("today");
  }

  function clearForm(keepCompany = true) {
    if (!keepCompany) els.companyInput.value = settings.defaultCompany || "DoorDash";
    els.earningsInput.value = "";
    els.milesInput.value = "";
    els.notesInput.value = "";
    els.screenshotInput.value = "";
    els.previewImage.classList.add("hidden");
    els.ocrDetails.classList.add("hidden");
    els.scanStatus.classList.add("hidden");
    lastOCRText = "";
  }

  function saveSettings() {
    const dailyGoal = num(els.goalInput.value);
    settings = {
      dailyGoal: dailyGoal || defaultSettings.dailyGoal,
      defaultCompany: els.defaultCompanyInput.value || "DoorDash"
    };
    writeJSON(SETTINGS_KEY, settings);
    els.companyInput.value = settings.defaultCompany;
    render();
    showTab("today");
  }

  function toggleShift() {
    if (shift.active && shift.startedAt && isToday(shift.startedAt)) {
      shift = { active: false, startedAt: null, endedAt: new Date().toISOString() };
    } else {
      shift = { active: true, startedAt: new Date().toISOString(), endedAt: null };
    }
    writeJSON(SHIFT_KEY, shift);
    render();
  }

  function deleteDelivery(id) {
    const item = deliveries.find((d) => d.id === id);
    if (!item) return;
    if (!confirm(`Delete ${money.format(item.earnings)} ${item.company} delivery?`)) return;
    deliveries = deliveries.filter((d) => d.id !== id);
    writeJSON(STORE_KEY, deliveries);
    render();
  }

  function clearToday() {
    const todays = todayDeliveries();
    if (!todays.length) return alert("There are no deliveries saved for today.");
    if (!confirm(`Delete ${todays.length} deliveries from today? This cannot be undone.`)) return;
    const today = todayKey();
    deliveries = deliveries.filter((d) => todayKey(new Date(d.createdAt)) !== today);
    writeJSON(STORE_KEY, deliveries);
    render();
    showTab("today");
  }

  function exportCSV() {
    if (!deliveries.length) return alert("No deliveries to export yet.");
    const header = ["date", "company", "earnings", "miles", "dollars_per_mile", "notes"];
    const rows = deliveries
      .sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt))
      .map((d) => [
        new Date(d.createdAt).toISOString(),
        d.company,
        d.earnings,
        d.miles,
        d.miles ? round2(d.earnings / d.miles) : 0,
        d.notes || ""
      ]);
    const csv = [header, ...rows]
      .map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(","))
      .join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `driveledger-${todayKey()}.csv`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  }

  function bindEvents() {
    document.querySelectorAll(".tab-btn").forEach((btn) => btn.addEventListener("click", () => showTab(btn.dataset.tab)));
    document.querySelectorAll("[data-open-add]").forEach((btn) => btn.addEventListener("click", () => openAdd(btn.dataset.openAdd)));
    $("deliveryForm").addEventListener("submit", saveDelivery);
    $("saveSettingsBtn").addEventListener("click", saveSettings);
    $("clearTodayBtn").addEventListener("click", clearToday);
    $("exportBtn").addEventListener("click", exportCSV);
    els.shiftBtn.addEventListener("click", toggleShift);
    els.screenshotInput.addEventListener("change", (event) => scanScreenshot(event.target.files?.[0]));
    els.historyList.addEventListener("click", (event) => {
      const btn = event.target.closest("[data-delete]");
      if (btn) deleteDelivery(btn.dataset.delete);
    });
  }

  function registerServiceWorker() {
    if ("serviceWorker" in navigator && location.protocol === "https:") {
      navigator.serviceWorker.register("service-worker.js").catch((err) => console.warn("Service worker not registered", err));
    }
  }

  bindEvents();
  render();
  setInterval(render, 60_000);
  registerServiceWorker();
})();
