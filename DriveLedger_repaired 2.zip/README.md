# DriveLedger

DriveLedger is a local-first Progressive Web App for gig delivery drivers. It tracks daily earnings, mileage, company totals, delivery averages, goal progress, shift time, screenshot OCR-assisted entry, and CSV export.

## Run locally

Because this is a static PWA, no backend server is required. Open `index.html` directly for simple testing, or serve the folder with any static server:

```bash
python -m http.server 8000
```

Then open `http://localhost:8000`.

## Install on iPhone/iPad

1. Host the folder with HTTPS, such as Netlify Drop.
2. Open the hosted site in Safari.
3. Tap Share.
4. Tap **Add to Home Screen**.

## Tests

The ZIP includes a minimal no-dependency smoke test suite. It checks static package structure, manifest/icon paths, JavaScript syntax, UI wiring, local storage namespacing, and startup behavior in a mocked browser environment.

```bash
python -m unittest discover -s tests
```

Optional Node scripts:

```bash
npm run syntax
npm run smoke
```

## Architecture notes

- There is no FastAPI/backend layer in this ZIP.
- Data is stored locally in browser `localStorage` under `driveledger.*` keys.
- Screenshot OCR uses Tesseract.js from jsDelivr on first load. If the CDN is unavailable, the app falls back to manual entry.
