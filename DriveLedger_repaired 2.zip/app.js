(() => {
  const STORE_KEY = "driveledger.deliveries.v1";
  const SETTINGS_KEY = "driveledger.settings.v1";
  const SHIFT_KEY = "driveledger.shift.v1";

  const money = new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" });
  const $ = (id) => document.getElementById(id);

  const defaultSettings = {
    dailyGoal: 200,
    defaultCompany: "DoorDash"
  };

  const allowedCompanies = new Set([
    "DoorDash",
    "Uber Eats",
    "Grubhub",
    "Catering",
    "Instacart",
    "Spark",
    "Roadie",
    "Other"
  ]);

  let deliveries = normalizeDeliveries(readJSON(STORE_KEY, []));
  let settings = normalizeSettings(readJSON(SETTINGS_KEY, {}));
  let shift = normalizeShift(readJSON(SHIFT_KEY, { active: false, startedAt: null, endedAt: null }));
  let lastOCRText = "";
  let lastDayKey = todayKey();
  let toastTimer = null;

  const els = {
    todayEarned: $("todayEarned"),
    goalPercent: $("goalPercent"),
    goalBar: $("goalBar"),
    goalText: $("goalText"),
    goalRemaining: $("goalRemaining"),
    ordersCount: $("ordersCount"),
    milesToday: $("milesToday"),
    avgOrder: $("avgOrder"),
    avgMile: $("avgMile"),
    avgHour: $("avgHour"),
    timeWorking: $("timeWorking"),
    trendTitle: $("trendTitle"),
    trendDetail: $("trendDetail"),
    trendCard: document.querySelector(".trend-card"),
    companyBreakdown: $("companyBreakdown"),
    historyList: $("historyList"),
    goalInput: $("goalInput"),
    defaultCompanyInput: $("defaultCompanyInput"),
    companyInput: $("companyInput"),
    earningsInput: $("earningsInput"),
    milesInput: $("milesInput"),
    notesInput: $("notesInput"),
    screenshotInput: $("screenshotInput"),
    previewImage: $("previewImage"),
    scanStatus: $("scanStatus"),
    ocrDetails: $("ocrDetails"),
    ocrText: $("ocrText"),
    shiftBtn: $("shiftBtn"),
    toast: $("toast")
  };

  function readJSON(key, fallback) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch {
      return fallback;
    }
  }

  function writeJSON(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch {
      toast("Could not save. Device storage may be full or blocked.");
    }
  }

  function normalizeDeliveries(value) {
    if (!Array.isArray(value)) return [];
    return value
      .map((item) => normalizeDelivery(item))
      .filter(Boolean);
  }

  function normalizeDelivery(item) {
    if (!item || typeof item !== "object") return null;
    const earnings = round2(num(item.earnings));
    const miles = round1(num(item.miles));
    const createdAt = new Date(item.createdAt);
    if (!earnings || earnings <= 0 || !miles || miles <= 0 || Number.isNaN(createdAt.getTime())) return null;
    const company = allowedCompanies.has(item.company) ? item.company : "Other";
    return {
      id: String(item.id || makeId()),
      company,
      earnings,
      miles,
      notes: String(item.notes || "").slice(0, 500),
      ocrText: String(item.ocrText || "").slice(0, 20000),
      createdAt: createdAt.toISOString()
    };
  }

  function normalizeSettings(value) {
    const raw = value && typeof value === "object" ? value : {};
    const dailyGoal = num(raw.dailyGoal);
    const defaultCompany = allowedCompanies.has(raw.defaultCompany) ? raw.defaultCompany : defaultSettings.defaultCompany;
    return {
      dailyGoal: dailyGoal > 0 && dailyGoal <= 100000 ? round2(dailyGoal) : defaultSettings.dailyGoal,
      defaultCompany
    };
  }

  function normalizeShift(value) {
    const raw = value && typeof value === "object" ? value : {};
    const startedAt = raw.startedAt && !Number.isNaN(new Date(raw.startedAt).getTime()) ? new Date(raw.startedAt).toISOString() : null;
    const endedAt = raw.endedAt && !Number.isNaN(new Date(raw.endedAt).getTime()) ? new Date(raw.endedAt).toISOString() : null;
    return {
      active: Boolean(raw.active && startedAt),
      startedAt,
      endedAt
    };
  }

  // Local calendar date, not UTC. The old version used toISOString(), which
  // flips to "tomorrow" at 5-8 PM in US time zones and made evening
  // deliveries vanish from the Today screen during dinner rush.
  function todayKey(date = new Date()) {
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, "0");
    const d = String(date.getDate()).padStart(2, "0");
    return `${y}-${m}-${d}`;
  }

  function isToday(value) {
    const date = new Date(value);
    return !Number.isNaN(date.getTime()) && todayKey(date) === todayKey();
  }

  // Accepts "18.75", "18,75", "1,234.56", "$12", etc.
  function num(value) {
    let s = String(value ?? "").trim().replace(/[^0-9.,]/g, "");
    if (!s) return 0;
    const lastComma = s.lastIndexOf(",");
    const lastDot = s.lastIndexOf(".");
    if (lastComma > -1 && lastDot > -1) {
      if (lastComma > lastDot) {
        s = s.replace(/\./g, "").replace(/,/g, ".");
      } else {
        s = s.replace(/,/g, "");
      }
    } else if (lastComma > -1) {
      const parts = s.split(",");
      s = parts.length === 2 && parts[1].length !== 3 ? s.replace(",", ".") : s.replace(/,/g, "");
    }
    const parsed = Number.parseFloat(s);
    return Number.isFinite(parsed) ? parsed : 0;
  }

  function todayDeliveries() {
    return deliveries
      .filter((d) => isToday(d.createdAt))
      .sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
  }

  // Work window: starts at "Start Day" (or first delivery), and freezes at
  // "End Day" so Avg/Hour stops sliding down after you go home.
  function getWorkWindow(todays) {
    let start = null;
    if (shift.startedAt && isToday(shift.startedAt)) start = new Date(shift.startedAt);
    else if (todays.length) start = new Date(todays[0].createdAt);
    if (!start) return null;

    let end = new Date();
    if (!shift.active && shift.endedAt && isToday(shift.endedAt)) {
      const ended = new Date(shift.endedAt);
      if (ended > start) end = ended;
    }
    if (todays.length) {
      const lastDelivery = new Date(todays[todays.length - 1].createdAt);
      if (lastDelivery > end) end = lastDelivery;
    }
    return { start, end };
  }

  function calculate(todays) {
    const earnings = todays.reduce((sum, d) => sum + Number(d.earnings || 0), 0);
    const miles = todays.reduce((sum, d) => sum + Number(d.miles || 0), 0);
    const orders = todays.length;
    const avgOrder = orders ? earnings / orders : 0;
    const avgMile = miles ? earnings / miles : 0;
    const window = getWorkWindow(todays);
    const hours = window ? Math.max((window.end - window.start) / 36e5, 1 / 60) : 0;
    const avgHour = hours ? earnings / hours : 0;
    return { earnings, miles, orders, avgOrder, avgMile, avgHour, hours };
  }

  function render() {
    const todays = todayDeliveries();
    const c = calculate(todays);
    const goal = Number(settings.dailyGoal || 0);
    const pct = goal ? Math.min((c.earnings / goal) * 100, 999) : 0;
    const remaining = Math.max(goal - c.earnings, 0);

    els.todayEarned.textContent = money.format(c.earnings);
    els.goalPercent.textContent = `${Math.round(Math.min(pct, 100))}%`;
    els.goalBar.style.width = `${Math.min(pct, 100)}%`;
    els.goalText.textContent = money.format(goal);
    els.goalRemaining.textContent = goal
      ? remaining > 0
        ? `${money.format(remaining)} left to hit today's goal.`
        : `Goal hit. You're ${money.format(c.earnings - goal)} over target.`
      : "Set a daily goal in Settings.";

    els.ordersCount.textContent = String(c.orders);
    els.milesToday.textContent = c.miles.toFixed(1);
    els.avgOrder.textContent = money.format(c.avgOrder);
    els.avgMile.textContent = money.format(c.avgMile);
    els.avgHour.textContent = money.format(c.avgHour);
    els.timeWorking.textContent = formatHours(c.hours);

    renderTrend(todays);
    renderHistory();
    renderCompanyBreakdown(todays);
    renderSettings();
    renderShiftButton();
  }

  // Lightweight refresh for the two time-based numbers. Runs on a timer
  // without rebuilding the history list, so it never interrupts scrolling
  // or typing.
  function renderLive() {
    const todays = todayDeliveries();
    const c = calculate(todays);
    els.avgHour.textContent = money.format(c.avgHour);
    els.timeWorking.textContent = formatHours(c.hours);
  }

  function formatHours(hours) {
    if (!hours) return "0h 00m";
    const totalMinutes = Math.max(0, Math.round(hours * 60));
    const h = Math.floor(totalMinutes / 60);
    const m = totalMinutes % 60;
    return `${h}h ${String(m).padStart(2, "0")}m`;
  }

  function renderTrend(todays) {
    els.trendCard.classList.remove("trend-up", "trend-down");
    if (todays.length === 0) {
      els.trendTitle.textContent = "No deliveries yet";
      els.trendDetail.textContent = "After each delivery, DriveLedger shows whether that delivery raised or lowered your average.";
      return;
    }
    if (todays.length === 1) {
      const only = todays[0];
      const earnings = Number(only.earnings || 0);
      const miles = Number(only.miles || 0);
      els.trendTitle.textContent = `${money.format(earnings)} first delivery`;
      els.trendDetail.textContent = `Your starting average is ${money.format(earnings)} per delivery and ${money.format(miles ? earnings / miles : 0)} per mile.`;
      return;
    }

    const before = todays.slice(0, -1);
    const last = todays[todays.length - 1];
    const lastEarnings = Number(last.earnings || 0);
    const lastMiles = Number(last.miles || 0);
    const beforeAvg = before.reduce((s, d) => s + Number(d.earnings || 0), 0) / before.length;
    const afterAvg = todays.reduce((s, d) => s + Number(d.earnings || 0), 0) / todays.length;
    const diff = afterAvg - beforeAvg;
    const perMile = lastMiles ? lastEarnings / lastMiles : 0;
    const detail = `Last delivery: ${money.format(lastEarnings)} from ${last.company}, ${lastMiles.toFixed(1)} miles, ${money.format(perMile)} per mile.`;

    if (diff >= 0) {
      els.trendCard.classList.add("trend-up");
      els.trendTitle.textContent = `Average went up by ${money.format(diff)}`;
    } else {
      els.trendCard.classList.add("trend-down");
      els.trendTitle.textContent = `Average went down by ${money.format(Math.abs(diff))}`;
    }
    els.trendDetail.textContent = detail;
  }

  function renderCompanyBreakdown(todays) {
    if (!todays.length) {
      els.companyBreakdown.className = "breakdown empty";
      els.companyBreakdown.textContent = "No company data yet.";
      return;
    }
    els.companyBreakdown.className = "breakdown";
    const grouped = new Map();
    for (const d of todays) {
      const row = grouped.get(d.company) || { earnings: 0, miles: 0, count: 0 };
      row.earnings += Number(d.earnings || 0);
      row.miles += Number(d.miles || 0);
      row.count += 1;
      grouped.set(d.company, row);
    }
    els.companyBreakdown.innerHTML = [...grouped.entries()]
      .sort((a, b) => b[1].earnings - a[1].earnings)
      .map(([company, row]) => `
        <div class="breakdown-item">
          <div class="breakdown-top"><span>${escapeHTML(company)}</span><strong>${money.format(row.earnings)}</strong></div>
          <div class="breakdown-meta">${row.count} ${row.count === 1 ? "delivery" : "deliveries"} · ${row.miles.toFixed(1)} mi · ${money.format(row.miles ? row.earnings / row.miles : 0)}/mi</div>
        </div>
      `).join("");
  }

  function renderHistory() {
    if (!deliveries.length) {
      els.historyList.className = "history-list empty";
      els.historyList.textContent = "No deliveries saved yet.";
      return;
    }
    els.historyList.className = "history-list";
    els.historyList.innerHTML = [...deliveries]
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
      .map((d) => {
        const earnings = Number(d.earnings || 0);
        const miles = Number(d.miles || 0);
        const perMile = miles ? earnings / miles : 0;
        const date = new Date(d.createdAt).toLocaleString([], { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });
        return `
          <article class="history-item">
            <div class="history-top"><span>${escapeHTML(d.company)}</span><strong>${money.format(earnings)}</strong></div>
            <div class="history-meta">${miles.toFixed(1)} mi · ${money.format(perMile)}/mi · ${date}</div>
            ${d.notes ? `<div class="history-meta">${escapeHTML(d.notes)}</div>` : ""}
            <div class="history-actions"><button class="delete-mini" data-delete="${escapeHTML(d.id)}" type="button">Delete</button></div>
          </article>
        `;
      }).join("");
  }

  // Only touch the Settings inputs when the user is not typing in them,
  // so background refreshes never wipe a half-typed goal.
  function renderSettings() {
    if (document.activeElement !== els.goalInput) {
      els.goalInput.value = settings.dailyGoal ?? "";
    }
    if (document.activeElement !== els.defaultCompanyInput) {
      els.defaultCompanyInput.value = settings.defaultCompany || "DoorDash";
    }
  }

  function renderShiftButton() {
    if (shift.active && shift.startedAt && isToday(shift.startedAt)) {
      els.shiftBtn.textContent = "End Day";
    } else {
      els.shiftBtn.textContent = "Start Day";
    }
  }

  function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>'"]/g, (ch) => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#039;", '"': "&quot;"
    }[ch]));
  }

  function makeId() {
    const cryptoObj = globalThis.crypto;
    if (cryptoObj && typeof cryptoObj.randomUUID === "function") {
      return cryptoObj.randomUUID();
    }
    if (cryptoObj && typeof cryptoObj.getRandomValues === "function") {
      const bytes = new Uint8Array(16);
      cryptoObj.getRandomValues(bytes);
      bytes[6] = (bytes[6] & 0x0f) | 0x40;
      bytes[8] = (bytes[8] & 0x3f) | 0x80;
      const hex = [...bytes].map((byte) => byte.toString(16).padStart(2, "0")).join("");
      return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
    }
    return `dl-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
  }

  function toast(message) {
    if (!els.toast) return;
    els.toast.textContent = message;
    els.toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => els.toast.classList.remove("show"), 2600);
  }

  function flagInvalid(input) {
    input.classList.add("invalid");
    input.focus();
    setTimeout(() => input.classList.remove("invalid"), 1400);
  }

  function showTab(tab) {
    const screen = $(`tab-${tab}`);
    const button = document.querySelector(`.tab-btn[data-tab="${tab}"]`);
    if (!screen || !button) {
      console.warn(`Unknown tab requested: ${tab}`);
      return;
    }
    document.querySelectorAll(".tab-screen").forEach((item) => item.classList.remove("active"));
    document.querySelectorAll(".tab-btn").forEach((item) => item.classList.remove("active"));
    screen.classList.add("active");
    button.classList.add("active");
  }

  // iOS Safari only opens the photo picker / keyboard when the call happens
  // inside the original tap. The old setTimeout(…, 150) broke that chain,
  // so "Scan Screenshot" silently did nothing on iPhone.
  function openAdd(mode) {
    showTab("add");
    els.companyInput.value = settings.defaultCompany || "DoorDash";
    if (mode === "scan") {
      els.screenshotInput.click();
    } else {
      els.earningsInput.focus();
    }
  }

  async function scanScreenshot(file) {
    if (!file) return;
    lastOCRText = "";

    if (els.previewImage.dataset.url) {
      URL.revokeObjectURL(els.previewImage.dataset.url);
    }
    const previewURL = URL.createObjectURL(file);
    els.previewImage.dataset.url = previewURL;
    els.previewImage.src = previewURL;
    els.previewImage.classList.remove("hidden");
    els.ocrDetails.classList.add("hidden");
    els.scanStatus.classList.remove("hidden");

    if (!window.Tesseract) {
      els.scanStatus.textContent = "OCR needs internet the first time it loads. Type the numbers below instead.";
      return;
    }

    try {
      els.scanStatus.textContent = "Scanning screenshot…";
      const result = await Tesseract.recognize(file, "eng", {
        logger: (m) => {
          if (m.status === "recognizing text" && m.progress) {
            els.scanStatus.textContent = `Scanning screenshot… ${Math.round(m.progress * 100)}%`;
          }
        }
      });
      lastOCRText = result?.data?.text || "";
      const parsed = parseScreenshotText(lastOCRText);
      applyParsedResult(parsed);
      els.ocrText.textContent = lastOCRText.trim() || "No text found.";
      els.ocrDetails.classList.remove("hidden");
      els.scanStatus.textContent = parsed.confidence >= 2
        ? "Scan complete. Confirm the company, earnings, and miles before saving."
        : "Scan complete, but I could not confidently find all values. Please type or correct them.";
    } catch (err) {
      console.error(err);
      els.scanStatus.textContent = "Could not scan this screenshot. Add it manually or try a clearer screenshot.";
    }
  }

  function parseScreenshotText(text) {
    const original = String(text || "");
    const normalized = original.replace(/\s+/g, " ").trim();
    const lower = normalized.toLowerCase();
    const platform = detectPlatform(lower);
    const earnings = detectEarnings(original);
    const miles = detectMiles(original);
    let confidence = 0;
    if (platform && platform !== settings.defaultCompany) confidence += 1;
    if (earnings) confidence += 1;
    if (miles) confidence += 1;
    return { platform, earnings, miles, confidence };
  }

  function detectPlatform(lowerText) {
    const tests = [
      ["DoorDash", /door\s*dash|doordash|dasher/i],
      ["Uber Eats", /uber\s*eats|ubereats|uber/i],
      ["Grubhub", /grub\s*hub|grubhub/i],
      ["Instacart", /instacart/i],
      ["Spark", /walmart\s*spark|spark\s*driver|spark/i],
      ["Roadie", /roadie/i],
      ["Catering", /ezcater|catering|deliverthat|dlivrd|foodja|cater/i],
      ["DoorDash", /\bdash\b/i]
    ];
    for (const [name, re] of tests) {
      if (re.test(lowerText)) return name;
    }
    return settings.defaultCompany || "Other";
  }

  function parseMoneyToken(token) {
    // "1,234.56" -> 1234.56    "18,75" -> 18.75    "23.50" -> 23.5
    if (/^\d{1,3}(,\d{3})+(\.\d{2})?$/.test(token)) {
      return Number.parseFloat(token.replace(/,/g, ""));
    }
    return Number.parseFloat(token.replace(/,/g, "."));
  }

  function detectEarnings(text) {
    const matches = [];
    const push = (raw, index, bonus) => {
      const value = parseMoneyToken(raw);
      if (!Number.isFinite(value) || value <= 0 || value > 1000) return;
      const context = text.slice(Math.max(0, index - 70), Math.min(text.length, index + 90)).toLowerCase();
      let score = 1 + bonus;
      if (/total|earn|earning|payout|pay|paid|estimate|offer|guarantee|including|tip|fare|base/.test(context)) score += 3;
      if (/balance|cash\s*out|weekly|month|year|tax|fee|subscription|debt|per\s*hour|\/\s*hr/.test(context)) score -= 2;
      if (value >= 2 && value <= 80) score += 1;
      matches.push({ value, score, index });
    };

    // Amounts with an explicit currency marker.
    const dollarRegex = /(?:\$|usd\s*)\s*([0-9]{1,3}(?:,[0-9]{3})+(?:\.[0-9]{2})?|[0-9]{1,4}(?:[.,][0-9]{2})?)/gi;
    let m;
    while ((m = dollarRegex.exec(text)) !== null) push(m[1], m.index, 0);

    // OCR often drops the "$" — also accept bare decimals right after an
    // earnings keyword, e.g. "Total 23.50".
    const keywordRegex = /(?:total|earnings?|payout|paid|guarantee|fare|offer)[^0-9$\n]{0,14}([0-9]{1,3}(?:,[0-9]{3})*\.[0-9]{2})/gi;
    while ((m = keywordRegex.exec(text)) !== null) push(m[1], m.index, 2);

    if (!matches.length) return 0;
    matches.sort((a, b) => b.score - a.score || b.value - a.value || a.index - b.index);
    return round2(matches[0].value);
  }

  function detectMiles(text) {
    const matches = [];
    // Allow two decimals ("5.42 mi") and a trailing period ("mi.") while
    // still rejecting "min", "mph", etc.
    const mileRegex = /([0-9]{1,3}(?:[.,][0-9]{1,2})?)\s*(?:miles|mile|mi)(?![a-z])/gi;
    let m;
    while ((m = mileRegex.exec(text)) !== null) {
      const value = Number.parseFloat(m[1].replace(",", "."));
      if (!Number.isFinite(value) || value <= 0 || value > 300) continue;
      const context = text.slice(Math.max(0, m.index - 60), Math.min(text.length, m.index + 60)).toLowerCase();
      let score = 1;
      if (/total|trip|delivery|distance|route/.test(context)) score += 2;
      if (/mph|minutes|minute|away|radius/.test(context)) score -= 1;
      matches.push({ value, score, index: m.index });
    }
    if (!matches.length) return 0;
    matches.sort((a, b) => b.score - a.score || a.value - b.value);
    return round1(matches[0].value);
  }

  function round2(v) { return Math.round(v * 100) / 100; }
  function round1(v) { return Math.round(v * 10) / 10; }

  function applyParsedResult(parsed) {
    if (parsed.platform) els.companyInput.value = parsed.platform;
    if (parsed.earnings) els.earningsInput.value = parsed.earnings.toFixed(2);
    if (parsed.miles) els.milesInput.value = parsed.miles.toFixed(1);
  }

  function saveDelivery(event) {
    event.preventDefault();
    const earnings = num(els.earningsInput.value);
    const miles = num(els.milesInput.value);
    const selectedCompany = els.companyInput.value || settings.defaultCompany || "Other";
    const company = allowedCompanies.has(selectedCompany) ? selectedCompany : "Other";

    if (!earnings || earnings <= 0) {
      toast("Enter the delivery earnings first.");
      flagInvalid(els.earningsInput);
      return;
    }
    if (!miles || miles <= 0) {
      toast("Enter the delivery miles first.");
      flagInvalid(els.milesInput);
      return;
    }

    const delivery = {
      id: makeId(),
      company,
      earnings: round2(earnings),
      miles: round1(miles),
      notes: els.notesInput.value.trim(),
      ocrText: lastOCRText,
      createdAt: new Date().toISOString()
    };

    deliveries.push(delivery);
    writeJSON(STORE_KEY, deliveries);
    clearForm(false);
    if (document.activeElement && typeof document.activeElement.blur === "function") {
      document.activeElement.blur();
    }
    render();
    showTab("today");
    toast(`Saved ${money.format(delivery.earnings)} from ${company}.`);
  }

  function clearForm(keepCompany = true) {
    if (!keepCompany) els.companyInput.value = settings.defaultCompany || "DoorDash";
    els.earningsInput.value = "";
    els.milesInput.value = "";
    els.notesInput.value = "";
    els.screenshotInput.value = "";
    els.previewImage.classList.add("hidden");
    els.ocrDetails.classList.add("hidden");
    els.scanStatus.classList.add("hidden");
    if (els.previewImage.dataset.url) {
      URL.revokeObjectURL(els.previewImage.dataset.url);
      delete els.previewImage.dataset.url;
    }
    els.previewImage.removeAttribute("src");
    lastOCRText = "";
  }

  function saveSettings() {
    const dailyGoal = num(els.goalInput.value);
    const defaultCompany = allowedCompanies.has(els.defaultCompanyInput.value) ? els.defaultCompanyInput.value : defaultSettings.defaultCompany;
    settings = {
      dailyGoal: dailyGoal > 0 && dailyGoal <= 100000 ? round2(dailyGoal) : defaultSettings.dailyGoal,
      defaultCompany
    };
    writeJSON(SETTINGS_KEY, settings);
    els.companyInput.value = settings.defaultCompany;
    render();
    showTab("today");
    toast("Settings saved.");
  }

  function toggleShift() {
    if (shift.active && shift.startedAt && isToday(shift.startedAt)) {
      // Keep startedAt so Time Working and Avg/Hour freeze at the moment
      // the day ended instead of resetting or continuing to climb.
      shift = { active: false, startedAt: shift.startedAt, endedAt: new Date().toISOString() };
      toast("Day ended. Time and hourly stats are frozen.");
    } else {
      shift = { active: true, startedAt: new Date().toISOString(), endedAt: null };
      toast("Day started. The clock is running.");
    }
    writeJSON(SHIFT_KEY, shift);
    render();
  }

  function deleteDelivery(id) {
    const item = deliveries.find((d) => d.id === id);
    if (!item) return;
    if (!confirm(`Delete ${money.format(Number(item.earnings || 0))} ${item.company} delivery?`)) return;
    deliveries = deliveries.filter((d) => d.id !== id);
    writeJSON(STORE_KEY, deliveries);
    render();
    toast("Delivery deleted.");
  }

  function clearToday() {
    const todays = todayDeliveries();
    if (!todays.length) return toast("There are no deliveries saved for today.");
    if (!confirm(`Delete ${todays.length} ${todays.length === 1 ? "delivery" : "deliveries"} from today? This cannot be undone.`)) return;
    const today = todayKey();
    deliveries = deliveries.filter((d) => todayKey(new Date(d.createdAt)) !== today);
    writeJSON(STORE_KEY, deliveries);
    render();
    showTab("today");
    toast("Today's deliveries deleted.");
  }

  function buildCSV() {
    const header = ["date", "company", "earnings", "miles", "dollars_per_mile", "notes"];
    const rows = [...deliveries]
      .sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt))
      .map((d) => [
        new Date(d.createdAt).toISOString(),
        d.company,
        d.earnings,
        d.miles,
        d.miles ? round2(Number(d.earnings || 0) / Number(d.miles)) : 0,
        d.notes || ""
      ]);
    return [header, ...rows]
      .map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(","))
      .join("\r\n");
  }

  // iOS home-screen web apps can't reliably use <a download>. The share
  // sheet is the native path: from there the CSV can go to Files, Numbers,
  // Mail, AirDrop, anywhere. Falls back to a normal download elsewhere.
  async function exportCSV() {
    if (!deliveries.length) return toast("No deliveries to export yet.");
    const csv = "\uFEFF" + buildCSV();
    const filename = `driveledger-${todayKey()}.csv`;

    if (navigator.canShare && typeof File === "function") {
      try {
        const file = new File([csv], filename, { type: "text/csv" });
        if (navigator.canShare({ files: [file] })) {
          await navigator.share({ files: [file], title: "DriveLedger export" });
          return;
        }
      } catch (err) {
        if (err && err.name === "AbortError") return; // user closed the share sheet
        // fall through to download
      }
    }

    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
    toast("CSV exported.");
  }

  function bindEvents() {
    document.querySelectorAll(".tab-btn").forEach((btn) => btn.addEventListener("click", () => showTab(btn.dataset.tab)));
    document.querySelectorAll("[data-open-add]").forEach((btn) => btn.addEventListener("click", () => openAdd(btn.dataset.openAdd)));
    $("deliveryForm").addEventListener("submit", saveDelivery);
    $("saveSettingsBtn").addEventListener("click", saveSettings);
    $("clearTodayBtn").addEventListener("click", clearToday);
    $("exportBtn").addEventListener("click", exportCSV);
    els.shiftBtn.addEventListener("click", toggleShift);
    els.screenshotInput.addEventListener("change", (event) => scanScreenshot(event.target.files?.[0]));
    els.historyList.addEventListener("click", (event) => {
      const btn = event.target.closest("[data-delete]");
      if (btn) deleteDelivery(btn.dataset.delete);
    });

    // iOS suspends timers in home-screen apps; refresh when coming back.
    document.addEventListener("visibilitychange", () => {
      if (!document.hidden) checkDayAndRender(true);
    });
    window.addEventListener("pageshow", () => checkDayAndRender(true));
  }

  function checkDayAndRender(full = false) {
    const key = todayKey();
    if (key !== lastDayKey) {
      lastDayKey = key;
      render(); // midnight rollover: reset the Today screen
      return;
    }
    if (full) render();
    else renderLive();
  }

  function registerServiceWorker() {
    // Only meaningful when the app has its companion files next to it.
    if (!document.querySelector('link[rel="manifest"]')) return;
    const isLocal = ["localhost", "127.0.0.1"].includes(location.hostname);
    if ("serviceWorker" in navigator && (location.protocol === "https:" || isLocal)) {
      navigator.serviceWorker.register("./service-worker.js").catch((err) => console.warn("Service worker not registered", err));
    }
  }

  bindEvents();
  render();
  setInterval(() => checkDayAndRender(false), 30_000);
  registerServiceWorker();
})();
