import json
import re
import subprocess
import unittest
from html.parser import HTMLParser
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]


class AssetParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.ids = set()
        self.assets = []
        self.scripts = []
        self.classes = set()

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if 'id' in attrs:
            self.ids.add(attrs['id'])
        for class_name in attrs.get('class', '').split():
            self.classes.add(class_name)
        if tag == 'link' and attrs.get('rel') in {'stylesheet', 'manifest', 'apple-touch-icon', 'icon'}:
            href = attrs.get('href')
            if href and not href.startswith(('http://', 'https://', 'data:')):
                self.assets.append(href)
        if tag == 'script':
            src = attrs.get('src')
            if src:
                self.scripts.append(src)
                if not src.startswith(('http://', 'https://')):
                    self.assets.append(src)


class DriveLedgerStaticAppTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.html = (PROJECT_ROOT / 'index.html').read_text(encoding='utf-8')
        cls.app_js = (PROJECT_ROOT / 'app.js').read_text(encoding='utf-8')
        cls.parser = AssetParser()
        cls.parser.feed(cls.html)

    def test_required_package_files_exist(self):
        for rel in ['index.html', 'styles.css', 'app.js', 'manifest.json', 'service-worker.js', 'icons/icon-192.png', 'icons/icon-512.png']:
            self.assertTrue((PROJECT_ROOT / rel).is_file(), f'missing {rel}')

    def test_html_referenced_local_assets_exist(self):
        for rel in self.parser.assets:
            self.assertTrue((PROJECT_ROOT / rel).is_file(), f'HTML references missing asset {rel}')

    def test_manifest_is_valid_and_icon_paths_exist(self):
        manifest = json.loads((PROJECT_ROOT / 'manifest.json').read_text(encoding='utf-8'))
        self.assertEqual(manifest.get('name'), 'DriveLedger')
        self.assertEqual(manifest.get('display'), 'standalone')
        for icon in manifest.get('icons', []):
            self.assertTrue((PROJECT_ROOT / icon['src']).is_file(), f"manifest references missing icon {icon['src']}")

    def test_javascript_syntax_is_valid(self):
        for rel in ['app.js', 'service-worker.js']:
            result = subprocess.run(['node', '--check', rel], cwd=PROJECT_ROOT, text=True, capture_output=True)
            self.assertEqual(result.returncode, 0, result.stderr or result.stdout)

    def test_dom_ids_referenced_by_app_exist(self):
        referenced = set(re.findall(r'\$\("([A-Za-z0-9_-]+)"\)', self.app_js))
        missing = sorted(referenced - self.parser.ids)
        self.assertEqual(missing, [], f'app.js references missing DOM IDs: {missing}')
        self.assertIn('trend-card', self.parser.classes)

    def test_ui_controls_are_bound_to_real_logic(self):
        expected_bindings = [
            'deliveryForm',
            'saveSettingsBtn',
            'clearTodayBtn',
            'exportBtn',
            'shiftBtn',
            'screenshotInput',
            'historyList',
        ]
        for element_id in expected_bindings:
            self.assertIn(element_id, self.parser.ids)
            self.assertRegex(self.app_js, rf'(\$\("{element_id}"\)|els\.{element_id})\.addEventListener')
        self.assertIn('scanScreenshot', self.app_js)
        self.assertNotIn('/api/', self.app_js, 'static UI should not call missing backend API routes')

    def test_storage_is_local_and_namespaced(self):
        self.assertIn('driveledger.deliveries.v1', self.app_js)
        self.assertIn('driveledger.settings.v1', self.app_js)
        self.assertIn('driveledger.shift.v1', self.app_js)
        self.assertNotRegex(self.app_js, r'indexedDB\.open\([^)]*[^a-zA-Z]')
        self.assertNotRegex(self.app_js, r'fetch\(["\']/(api|backend)')

    def test_startup_smoke_test_with_mock_browser(self):
        result = subprocess.run(['node', 'tools/smoke-startup.js'], cwd=PROJECT_ROOT, text=True, capture_output=True)
        self.assertEqual(result.returncode, 0, result.stderr or result.stdout)
        self.assertIn('passed', result.stdout)


if __name__ == '__main__':
    unittest.main()
