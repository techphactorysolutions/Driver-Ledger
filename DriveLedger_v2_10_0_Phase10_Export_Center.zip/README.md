# DriveLedger

DriveLedger is a local-first Progressive Web App for gig delivery drivers. It tracks daily earnings, mileage, estimated profit, tax mileage deduction, platform performance, zone performance, shift pace, screenshot OCR-assisted entry, and accept/decline order decisions.

## Current release

Version: `2.10.0` Phase 10 Tax and Export Center.

This release preserves the static PWA architecture. There is no backend, database server, framework, build step, or account system. The app runs from plain static files and stores user data locally in the browser.

## Included features

- Premium Today Command Center with dedicated Pace, Efficiency, Tax, Performance, and Last Delivery Impact cards.
- Centralized Profit Engine used across dashboard, calculator, history, recaps, and exports for consistent vehicle cost, profit, hourly, $/mile, tax, projection, ETA, and driver score math.
- **Fast Quick Add bottom sheet from Today** so drivers can add a delivery without switching tabs.
- Quick Add fields for company, earnings, miles, minutes, zone, and optional collapsible notes.
- Quick Add validation for valid company, earnings greater than 0, miles 0 or greater, and minutes 0 or greater.
- Quick Add smart defaults using the last saved company/zone, falling back to Settings defaults.
- Quick Add **Save** and **Save + Add Another** actions with immediate dashboard updates and toast confirmation.
- Main hero card with gross earnings, estimated profit, daily goal percentage, progress bar, shift status, and an in-card start/end day action.
- Pace card with gross/hour, profit/hour, projected today total, goal ETA, and a live pace recommendation.
- Efficiency card with gross $/mile, profit $/mile, business miles, average delivery value, and order-quality coaching.
- Tax card with mileage deduction estimate, mileage deduction rate, tracked business miles, estimated vehicle cost, and delivery count.
- Performance card with driver score, best company today, best zone today, time working, and simple recommendation text.
- Profit Mode using editable gas price, MPG, maintenance cost per mile, and mileage deduction rate.
- Accept Calculator v2 that recommends **ACCEPT**, **BORDERLINE**, or **DECLINE** using user-defined minimum payout, $/mile, $/hour, max-mile, gas, MPG, and maintenance rules.
- Accept Calculator v2 shows gross $/mile, gross hourly pace, estimated profit, profit $/mile, profit hourly pace, and pass/fail threshold rows.
- Accept Calculator supports Calculate Only, Save as Completed, Clear, Copy Decision, zone capture, and optional note capture.
- Screenshot OCR review-first workflow with editable detected company, earnings, miles, minutes, confidence labels, raw text review, direct save, cancel, and clear actions.
- Existing Add tab manual delivery entry with optional minutes, zone, notes, and **Save + Add Another** support.
- Delivery edit, duplicate, delete, and undo-delete support.
- Grouped History by day with daily totals, estimated profit, total miles, average $/mile, gross/hour where available, tracked time, per-delivery profit details, minutes, zone, source labels, edit, duplicate, delete, and undo-delete actions.
- Company and zone performance breakdowns on Today with earnings, profit, miles, delivery count, gross $/mile, profit $/mile, gross/hour, and profit/hour.
- Dedicated Analytics tab with platform performance, zone performance, best/worst labels, hourly earnings insights, and plain CSS performance bars.
- Daily shift summary with copy support.
- Tax & Export Center with standard CSV, tax CSV, daily summary CSV, JSON backup, JSON import, and pre-import rollback restore.
- Local-first storage using browser `localStorage` under `driveledger.*` keys.



## Phase 10 Tax and Export Center notes

Phase 10 upgrades the History export buttons into a dedicated **Tax & Export Center**. The app remains a static local-first PWA; exports are generated entirely from saved browser data and do not require a backend.

Export types:

```text
Standard CSV: date, company, earnings, miles, minutes, zone, note, source
Tax CSV: date, company, gross earnings, business miles, mileage deduction rate, estimated deduction, fuel estimate, maintenance estimate, estimated profit
Daily Summary CSV: date, total earnings, estimated profit, miles, deliveries, average $/mile, gross/hour, profit/hour
JSON Backup: deliveries, settings, shift, app data version, exportedAt
```

CSV cells are quoted and escaped so commas, quotes, and multiline notes remain valid. Empty ledgers export header-only CSV files instead of failing. JSON backup includes `appDataVersion` and schema metadata for safer future imports.

Tax, deduction, fuel, maintenance, and profit numbers are estimates based on the user's Settings and are not tax advice.


## Phase 9 Platform and Zone Analytics notes

Phase 9 adds a dedicated Analytics tab and upgrades the Today breakdown cards. All analytics are calculated from local saved deliveries; no fake sample data, backend, or chart library was added.

Analytics now include:

```text
company/platform earnings
estimated profit
delivery count
total miles
average gross $/mile
average profit $/mile
average gross/hour
average profit/hour
zone performance using the same metrics
best/worst company today
best/worst zone today
best hour today
best saved hour from recent local data
```

Ranking uses estimated profit per mile first, then profit/hour, total profit, total earnings, and a stable alphabetical tie-break. One-company or one-zone days show a helpful `Need 2+` label instead of pretending there is a meaningful worst performer.

Hourly insights are grouped by the local hour of each saved delivery. The visual bars are plain HTML/CSS and are based on real saved delivery totals.


## Phase 8 History, Editing, Undo, and Daily Groups notes

Phase 8 upgrades History into a more complete bookkeeping surface. Deliveries are grouped by local day, and each day group now includes total earnings, estimated profit, total miles, delivery count, average gross $/mile, gross/hour when minutes are available, and tracked time.

Each delivery card now shows:

```text
company/platform
payout
miles
minutes
zone
estimated profit
gross $/mile
source label: Manual, OCR, Calculator, or Import
```

History actions remain local-first and immediately update the Today dashboard, History, and analytics surfaces:

```text
Edit
Duplicate
Delete
Undo delete
```

Editing preserves the delivery ID and original created timestamp while updating `updatedAt`. Duplicating creates a new delivery ID and current timestamp. Deleting removes the item from localStorage and exposes an undo action in the toast.


## Phase 7 Centralized Profit Engine notes

Phase 7 consolidates DriveLedger's profit and efficiency math into a single `ProfitEngine` section in `app.js`. The UI still uses plain HTML, CSS, and JavaScript, but repeated formulas are now routed through reusable calculation helpers.

Centralized helpers cover:

```text
fuel cost per mile
maintenance cost
vehicle cost per mile
estimated delivery profit
estimated profit per mile
gross dollar per mile
gross hourly rate
profit hourly rate
mileage deduction
projected daily earnings
goal ETA
driver score
row/day summaries
```

The Today Command Center, Accept Calculator, manual/quick/OCR previews, history rows, shift recap, and CSV exports now use the same calculation layer. This reduces drift between screens and prevents unsafe output such as `NaN`, `Infinity`, `undefined`, or `null`.

Phase 7 also hardened numeric setting migration so malformed values such as `"NaN"` fall back to defaults instead of becoming `0`. Valid zero values remain allowed where the setting intentionally supports zero.

## Phase 6 Accept / Decline Calculator v2 notes

The Decide tab is now a transparent order decision assistant. It uses the user's local settings for minimum payout, minimum gross $/mile, minimum gross $/hour, maximum distance, gas price, MPG, and maintenance cost per mile.

Inputs:

```text
Company/platform
Offer payout
Miles
Estimated minutes
Zone
Optional note
```

Outputs:

```text
ACCEPT, BORDERLINE, or DECLINE
Gross $/mile
Gross hourly pace
Estimated profit after vehicle costs
Profit $/mile
Profit hourly pace
Pass/fail rule rows for each active threshold
```

Actions:

```text
Calculate Only
Save as Completed
Clear
Copy Decision
```

Saving an offer writes a normalized delivery with `source: "calculator"`, selected company, zone, minutes, optional note, and a decision tag. Invalid offers with missing/zero pay, miles, or minutes are rejected without saving. The calculator intentionally avoids `NaN`, `Infinity`, `undefined`, and `null` output.

Phase 6 also fixed a default-settings normalization issue where missing numeric settings with a zero minimum could be normalized to `0` instead of using the intended defaults.

## Phase 5 OCR review notes

Screenshot scanning is now a review-first workflow. OCR never silently saves a delivery. After a screenshot is selected, DriveLedger shows a processing state and then an editable review card.

The OCR review card includes:

```text
Detected company
Detected earnings
Detected miles
Detected minutes when present
Confidence percentage
Confidence label: High confidence, Medium confidence, or Needs review
Editable company, earnings, miles, and minutes fields
Raw OCR text in an expandable details panel
Save Reviewed
Use in Form
Cancel
Clear Scan
```

If the OCR library is unavailable or Tesseract fails, the app shows a failed scan message and leaves manual entry, Quick Add, and the Accept Calculator usable. Low-confidence scans are labeled clearly and are not saved unless the user corrects the fields and explicitly taps **Save Reviewed**.

## Phase 4 quick-add notes

The Today screen now has a prominent **Quick Add** button that opens a one-hand bottom sheet instead of sending the user to the Add tab. The sheet keeps the command center in context and is optimized for fast delivery entry between orders.

Quick Add supports:

```text
Company
Earnings
Miles
Minutes
Zone
Optional notes
Save
Save + Add Another
Cancel
```

The quick-add flow writes the same normalized delivery records as the full Add tab. A zero-mile value is allowed for quick add when the driver does not yet know mileage, but a blank mileage field is still rejected so accidental saves are avoided.

## Phase 3 command center notes

The Today screen uses real local delivery, shift, and settings data to answer:

```text
How much did I earn today?
What is my estimated profit?
Am I ahead or behind goal?
What is my gross hourly pace?
What is my profit hourly pace?
What is my gross and profit $/mile?
How many business miles and deliveries did I track?
Which company is strongest today?
Which zone is strongest today?
When will I hit my goal at the current pace?
What is my driver score?
```

The command cards intentionally avoid fake charts or fake data. Empty states stay descriptive until real deliveries are saved. All displayed values are guarded against `NaN`, `Infinity`, `undefined`, and `null` in normal startup and smoke-tested flows.

## Phase 2 storage upgrade notes

Delivery records are normalized on app startup and when saved/imported. The current delivery schema includes:

```text
id
date
createdAt
updatedAt
company
earnings
miles
minutes
zone
note
notes
source: manual, ocr, calculator, import
ocrText
ocrConfidence
tags
deleted
version
```

Settings are also normalized and include clearer long-form keys while preserving older aliases used by existing UI code:

```text
dailyGoal
defaultCompany
defaultZone
gasPrice
vehicleMpg / mpg
maintenanceCostPerMile / maintenancePerMile
mileageDeductionRate / taxMileageRate
minimumDollarPerMile / minPerMile
minimumDollarPerHour / minPerHour
minimumPayout / minPayout
maxMiles
theme
appDataVersion
```

Shift data includes:

```text
active
startedAt
endedAt
lastSummary
shiftHistory
appDataVersion
```

On startup, DriveLedger normalizes and re-saves the local state. This gives older saved data the new fields without requiring a backend migration. Corrupted JSON or impossible values are safely defaulted or discarded instead of crashing the app.

## Local data keys

DriveLedger currently uses these localStorage keys:

- `driveledger.deliveries.v1`
- `driveledger.settings.v1`
- `driveledger.shift.v1`
- `driveledger.rollback.v1`

## Run locally

Because this is a static PWA, no backend server is required. Open `index.html` directly for simple testing, or serve the folder with any static server:

```bash
python -m http.server 8000
```

Then open `http://localhost:8000`.

## Install on iPhone/iPad

1. Host the folder with HTTPS, such as Netlify Drop.
2. Open the hosted site in Safari.
3. Tap Share.
4. Tap **Add to Home Screen**.

## Tests

The ZIP includes a no-dependency smoke test suite. It checks static package structure, manifest/icon paths, JavaScript syntax, UI wiring, local storage namespacing, startup behavior in a mocked browser, manual delivery save, quick-add open/save/invalid-save behavior, save-and-add-another, calculator zone/source persistence, OCR review parsing/save/failure behavior, accept-calculator behavior, shift persistence, shift history persistence, local schema migration, service-worker cached asset references, Clipboard API fallback behavior, and command center rendering safety.

```bash
python -m unittest discover -s tests -v
```

Optional Node scripts:

```bash
npm run syntax
npm run smoke
```

## Architecture notes

- There is no FastAPI/backend layer in this ZIP.
- Data is stored locally in browser `localStorage`.
- Screenshot OCR uses Tesseract.js from jsDelivr on first load. If the CDN is unavailable or OCR fails, the app shows a failed scan state and falls back to manual entry.
- Tax and expense numbers are estimates. The mileage rate, gas price, MPG, and maintenance cost are editable in Settings.
- The smoke test is a mocked browser test, not a substitute for manual iPhone/iPad Safari testing.
