#!/usr/bin/env node
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { webcrypto } = require('node:crypto');

const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const appCode = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const idMatches = [...html.matchAll(/\sid=["']([^"']+)["']/g)].map((m) => m[1]);
const tabNames = [...html.matchAll(/data-tab=["']([^"']+)["']/g)].map((m) => m[1]);
const openAddModes = [...html.matchAll(/data-open-add=["']([^"']+)["']/g)].map((m) => m[1]);
const tabJumpNames = [...html.matchAll(/data-tab-jump=["']([^"']+)["']/g)].map((m) => m[1]);
const quickAddOpenIds = [...html.matchAll(/id=["']([^"']+)["'][^>]*data-quick-add-open/g)].map((m) => m[1]);
const quickAddCancelIds = [...html.matchAll(/id=["']([^"']+)["'][^>]*data-quick-add-cancel/g)].map((m) => m[1]);

class MockClassList {
  constructor() { this.values = new Set(); }
  add(...items) { items.forEach((item) => this.values.add(item)); }
  remove(...items) { items.forEach((item) => this.values.delete(item)); }
  contains(item) { return this.values.has(item); }
}

function createElement(id = '') {
  return {
    id,
    value: '',
    textContent: '',
    innerHTML: '',
    dataset: {},
    style: {},
    files: [],
    classList: new MockClassList(),
    listeners: {},
    addEventListener(type, handler) {
      this.listeners[type] ||= [];
      this.listeners[type].push(handler);
    },
    appendChild() {},
    remove() {},
    click() {},
    focus() { document.activeElement = this; },
    blur() { if (document.activeElement === this) document.activeElement = null; },
    setAttribute(name, value) { this[name] = value; },
    removeAttribute(name) { delete this[name]; },
    closest(selector) {
      if (selector === '[data-toast-action]' && this.dataset.toastAction !== undefined) return this;
      return null;
    }
  };
}

function createHarness(seedStorage = {}, options = {}) {
  const downloads = [];
  const elements = new Map();
  for (const id of idMatches) elements.set(id, createElement(id));

  const trendCard = createElement('trend-card');
  const tabButtons = [...new Set(tabNames)].map((tab) => {
    const el = createElement(`tab-btn-${tab}`);
    el.dataset.tab = tab;
    return el;
  });
  const addButtons = [...new Set(openAddModes)].map((mode) => {
    const el = createElement(`open-add-${mode}`);
    el.dataset.openAdd = mode;
    return el;
  });
  const jumpButtons = [...new Set(tabJumpNames)].map((tab) => {
    const el = createElement(`jump-${tab}`);
    el.dataset.tabJump = tab;
    return el;
  });
  const quickOpenButtons = [...new Set(quickAddOpenIds)].map((id) => elements.get(id)).filter(Boolean);
  const quickCancelButtons = [...new Set(quickAddCancelIds)].map((id) => elements.get(id)).filter(Boolean);
  quickCancelButtons.forEach((el) => { el.dataset.quickAddCancel = ''; });
  const screens = [...new Set(tabNames)].map((tab) => elements.get(`tab-${tab}`)).filter(Boolean);

  const storage = new Map(Object.entries(seedStorage));
  global.document = {
    activeElement: null,
    hidden: false,
    body: createElement('body'),
    getElementById(id) { return elements.get(id) || null; },
    querySelector(selector) {
      if (selector === '.trend-card') return trendCard;
      if (selector === 'link[rel="manifest"]') return createElement('manifest-link');
      const tabMatch = selector.match(/^\.tab-btn\[data-tab="(.+)"\]$/);
      if (tabMatch) return tabButtons.find((button) => button.dataset.tab === tabMatch[1]) || null;
      return null;
    },
    querySelectorAll(selector) {
      if (selector === '.tab-btn') return tabButtons;
      if (selector === '[data-open-add]') return addButtons;
      if (selector === '[data-tab-jump]') return jumpButtons;
      if (selector === '[data-quick-add-open]') return quickOpenButtons;
      if (selector === '[data-quick-add-cancel]') return quickCancelButtons;
      if (selector === '.tab-screen') return screens;
      return [];
    },
    createElement(tag) { return createElement(tag); },
    addEventListener() {}
  };
  const document = global.document;

  const context = {
    console: options.console || console,
    document,
    window: { addEventListener() {} },
    navigator: options.navigator || { clipboard: { writeText: async () => {} } },
    location: { protocol: 'http:', hostname: 'localhost' },
    localStorage: {
      getItem(key) { return storage.has(key) ? storage.get(key) : null; },
      setItem(key, value) { storage.set(key, String(value)); }
    },
    confirm: () => true,
    crypto: webcrypto,
    setInterval: () => 1,
    clearInterval: () => {},
    setTimeout: () => 1,
    clearTimeout: () => {},
    URL: {
      createObjectURL: (blob) => { downloads.push(blob); return 'blob:mock'; },
      revokeObjectURL: () => {}
    },
    Blob,
    File: typeof File === 'function' ? File : class File extends Blob { constructor(parts, name, opts) { super(parts, opts); this.name = name; } },
    Intl,
    Date,
    Math,
    Number,
    String,
    RegExp,
    Map,
    Set,
    Array,
    Object,
    JSON,
    Promise,
    Uint8Array,
    Tesseract: options.Tesseract,
    globalThis: null
  };
  context.globalThis = context;
  return { context, elements, storage, downloads };
}

function callFirst(element, type, event = {}) {
  if (!element.listeners[type] || !element.listeners[type].length) throw new Error(`${element.id} has no ${type} listener`);
  return element.listeners[type][0](event);
}

function runStartup(seedStorage) {
  const harness = createHarness(seedStorage);
  vm.runInNewContext(appCode, harness.context, { filename: 'app.js' });

  const form = harness.elements.get('deliveryForm');
  harness.elements.get('companyInput').value = 'DoorDash';
  harness.elements.get('earningsInput').value = '18.75';
  harness.elements.get('milesInput').value = '5.4';
  harness.elements.get('minutesInput').value = '24';
  harness.elements.get('zoneInput').value = 'South City';
  callFirst(form, 'submit', { preventDefault() {} });

  const saved = harness.storage.get('driveledger.deliveries.v1');
  if (!saved || !saved.includes('18.75') || !saved.includes('South City')) {
    throw new Error('manual delivery save did not persist full delivery details to localStorage');
  }
  const firstDelivery = JSON.parse(saved)[0];
  if (firstDelivery.source !== 'manual' || !firstDelivery.updatedAt || !firstDelivery.version) {
    throw new Error('manual delivery did not persist normalized metadata');
  }
  for (const key of ['date', 'note', 'notes', 'tags', 'deleted', 'createdAt', 'updatedAt', 'version']) {
    if (!(key in firstDelivery)) throw new Error(`manual delivery missing normalized ${key} field`);
  }
  if (!harness.elements.get('profitLine').textContent.includes('$17.35')) {
    throw new Error(`central profit engine did not render expected first-delivery profit: ${harness.elements.get('profitLine').textContent}`);
  }
  if (!harness.elements.get('taxDeduction').textContent.includes('$3.62')) {
    throw new Error(`central profit engine did not render expected mileage deduction: ${harness.elements.get('taxDeduction').textContent}`);
  }

  const quickOpen = harness.elements.get('quickAddOpenBtn');
  if (!quickOpen.listeners.click?.length) throw new Error('quick add open button is not wired');
  callFirst(quickOpen, 'click', {});
  if (harness.elements.get('quickAddSheet').classList.contains('hidden')) {
    throw new Error('quick add sheet did not open');
  }
  harness.elements.get('quickEarningsInput').value = '15.25';
  harness.elements.get('quickMilesInput').value = '0';
  harness.elements.get('quickMinutesInput').value = '20';
  harness.elements.get('quickZoneInput').value = 'South City';
  callFirst(harness.elements.get('quickAddForm'), 'submit', { preventDefault() {} });
  const savedAfterQuick = JSON.parse(harness.storage.get('driveledger.deliveries.v1'));
  if (!savedAfterQuick.some((d) => d.earnings === 15.25 && d.miles === 0 && d.zone === 'South City' && d.source === 'manual')) {
    throw new Error('quick add did not persist a zero-mile delivery with metadata');
  }
  if (!harness.elements.get('quickAddSheet').classList.contains('hidden')) {
    throw new Error('quick add sheet did not close after save');
  }
  if (!harness.elements.get('todayEarned').textContent.includes('34.00')) {
    throw new Error('dashboard did not update after quick add save');
  }

  callFirst(quickOpen, 'click', {});
  harness.elements.get('quickEarningsInput').value = '0';
  harness.elements.get('quickMilesInput').value = '2';
  const beforeInvalidQuick = JSON.parse(harness.storage.get('driveledger.deliveries.v1')).length;
  callFirst(harness.elements.get('quickAddForm'), 'submit', { preventDefault() {} });
  const afterInvalidQuick = JSON.parse(harness.storage.get('driveledger.deliveries.v1')).length;
  if (afterInvalidQuick !== beforeInvalidQuick || !harness.elements.get('toast').textContent.includes('earnings')) {
    throw new Error('quick add invalid earnings should be rejected without saving');
  }
  callFirst(harness.elements.get('quickCancelBtn'), 'click', {});

  harness.elements.get('companyInput').value = 'Uber Eats';
  harness.elements.get('earningsInput').value = '11.50';
  harness.elements.get('milesInput').value = '3.1';
  harness.elements.get('minutesInput').value = '18';
  harness.elements.get('zoneInput').value = 'Tower Grove';
  callFirst(harness.elements.get('saveAddAnotherBtn'), 'click', {});
  const afterAddAnother = JSON.parse(harness.storage.get('driveledger.deliveries.v1'));
  if (afterAddAnother.length < 2 || !afterAddAnother.some((d) => d.zone === 'Tower Grove')) {
    throw new Error('save + add another did not persist a second delivery');
  }

  harness.elements.get('offerPayInput').value = '9.75';
  harness.elements.get('offerMilesInput').value = '4.2';
  harness.elements.get('offerMinutesInput').value = '22';
  harness.elements.get('offerZoneInput').value = 'Kirkwood';
  callFirst(harness.elements.get('offerPayInput'), 'input', {});
  if (!harness.elements.get('decisionResult').innerHTML.includes('ACCEPT')) {
    throw new Error('accept calculator did not render an ACCEPT decision for a strong offer');
  }
  callFirst(harness.elements.get('saveOfferAsDeliveryBtn'), 'click', {});
  const savedAfterOffer = JSON.parse(harness.storage.get('driveledger.deliveries.v1'));
  if (savedAfterOffer.length < 3) throw new Error('save offer as delivery did not persist');
  if (!savedAfterOffer.some((d) => d.source === 'calculator' && d.zone === 'Kirkwood')) {
    throw new Error('calculator delivery did not persist source and zone metadata');
  }

  if (!harness.elements.get('heroShiftBtn').listeners.click?.length) {
    throw new Error('hero shift action is not wired');
  }
  callFirst(harness.elements.get('shiftBtn'), 'click', {});
  if (!harness.storage.get('driveledger.shift.v1')?.includes('startedAt')) {
    throw new Error('shift toggle did not persist shift state');
  }
  callFirst(harness.elements.get('shiftBtn'), 'click', {});
  const completedShift = JSON.parse(harness.storage.get('driveledger.shift.v1'));
  if (!Array.isArray(completedShift.shiftHistory) || !completedShift.shiftHistory.length || !completedShift.lastSummary) {
    throw new Error('ending a shift did not persist lastSummary and shiftHistory');
  }

  for (const id of ['projectedTotal', 'goalEta', 'avgDeliveryValue', 'taxMiles', 'vehicleCostToday', 'bestCompanyToday', 'worstCompanyToday', 'bestZoneToday', 'worstZoneToday', 'performanceRecommendation', 'analyticsBestCompany', 'analyticsWorstCompany', 'analyticsBestZone', 'analyticsWorstZone', 'analyticsBestHourToday', 'analyticsWeeklyBestHour', 'analyticsCompanyBreakdown', 'analyticsZoneBreakdown', 'analyticsHourlyBreakdown']) {
    const el = harness.elements.get(id);
    if (!el) throw new Error(`phase 9 command/analytics element missing in smoke harness: ${id}`);
    const rendered = `${el.textContent || ''} ${el.innerHTML || ''}`;
    if (/NaN|Infinity|undefined|null/.test(rendered)) {
      throw new Error(`phase 9 analytics rendered unsafe value in ${id}: ${rendered}`);
    }
  }

  if (!harness.elements.get('bestCompanyToday').textContent || harness.elements.get('bestCompanyToday').textContent === '—') {
    throw new Error('best company command metric did not update after saved deliveries');
  }
  if (!harness.elements.get('bestZoneToday').textContent || harness.elements.get('bestZoneToday').textContent === '—') {
    throw new Error('best zone command metric did not update after saved deliveries');
  }
  if (harness.elements.get('analyticsCompanyBreakdown').className.includes('empty') || !harness.elements.get('analyticsCompanyBreakdown').innerHTML.includes('DoorDash') || !harness.elements.get('analyticsCompanyBreakdown').innerHTML.includes('Uber Eats')) {
    throw new Error('platform analytics should aggregate multiple saved companies');
  }
  if (harness.elements.get('analyticsZoneBreakdown').className.includes('empty') || !harness.elements.get('analyticsZoneBreakdown').innerHTML.includes('South City') || !harness.elements.get('analyticsZoneBreakdown').innerHTML.includes('Kirkwood')) {
    throw new Error('zone analytics should aggregate multiple saved zones');
  }
  if (harness.elements.get('analyticsHourlyBreakdown').className.includes('empty') || !harness.elements.get('analyticsHourlyBreakdown').innerHTML.includes('gross/hr')) {
    throw new Error('hourly analytics should render real saved delivery hour metrics');
  }
}

runStartup({});

function runMigrationSmoke() {
  const legacyDate = new Date().toISOString();
  const legacyDeliveries = [{
    id: 'legacy-1',
    company: 'NotAPlatform',
    earnings: '$22.40',
    miles: '0',
    minutes: 'bad',
    zone: '  South City  ',
    note: 'legacy note',
    createdAt: legacyDate,
    tags: ['Lunch', ' lunch ', '<script>']
  }];
  const legacySettings = {
    dailyGoal: '250',
    defaultCompany: 'BadApp',
    gasPrice: '3.25',
    mpg: '28',
    maintenancePerMile: '0.15',
    taxMileageRate: '0.70',
    minPerMile: '1.75',
    minPerHour: '24',
    minPayout: '8',
    maxMiles: '10',
    theme: 'neon'
  };
  const legacyShift = {
    active: true,
    startedAt: legacyDate,
    lastSummary: 123,
    shiftHistory: [{ startedAt: legacyDate, endedAt: legacyDate, summary: 'old shift' }]
  };
  const harness = createHarness({
    'driveledger.deliveries.v1': JSON.stringify(legacyDeliveries),
    'driveledger.settings.v1': JSON.stringify(legacySettings),
    'driveledger.shift.v1': JSON.stringify(legacyShift)
  });
  vm.runInNewContext(appCode, harness.context, { filename: 'app.js' });
  const migratedDeliveries = JSON.parse(harness.storage.get('driveledger.deliveries.v1'));
  const migratedSettings = JSON.parse(harness.storage.get('driveledger.settings.v1'));
  const migratedShift = JSON.parse(harness.storage.get('driveledger.shift.v1'));

  if (migratedDeliveries.length !== 1) throw new Error('legacy delivery was not preserved during migration');
  const d = migratedDeliveries[0];
  if (d.company !== 'Other' || d.miles !== 0 || d.note !== 'legacy note' || d.notes !== 'legacy note') {
    throw new Error('legacy delivery fields were not normalized safely');
  }
  for (const key of ['date', 'source', 'ocrText', 'ocrConfidence', 'tags', 'deleted', 'version']) {
    if (!(key in d)) throw new Error(`migrated delivery missing ${key}`);
  }
  if (migratedSettings.vehicleMpg !== 28 || migratedSettings.mpg !== 28) {
    throw new Error('settings MPG alias migration failed');
  }
  if (migratedSettings.maintenanceCostPerMile !== 0.15 || migratedSettings.maintenancePerMile !== 0.15) {
    throw new Error('settings maintenance alias migration failed');
  }
  if (migratedSettings.mileageDeductionRate !== 0.7 || migratedSettings.taxMileageRate !== 0.7) {
    throw new Error('settings mileage deduction alias migration failed');
  }
  if (migratedSettings.defaultCompany !== 'DoorDash' || migratedSettings.theme !== 'system' || migratedSettings.appDataVersion !== 5) {
    throw new Error('invalid settings were not defaulted during migration');
  }
  if (!Array.isArray(migratedShift.shiftHistory) || migratedShift.shiftHistory.length !== 1 || migratedShift.appDataVersion !== 5) {
    throw new Error('shift history migration failed');
  }
}


async function runOCRReviewSmoke() {
  const sampleText = 'DoorDash offer Total $14.25 Distance 6.8 miles Estimated time 31 min';
  const harness = createHarness({}, {
    Tesseract: { recognize: async () => ({ data: { text: sampleText } }) }
  });
  vm.runInNewContext(appCode, harness.context, { filename: 'app.js' });

  await callFirst(harness.elements.get('screenshotInput'), 'change', { target: { files: [{ name: 'doordash.png' }] } });
  if (harness.elements.get('ocrReview').classList.contains('hidden')) {
    throw new Error('OCR review card should be visible after successful scan');
  }
  if (!harness.elements.get('ocrCompanyInput').value.includes('DoorDash')) {
    throw new Error('OCR did not parse sample DoorDash company');
  }
  if (harness.elements.get('ocrEarningsInput').value !== '14.25') {
    throw new Error(`OCR did not parse sample earnings: ${harness.elements.get('ocrEarningsInput').value}`);
  }
  if (harness.elements.get('ocrMilesInput').value !== '6.8') {
    throw new Error(`OCR did not parse sample miles: ${harness.elements.get('ocrMilesInput').value}`);
  }
  if (harness.elements.get('ocrMinutesInput').value !== '31') {
    throw new Error(`OCR did not parse sample minutes: ${harness.elements.get('ocrMinutesInput').value}`);
  }
  if (!harness.elements.get('ocrConfidenceLabel').textContent.includes('High confidence')) {
    throw new Error('OCR confidence label should show High confidence for complete sample text');
  }

  const beforeSave = JSON.parse(harness.storage.get('driveledger.deliveries.v1') || '[]').length;
  await callFirst(harness.elements.get('saveOcrBtn'), 'click', {});
  const saved = JSON.parse(harness.storage.get('driveledger.deliveries.v1') || '[]');
  if (saved.length !== beforeSave + 1) throw new Error('saving reviewed OCR did not persist a delivery');
  const ocrDelivery = saved.find((d) => d.source === 'ocr');
  if (!ocrDelivery || ocrDelivery.company !== 'DoorDash' || ocrDelivery.earnings !== 14.25 || ocrDelivery.miles !== 6.8 || ocrDelivery.minutes !== 31 || !ocrDelivery.ocrText) {
    throw new Error('reviewed OCR delivery was not normalized with OCR metadata');
  }

  const lowHarness = createHarness({}, {
    Tesseract: { recognize: async () => ({ data: { text: 'parking garage receipt no pay or miles here' } }) }
  });
  vm.runInNewContext(appCode, lowHarness.context, { filename: 'app.js' });
  await callFirst(lowHarness.elements.get('screenshotInput'), 'change', { target: { files: [{ name: 'low.png' }] } });
  const lowSaved = JSON.parse(lowHarness.storage.get('driveledger.deliveries.v1') || '[]');
  if (lowSaved.length) throw new Error('low-confidence OCR should not autosave');
  if (!lowHarness.elements.get('ocrConfidenceLabel').textContent.includes('Needs review')) {
    throw new Error('low-confidence OCR should be labeled Needs review');
  }
  await callFirst(lowHarness.elements.get('saveOcrBtn'), 'click', {});
  const lowAfterSaveAttempt = JSON.parse(lowHarness.storage.get('driveledger.deliveries.v1') || '[]');
  if (lowAfterSaveAttempt.length) throw new Error('invalid low-confidence OCR fields should be rejected when saving');

  const failHarness = createHarness({}, {
    console: { ...console, error() {} },
    Tesseract: { recognize: async () => { throw new Error('OCR unavailable'); } }
  });
  vm.runInNewContext(appCode, failHarness.context, { filename: 'app.js' });
  await callFirst(failHarness.elements.get('screenshotInput'), 'change', { target: { files: [{ name: 'fail.png' }] } });
  if (!failHarness.elements.get('scanStatus').textContent.includes('Could not scan')) {
    throw new Error('OCR failure should show failed status instead of crashing');
  }
}

function runClipboardUnavailableSmoke() {
  const harness = createHarness({}, { navigator: {} });
  vm.runInNewContext(appCode, harness.context, { filename: 'app.js' });

  const form = harness.elements.get('deliveryForm');
  harness.elements.get('companyInput').value = 'DoorDash';
  harness.elements.get('earningsInput').value = '10.00';
  harness.elements.get('milesInput').value = '2.0';
  callFirst(form, 'submit', { preventDefault() {} });

  callFirst(harness.elements.get('copySummaryBtn'), 'click', {});
  if (!harness.elements.get('toast').textContent.includes('Copy is not available')) {
    throw new Error('copy summary should not claim success when Clipboard API is unavailable');
  }
}


function setOffer(harness, { pay, miles, minutes, company = 'DoorDash', zone = 'South City', note = '' }) {
  harness.elements.get('offerPayInput').value = String(pay ?? '');
  harness.elements.get('offerMilesInput').value = String(miles ?? '');
  harness.elements.get('offerMinutesInput').value = String(minutes ?? '');
  harness.elements.get('offerCompanyInput').value = company;
  harness.elements.get('offerZoneInput').value = zone;
  harness.elements.get('offerNoteInput').value = note;
}

async function runDecisionAssistantSmoke() {
  let copiedDecision = '';
  const harness = createHarness({}, {
    navigator: { clipboard: { writeText: async (text) => { copiedDecision = text; } } }
  });
  vm.runInNewContext(appCode, harness.context, { filename: 'app.js' });

  for (const id of ['calculateOfferBtn', 'clearOfferBtn', 'copyDecisionBtn', 'saveOfferAsDeliveryBtn', 'offerNoteInput']) {
    if (!harness.elements.get(id)) throw new Error(`phase 6 element missing in smoke harness: ${id}`);
  }

  setOffer(harness, { pay: 12, miles: 4, minutes: 20, note: 'Fast restaurant' });
  callFirst(harness.elements.get('calculateOfferBtn'), 'click', {});
  let html = harness.elements.get('decisionResult').innerHTML;
  if (!html.includes('ACCEPT') || !html.includes('Gross $/mile') || !html.includes('Estimated profit') || !html.includes('Pass')) {
    throw new Error('accept calculator did not render transparent ACCEPT decision with threshold rows');
  }
  if (/NaN|Infinity|undefined|null/.test(html)) throw new Error(`accept decision rendered unsafe value: ${html}`);

  await callFirst(harness.elements.get('copyDecisionBtn'), 'click', {});
  if (!copiedDecision.includes('DriveLedger order decision: ACCEPT') || !copiedDecision.includes('Fast restaurant')) {
    throw new Error('copy decision did not include decision summary and note');
  }

  setOffer(harness, { pay: 7.5, miles: 5.2, minutes: 20 });
  callFirst(harness.elements.get('calculateOfferBtn'), 'click', {});
  html = harness.elements.get('decisionResult').innerHTML;
  if (!html.includes('BORDERLINE') || !html.includes('Fail')) {
    throw new Error('borderline calculator case did not render BORDERLINE with a failed rule');
  }
  if (/NaN|Infinity|undefined|null/.test(html)) throw new Error(`borderline decision rendered unsafe value: ${html}`);

  setOffer(harness, { pay: 5, miles: 10, minutes: 45 });
  callFirst(harness.elements.get('calculateOfferBtn'), 'click', {});
  html = harness.elements.get('decisionResult').innerHTML;
  if (!html.includes('DECLINE') || !html.includes('Too weak')) {
    throw new Error('decline calculator case did not render DECLINE with reasons');
  }
  if (/NaN|Infinity|undefined|null/.test(html)) throw new Error(`decline decision rendered unsafe value: ${html}`);

  setOffer(harness, { pay: 0, miles: 0, minutes: 0 });
  const beforeInvalid = JSON.parse(harness.storage.get('driveledger.deliveries.v1') || '[]').length;
  callFirst(harness.elements.get('saveOfferAsDeliveryBtn'), 'click', {});
  const afterInvalid = JSON.parse(harness.storage.get('driveledger.deliveries.v1') || '[]').length;
  html = harness.elements.get('decisionResult').innerHTML;
  if (afterInvalid !== beforeInvalid || !html.includes('Enter a valid offer') || !harness.elements.get('toast').textContent.includes('Enter valid pay')) {
    throw new Error('invalid offer should be rejected without saving');
  }
  if (/NaN|Infinity|undefined|null/.test(html)) throw new Error(`invalid decision rendered unsafe value: ${html}`);

  setOffer(harness, { pay: 13, miles: 4, minutes: 22, company: 'Uber Eats', zone: 'Kirkwood', note: 'Good stack' });
  callFirst(harness.elements.get('saveOfferAsDeliveryBtn'), 'click', {});
  const saved = JSON.parse(harness.storage.get('driveledger.deliveries.v1') || '[]');
  const calculatorDelivery = saved.find((d) => d.source === 'calculator' && d.company === 'Uber Eats' && d.zone === 'Kirkwood');
  if (!calculatorDelivery || calculatorDelivery.notes !== 'Good stack' || !calculatorDelivery.tags.includes('accept')) {
    throw new Error('save offer did not persist calculator source, note, zone, and decision tag');
  }
  if (harness.elements.get('offerPayInput').value || harness.elements.get('offerMilesInput').value || harness.elements.get('offerMinutesInput').value || harness.elements.get('offerNoteInput').value) {
    throw new Error('save offer should clear calculator fields after saving');
  }

  setOffer(harness, { pay: 11, miles: 3, minutes: 18 });
  callFirst(harness.elements.get('clearOfferBtn'), 'click', {});
  if (harness.elements.get('offerPayInput').value || !harness.elements.get('decisionResult').innerHTML.includes('Enter a valid offer')) {
    throw new Error('clear calculator did not reset fields and decision card');
  }

  const strictHarness = createHarness({
    'driveledger.settings.v1': JSON.stringify({ minPerMile: 5, minPerHour: 60, minPayout: 20, maxMiles: 3 })
  });
  vm.runInNewContext(appCode, strictHarness.context, { filename: 'app.js' });
  setOffer(strictHarness, { pay: 12, miles: 4, minutes: 20 });
  callFirst(strictHarness.elements.get('calculateOfferBtn'), 'click', {});
  if (!strictHarness.elements.get('decisionResult').innerHTML.includes('DECLINE')) {
    throw new Error('calculator thresholds from settings did not affect decision result');
  }

  console.log('phase 6 accept calculator cases passed');
}


function clickHistoryAction(harness, dataset) {
  return callFirst(harness.elements.get('historyList'), 'click', {
    target: {
      closest(selector) {
        if (selector === '[data-delete],[data-edit],[data-duplicate],[data-open-add]') return { dataset };
        return null;
      }
    }
  });
}

function runHistoryEditingSmoke() {
  const today = new Date();
  const yesterday = new Date(today.getTime() - 86400000);
  today.setHours(12, 0, 0, 0);
  yesterday.setHours(18, 0, 0, 0);
  const seedDeliveries = [
    {
      id: 'today-1',
      company: 'DoorDash',
      earnings: 18,
      miles: 6,
      minutes: 30,
      zone: 'South City',
      notes: 'Lunch rush',
      source: 'manual',
      createdAt: today.toISOString(),
      updatedAt: today.toISOString(),
      version: 4
    },
    {
      id: 'yesterday-1',
      company: 'Uber Eats',
      earnings: 22,
      miles: 8,
      minutes: 45,
      zone: 'Kirkwood',
      source: 'ocr',
      ocrText: 'sample',
      ocrConfidence: 88,
      createdAt: yesterday.toISOString(),
      updatedAt: yesterday.toISOString(),
      version: 4
    }
  ];
  const harness = createHarness({
    'driveledger.deliveries.v1': JSON.stringify(seedDeliveries)
  });
  vm.runInNewContext(appCode, harness.context, { filename: 'app.js' });

  let historyHtml = harness.elements.get('historyList').innerHTML;
  if (!historyHtml.includes('data-history-day') || !historyHtml.includes('avg $/mile') || !historyHtml.includes('gross/hour')) {
    throw new Error('history should render grouped day summaries with avg $/mile and gross/hour metrics');
  }
  if (!historyHtml.includes('South City') || !historyHtml.includes('30m') || !historyHtml.includes('Manual') || !historyHtml.includes('OCR')) {
    throw new Error('history cards should show zone, minutes, and source labels');
  }

  clickHistoryAction(harness, { edit: 'today-1' });
  if (harness.elements.get('editDeliveryId').value !== 'today-1') {
    throw new Error('edit action did not load selected delivery into the form');
  }
  harness.elements.get('earningsInput').value = '25.50';
  harness.elements.get('milesInput').value = '5.0';
  harness.elements.get('minutesInput').value = '25';
  harness.elements.get('zoneInput').value = 'Downtown';
  callFirst(harness.elements.get('deliveryForm'), 'submit', { preventDefault() {} });
  let saved = JSON.parse(harness.storage.get('driveledger.deliveries.v1'));
  const edited = saved.find((d) => d.id === 'today-1');
  if (!edited || edited.earnings !== 25.5 || edited.miles !== 5 || edited.minutes !== 25 || edited.zone !== 'Downtown') {
    throw new Error('edit action did not update the saved delivery in localStorage');
  }
  if (!harness.elements.get('todayEarned').textContent.includes('25.50')) {
    throw new Error('dashboard did not recalculate after delivery edit');
  }

  clickHistoryAction(harness, { duplicate: 'today-1' });
  saved = JSON.parse(harness.storage.get('driveledger.deliveries.v1'));
  const copies = saved.filter((d) => d.company === 'DoorDash' && d.earnings === 25.5);
  if (copies.length < 2 || new Set(copies.map((d) => d.id)).size !== copies.length) {
    throw new Error('duplicate action should create a separate delivery with a new ID');
  }
  const duplicate = copies.find((d) => d.id !== 'today-1');
  if (!duplicate || duplicate.createdAt === edited.createdAt) {
    throw new Error('duplicate action should use a new current timestamp');
  }

  clickHistoryAction(harness, { delete: 'today-1' });
  saved = JSON.parse(harness.storage.get('driveledger.deliveries.v1'));
  if (saved.some((d) => d.id === 'today-1')) {
    throw new Error('delete action did not remove the selected delivery');
  }
  if (harness.elements.get('todayEarned').textContent.includes('51.00')) {
    throw new Error('dashboard did not recalculate after delete');
  }
  callFirst(harness.elements.get('toast'), 'click', {
    target: { closest: (selector) => selector === '[data-toast-action]' ? {} : null }
  });
  saved = JSON.parse(harness.storage.get('driveledger.deliveries.v1'));
  if (!saved.some((d) => d.id === 'today-1')) {
    throw new Error('undo delete did not restore the selected delivery');
  }
}

function runAnalyticsEmptySmoke() {
  const harness = createHarness({});
  vm.runInNewContext(appCode, harness.context, { filename: 'app.js' });
  for (const id of ['analyticsCompanyBreakdown', 'analyticsZoneBreakdown', 'analyticsHourlyBreakdown']) {
    const el = harness.elements.get(id);
    if (!el.className.includes('empty')) throw new Error(`${id} should render an empty state without crashing`);
    if (/NaN|Infinity|undefined|null/.test(`${el.textContent} ${el.innerHTML}`)) {
      throw new Error(`${id} empty state rendered unsafe text`);
    }
  }
}

async function runExportCenterSmoke() {
  const first = new Date();
  first.setHours(10, 15, 0, 0);
  const second = new Date(first.getTime() - 86400000);
  const seedDeliveries = [
    {
      id: 'export-1',
      company: 'DoorDash',
      earnings: 18.5,
      miles: 6.2,
      minutes: 30,
      zone: 'South City',
      notes: 'Apartment, gate code "1234"\nCustomer tipped after dropoff',
      source: 'manual',
      createdAt: first.toISOString(),
      updatedAt: first.toISOString(),
      version: 4
    },
    {
      id: 'export-2',
      company: 'Uber Eats',
      earnings: 22,
      miles: 8,
      minutes: 42,
      zone: 'Kirkwood',
      notes: 'Lunch order',
      source: 'ocr',
      createdAt: second.toISOString(),
      updatedAt: second.toISOString(),
      version: 4
    }
  ];
  const harness = createHarness({
    'driveledger.deliveries.v1': JSON.stringify(seedDeliveries)
  });
  vm.runInNewContext(appCode, harness.context, { filename: 'app.js' });

  for (const id of ['exportBtn', 'exportTaxBtn', 'exportDailyBtn', 'backupBtn']) {
    if (!harness.elements.get(id).listeners.click?.length) throw new Error(`${id} is not wired in the export center`);
  }

  await callFirst(harness.elements.get('exportBtn'), 'click', {});
  let text = await harness.downloads.at(-1).text();
  if (!text.includes('"date","company","earnings","miles","minutes","zone","note","source"')) {
    throw new Error('standard CSV did not include the expected bookkeeping headers');
  }
  if (!text.includes('"Apartment, gate code ""1234""')) {
    throw new Error('standard CSV did not escape commas and quotes in notes');
  }
  if (!text.includes('Customer tipped after dropoff')) {
    throw new Error('standard CSV did not preserve multiline note content');
  }

  await callFirst(harness.elements.get('exportTaxBtn'), 'click', {});
  text = await harness.downloads.at(-1).text();
  if (!text.includes('"date","company","gross_earnings","business_miles","mileage_deduction_rate","estimated_mileage_deduction","fuel_cost_estimate","maintenance_cost_estimate","estimated_profit"')) {
    throw new Error('tax CSV did not include required tax/export headers');
  }
  if (!text.includes('"0.67"')) throw new Error('tax CSV did not include mileage deduction rate');

  await callFirst(harness.elements.get('exportDailyBtn'), 'click', {});
  text = await harness.downloads.at(-1).text();
  if (!text.includes('"date","total_earnings","estimated_profit","miles","deliveries","average_dollars_per_mile","gross_hour","profit_hour"')) {
    throw new Error('daily summary CSV did not include required summary headers');
  }
  if ((text.match(/\d{4}-\d{2}-\d{2}/g) || []).length < 2) {
    throw new Error('daily summary CSV should group saved deliveries by date');
  }

  await callFirst(harness.elements.get('backupBtn'), 'click', {});
  text = await harness.downloads.at(-1).text();
  const backup = JSON.parse(text);
  if (backup.app !== 'DriveLedger' || !backup.exportedAt || !backup.appDataVersion || !Array.isArray(backup.deliveries) || !backup.settings || !backup.shift) {
    throw new Error('backup JSON did not include required metadata, settings, shift, and deliveries');
  }

  const emptyHarness = createHarness({});
  vm.runInNewContext(appCode, emptyHarness.context, { filename: 'app.js' });
  await callFirst(emptyHarness.elements.get('exportDailyBtn'), 'click', {});
  const emptyText = await emptyHarness.downloads.at(-1).text();
  if (!emptyText.includes('"date","total_earnings"') || !emptyHarness.elements.get('toast').textContent.includes('Header-only')) {
    throw new Error('empty daily CSV export should create a header-only file and explain it');
  }

  console.log('phase 10 export center cases passed');
}

async function runBackupSafetySmoke() {
  const previous = {
    id: 'keep-1',
    company: 'DoorDash',
    earnings: 10,
    miles: 4,
    minutes: 20,
    zone: 'South City',
    source: 'manual',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    version: 4
  };
  const duplicate = { ...previous, earnings: 99 };
  const imported = {
    id: 'new-import-1',
    company: 'Uber Eats',
    earnings: 24.5,
    miles: 8.5,
    minutes: 35,
    zone: 'Kirkwood',
    source: 'manual',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    version: 4
  };
  const backupPayload = {
    app: 'DriveLedger',
    appDataVersion: 5,
    exportedAt: '2026-07-03T12:00:00.000Z',
    deliveries: [duplicate, imported],
    settings: { dailyGoal: 250, defaultCompany: 'Uber Eats', gasPrice: 4.25, vehicleMpg: 20 },
    shift: { active: false, startedAt: null, endedAt: null, lastSummary: 'backup summary', shiftHistory: [] }
  };

  const harness = createHarness({
    'driveledger.deliveries.v1': JSON.stringify([previous]),
    'driveledger.settings.v1': JSON.stringify({ dailyGoal: 175, defaultCompany: 'DoorDash' })
  });
  vm.runInNewContext(appCode, harness.context, { filename: 'app.js' });
  for (const id of ['importInput', 'importPreview', 'importPreviewMeta', 'importModeInput', 'confirmImportBtn', 'cancelImportBtn', 'restoreRollbackBtn']) {
    if (!harness.elements.get(id)) throw new Error(`${id} missing from backup safety UI`);
  }
  await callFirst(harness.elements.get('importInput'), 'change', { target: { files: [{ text: async () => JSON.stringify(backupPayload) }] } });
  if (harness.elements.get('importPreview').classList.contains('hidden')) {
    throw new Error('valid backup import did not render preview');
  }
  if (!harness.elements.get('importPreviewMeta').innerHTML.includes('2') || !harness.elements.get('importPreviewMeta').innerHTML.includes('Included')) {
    throw new Error('import preview did not show delivery/settings/shift metadata');
  }
  harness.elements.get('importModeInput').value = 'merge';
  await callFirst(harness.elements.get('confirmImportBtn'), 'click', {});
  const afterMerge = JSON.parse(harness.storage.get('driveledger.deliveries.v1'));
  if (afterMerge.length !== 2 || !afterMerge.some((d) => d.id === 'new-import-1') || !afterMerge.some((d) => d.id === 'keep-1' && d.earnings === 10)) {
    throw new Error('merge import should add new deliveries and keep existing duplicate IDs');
  }
  if (!harness.elements.get('toast').textContent.includes('skipped 1 duplicates')) {
    throw new Error('merge import should skip duplicate delivery IDs and report it');
  }

  await callFirst(harness.elements.get('importInput'), 'change', { target: { files: [{ text: async () => JSON.stringify(backupPayload) }] } });
  harness.elements.get('importModeInput').value = 'replace';
  await callFirst(harness.elements.get('confirmImportBtn'), 'click', {});
  const afterReplace = JSON.parse(harness.storage.get('driveledger.deliveries.v1'));
  if (afterReplace.length !== 2 || !afterReplace.some((d) => d.id === 'keep-1' && d.earnings === 99)) {
    throw new Error('replace import did not replace current deliveries with backup records');
  }
  if (!harness.storage.get('driveledger.rollback.v1')) {
    throw new Error('replace import did not store rollback');
  }
  await callFirst(harness.elements.get('restoreRollbackBtn'), 'click', {});
  const afterRollback = JSON.parse(harness.storage.get('driveledger.deliveries.v1'));
  if (afterRollback.length !== 2 || !afterRollback.some((d) => d.id === 'new-import-1')) {
    throw new Error('rollback restore did not restore previous data');
  }

  const invalidHarness = createHarness({}, { console: { ...console, error() {} } });
  vm.runInNewContext(appCode, invalidHarness.context, { filename: 'app.js' });
  await callFirst(invalidHarness.elements.get('importInput'), 'change', { target: { files: [{ text: async () => '{not json' }] } });
  if (!invalidHarness.elements.get('toast').textContent.includes('Could not import backup')) {
    throw new Error('invalid backup should be rejected without crashing');
  }
  if (!invalidHarness.elements.get('importPreview').classList.contains('hidden')) {
    throw new Error('invalid backup should not leave import preview open');
  }

  console.log('phase 11 backup safety cases passed');
}


async function runDriverRecapSmoke() {
  const emptyHarness = createHarness({});
  vm.runInNewContext(appCode, emptyHarness.context, { filename: 'app.js' });
  if (!emptyHarness.elements.get('dailySummary').textContent.includes('No shift data yet')) {
    throw new Error('driver recap should render a safe no-data empty state');
  }
  if (!emptyHarness.elements.get('recapStatus').textContent.includes('No data')) {
    throw new Error('driver recap status should show no-data state');
  }

  const first = new Date();
  first.setHours(11, 0, 0, 0);
  const second = new Date();
  second.setHours(13, 30, 0, 0);
  const deliveries = [
    {
      id: 'recap-1',
      company: 'DoorDash',
      earnings: 18,
      miles: 5,
      minutes: 25,
      zone: 'South City',
      source: 'manual',
      createdAt: first.toISOString(),
      updatedAt: first.toISOString(),
      version: 4
    },
    {
      id: 'recap-2',
      company: 'Uber Eats',
      earnings: 7,
      miles: 9,
      minutes: 35,
      zone: 'Downtown',
      source: 'manual',
      createdAt: second.toISOString(),
      updatedAt: second.toISOString(),
      version: 4
    }
  ];
  let copiedText = '';
  const harness = createHarness({
    'driveledger.deliveries.v1': JSON.stringify(deliveries),
    'driveledger.settings.v1': JSON.stringify({ dailyGoal: 40, minPerMile: 1.5, minPerHour: 20 }),
    'driveledger.shift.v1': JSON.stringify({ active: true, startedAt: first.toISOString(), endedAt: null, shiftHistory: [] })
  }, {
    navigator: { clipboard: { writeText: async (text) => { copiedText = text; } } }
  });
  vm.runInNewContext(appCode, harness.context, { filename: 'app.js' });

  const recapHtml = `${harness.elements.get('dailySummary').innerHTML} ${harness.elements.get('recapRecommendation').innerHTML}`;
  for (const token of ['estimated profit', 'Best company', 'Best zone', 'Best delivery', 'Weakest delivery']) {
    if (!recapHtml.includes(token)) throw new Error(`driver recap did not render ${token}`);
  }
  for (const id of ['recapMetrics', 'shiftHistoryList', 'dailyRecapCard']) {
    if (!harness.elements.get(id)) throw new Error(`${id} missing from driver recap UI`);
  }
  if (!harness.elements.get('recapMetrics').innerHTML.includes('gross/hr') || !harness.elements.get('recapMetrics').innerHTML.includes('profit/mi')) {
    throw new Error('recap metrics should include hourly and per-mile metrics');
  }
  if (!harness.elements.get('recapRecommendation').innerHTML.includes('Best platform suggestion') || !harness.elements.get('recapRecommendation').innerHTML.includes('Best zone suggestion')) {
    throw new Error('driver coaching should include platform and zone recommendations');
  }
  if (!harness.elements.get('copySummaryBtn').listeners.click?.length) {
    throw new Error('copy recap button is not wired');
  }
  await callFirst(harness.elements.get('copySummaryBtn'), 'click', {});
  for (const token of ['Gross earnings', 'Estimated profit', 'Hours worked', 'Gross $/mile', 'Profit $/mile', 'Best delivery', 'Weakest delivery', 'Recommendation']) {
    if (!copiedText.includes(token)) throw new Error(`copied daily recap missing ${token}`);
  }

  callFirst(harness.elements.get('shiftBtn'), 'click', {});
  const completedShift = JSON.parse(harness.storage.get('driveledger.shift.v1'));
  const savedRecap = completedShift.shiftHistory.at(-1);
  if (!savedRecap || !savedRecap.summary.includes('Weakest delivery') || !savedRecap.recommendation || !savedRecap.metrics || savedRecap.metrics.orders !== 2) {
    throw new Error('end shift did not generate and save a full driver recap with metrics');
  }
  if (!harness.elements.get('shiftHistoryList').innerHTML.includes('deliveries')) {
    throw new Error('saved shift recap did not render in shift history');
  }

  const oneDeliveryHarness = createHarness({
    'driveledger.deliveries.v1': JSON.stringify([deliveries[0]])
  });
  vm.runInNewContext(appCode, oneDeliveryHarness.context, { filename: 'app.js' });
  if (!oneDeliveryHarness.elements.get('dailySummary').innerHTML.includes('1</strong> delivery')) {
    throw new Error('driver recap should handle exactly one delivery');
  }

  console.log('phase 12 driver coaching recap cases passed');
}


function runMobilePolishSmoke() {
  for (const id of ['mobileActionDock', 'dockQuickAddBtn', 'dockScanBtn', 'dockDecideBtn', 'todayBreakdownsDetails', 'quickAddHint']) {
    if (!idMatches.includes(id)) throw new Error(`${id} missing from phase 13 mobile polish UI`);
  }
  if (!html.includes('class="skip-link"') || !html.includes('aria-modal="true"') || !html.includes('aria-atomic="true"')) {
    throw new Error('phase 13 accessibility landmarks are missing');
  }
  if (!html.includes('id="dockScanBtn"') || !openAddModes.includes('scan')) {
    throw new Error('mobile scan dock action is not represented in data-open-add wiring');
  }
  if (!html.includes('id="dockDecideBtn"') || !tabJumpNames.includes('decide')) {
    throw new Error('mobile decide dock action is not represented in data-tab-jump wiring');
  }
  const harness = createHarness({});
  vm.runInNewContext(appCode, harness.context, { filename: 'app.js' });
  const dockQuick = harness.elements.get('dockQuickAddBtn');
  if (!dockQuick.listeners.click?.length) throw new Error('mobile action dock quick add button is not wired');
  callFirst(dockQuick, 'click', {});
  if (harness.elements.get('quickAddSheet').classList.contains('hidden')) {
    throw new Error('mobile action dock quick add button did not open quick add');
  }
  if (harness.elements.get('quickAddSheet').ariaHidden !== 'false' && harness.elements.get('quickAddSheet')['aria-hidden'] !== 'false') {
    throw new Error('quick add dialog did not update aria-hidden when opened');
  }
  const css = fs.readFileSync(path.join(root, 'styles.css'), 'utf8');
  for (const token of ['mobile-action-dock', 'safe-area-inset-bottom', 'prefers-reduced-motion', 'min-height: 58px', 'loading-state', 'success-state', 'error-state']) {
    if (!css.includes(token)) throw new Error(`phase 13 CSS missing ${token}`);
  }
  console.log('phase 13 mobile polish cases passed');
}

function runPwaOfflinePolishSmoke() {
  const manifest = JSON.parse(fs.readFileSync(path.join(root, 'manifest.json'), 'utf8'));
  const serviceWorker = fs.readFileSync(path.join(root, 'service-worker.js'), 'utf8');
  const css = fs.readFileSync(path.join(root, 'styles.css'), 'utf8');
  if (!manifest.name.includes('Driver Command Center') || manifest.short_name !== 'DriveLedger') {
    throw new Error('manifest should be install-ready with strong name and DriveLedger short name');
  }
  if (manifest.display !== 'standalone' || manifest.start_url !== './' || manifest.scope !== './') {
    throw new Error('manifest install fields are not configured for standalone static hosting');
  }
  for (const icon of manifest.icons || []) {
    if (!fs.existsSync(path.join(root, icon.src))) throw new Error(`manifest icon path missing: ${icon.src}`);
    if (!String(icon.purpose || '').includes('maskable')) throw new Error('manifest icons should include maskable purpose');
  }
  for (const asset of ['./index.html', './styles.css', './app.js', './manifest.json', './icons/icon-192.png', './icons/icon-512.png']) {
    if (!serviceWorker.includes(`"${asset}"`)) throw new Error(`service worker should cache core app shell assets: ${asset}`);
  }
  for (const token of ['CACHE_VERSION = "v18-phase14"', 'OFFLINE_FALLBACK', 'networkFirst', 'staleWhileRevalidate', 'Tesseract CDN']) {
    if (!serviceWorker.includes(token)) throw new Error(`service worker missing PWA offline token: ${token}`);
  }
  if (!html.includes('id="offlineBanner"') || !css.includes('offline-banner')) {
    throw new Error('offline banner UI/style missing');
  }
  const harness = createHarness({}, { navigator: { clipboard: { writeText: async () => {} }, onLine: false } });
  vm.runInNewContext(appCode, harness.context, { filename: 'app.js' });
  if (harness.elements.get('offlineBanner').classList.contains('hidden')) {
    throw new Error('offline banner should appear when navigator.onLine is false');
  }
  if (!harness.elements.get('offlineBanner').textContent.includes('OCR may need internet')) {
    throw new Error('offline banner should explain OCR online dependency');
  }
  console.log('phase 14 PWA install and offline polish cases passed');
}

async function main() {
  runStartup({
    'driveledger.deliveries.v1': '{"not":"an array"}',
    'driveledger.settings.v1': '{"dailyGoal":"bad","defaultCompany":"Unknown","gasPrice":"NaN"}',
    'driveledger.shift.v1': '{"active":true,"startedAt":"not a date"}'
  });
  runClipboardUnavailableSmoke();
  runMigrationSmoke();
  runHistoryEditingSmoke();
  runAnalyticsEmptySmoke();
  await runExportCenterSmoke();
  await runBackupSafetySmoke();
  await runDecisionAssistantSmoke();
  await runOCRReviewSmoke();
  await runDriverRecapSmoke();
  runMobilePolishSmoke();
  runPwaOfflinePolishSmoke();
  console.log('DriveLedger startup smoke test passed');
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
