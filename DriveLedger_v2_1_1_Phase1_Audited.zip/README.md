# DriveLedger

DriveLedger is a local-first Progressive Web App for gig delivery drivers. It tracks daily earnings, mileage, estimated profit, tax mileage deduction, platform performance, zone performance, shift pace, screenshot OCR-assisted entry, and accept/decline order decisions.

## Current release

Version: `2.1.1` Phase 1 audit/stabilization release.

This release preserves the static PWA architecture. There is no backend, database server, framework, build step, or account system. The app runs from plain static files and stores user data locally in the browser.

## Included features

- Today Command Center with gross earnings, estimated profit, hourly pace, $/mile, tax deduction, shift status, driver score, and goal ETA.
- Profit Mode using editable gas price, MPG, maintenance cost per mile, and mileage deduction rate.
- Accept Calculator that recommends **ACCEPT**, **BORDERLINE**, or **DECLINE** using user-defined minimum payout, $/mile, $/hour, and max-mile rules.
- Accept Calculator zone capture so saved calculator deliveries contribute to zone analytics.
- Screenshot OCR review card with detected company, earnings, miles, and confidence before applying values.
- Fast manual delivery entry with optional minutes, zone, notes, and **Save + Add Another** support.
- Delivery edit, duplicate, delete, and undo-delete support.
- Grouped History by day with daily totals, per-delivery profit details, and source labels.
- Company and zone performance breakdowns.
- Daily shift summary with copy support.
- Standard CSV export, tax CSV export, JSON backup, JSON import, and pre-import rollback restore.
- Local-first storage using browser `localStorage` under `driveledger.*` keys.

## Phase 1 stabilization notes

The v2.1.1 pass focused on audit coverage and bug hardening rather than new product features. It fixed false-positive summary copy feedback when the Clipboard API is unavailable, expanded service worker cached-asset validation, and tightened event-wiring smoke coverage.

## Local data keys

DriveLedger currently uses these localStorage keys:

- `driveledger.deliveries.v1`
- `driveledger.settings.v1`
- `driveledger.shift.v1`
- `driveledger.rollback.v1`

Delivery records are normalized on load and include metadata fields such as `source`, `ocrConfidence`, `createdAt`, `updatedAt`, and `version` when saved by this release.

## Run locally

Because this is a static PWA, no backend server is required. Open `index.html` directly for simple testing, or serve the folder with any static server:

```bash
python -m http.server 8000
```

Then open `http://localhost:8000`.

## Install on iPhone/iPad

1. Host the folder with HTTPS, such as Netlify Drop.
2. Open the hosted site in Safari.
3. Tap Share.
4. Tap **Add to Home Screen**.

## Tests

The ZIP includes a no-dependency smoke test suite. It checks static package structure, manifest/icon paths, JavaScript syntax, UI wiring, local storage namespacing, startup behavior in a mocked browser, manual delivery save, save-and-add-another, calculator zone/source persistence, accept-calculator behavior, shift persistence, service-worker cached asset references, and Clipboard API fallback behavior.

```bash
python -m unittest discover -s tests -v
```

Optional Node scripts:

```bash
npm run syntax
npm run smoke
```

## Architecture notes

- There is no FastAPI/backend layer in this ZIP.
- Data is stored locally in browser `localStorage`.
- Screenshot OCR uses Tesseract.js from jsDelivr on first load. If the CDN is unavailable, the app falls back to manual entry.
- Tax and expense numbers are estimates. The mileage rate, gas price, MPG, and maintenance cost are editable in Settings.
- The smoke test is a mocked browser test, not a substitute for manual iPhone/iPad Safari testing.
