(() => {
  const STORE_KEY = "driveledger.deliveries.v1";
  const SETTINGS_KEY = "driveledger.settings.v1";
  const SHIFT_KEY = "driveledger.shift.v1";
  const ROLLBACK_KEY = "driveledger.rollback.v1";
  const DATA_VERSION = 3;
  const BACKUP_VERSION = 3;

  const money = new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" });
  const $ = (id) => document.getElementById(id);

  const allowedCompanies = new Set([
    "DoorDash",
    "Uber Eats",
    "Grubhub",
    "Catering",
    "Instacart",
    "Spark",
    "Roadie",
    "Other"
  ]);

  const validSources = new Set(["manual", "ocr", "calculator", "import"]);

  const defaultSettings = {
    dailyGoal: 200,
    defaultCompany: "DoorDash",
    gasPrice: 3.5,
    mpg: 25,
    maintenancePerMile: 0.12,
    taxMileageRate: 0.67,
    minPerMile: 1.5,
    minPerHour: 20,
    minPayout: 7,
    maxMiles: 12,
    defaultZone: ""
  };

  let deliveries = normalizeDeliveries(readJSON(STORE_KEY, []));
  let settings = normalizeSettings(readJSON(SETTINGS_KEY, {}));
  let shift = normalizeShift(readJSON(SHIFT_KEY, { active: false, startedAt: null, endedAt: null }));
  let lastOCRText = "";
  let lastOCRParsed = null;
  let lastDayKey = todayKey();
  let toastTimer = null;
  let lastDeleted = null;
  let toastAction = null;

  const els = {
    todayHero: $("todayHero"),
    todayEarned: $("todayEarned"),
    profitLine: $("profitLine"),
    goalPercent: $("goalPercent"),
    goalBar: $("goalBar"),
    goalText: $("goalText"),
    goalRemaining: $("goalRemaining"),
    shiftStatus: $("shiftStatus"),
    profitToday: $("profitToday"),
    profitHour: $("profitHour"),
    avgHour: $("avgHour"),
    avgMile: $("avgMile"),
    profitMile: $("profitMile"),
    taxDeduction: $("taxDeduction"),
    ordersCount: $("ordersCount"),
    milesToday: $("milesToday"),
    timeWorking: $("timeWorking"),
    driverScore: $("driverScore"),
    driverScoreTitle: $("driverScoreTitle"),
    driverScoreDetail: $("driverScoreDetail"),
    trendTitle: $("trendTitle"),
    trendDetail: $("trendDetail"),
    trendCard: document.querySelector(".trend-card"),
    dailySummary: $("dailySummary"),
    companyBreakdown: $("companyBreakdown"),
    zoneBreakdown: $("zoneBreakdown"),
    historyList: $("historyList"),
    goalInput: $("goalInput"),
    defaultCompanyInput: $("defaultCompanyInput"),
    gasPriceInput: $("gasPriceInput"),
    mpgInput: $("mpgInput"),
    maintenanceInput: $("maintenanceInput"),
    taxRateInput: $("taxRateInput"),
    minPerMileInput: $("minPerMileInput"),
    minPerHourInput: $("minPerHourInput"),
    minPayoutInput: $("minPayoutInput"),
    maxMilesInput: $("maxMilesInput"),
    defaultZoneInput: $("defaultZoneInput"),
    editDeliveryId: $("editDeliveryId"),
    companyInput: $("companyInput"),
    earningsInput: $("earningsInput"),
    milesInput: $("milesInput"),
    minutesInput: $("minutesInput"),
    zoneInput: $("zoneInput"),
    notesInput: $("notesInput"),
    deliveryPreview: $("deliveryPreview"),
    saveDeliveryBtn: $("saveDeliveryBtn"),
    saveAddAnotherBtn: $("saveAddAnotherBtn"),
    cancelEditBtn: $("cancelEditBtn"),
    screenshotInput: $("screenshotInput"),
    previewImage: $("previewImage"),
    scanStatus: $("scanStatus"),
    ocrReview: $("ocrReview"),
    ocrCompany: $("ocrCompany"),
    ocrEarnings: $("ocrEarnings"),
    ocrMiles: $("ocrMiles"),
    ocrConfidence: $("ocrConfidence"),
    applyOcrBtn: $("applyOcrBtn"),
    clearOcrBtn: $("clearOcrBtn"),
    ocrDetails: $("ocrDetails"),
    ocrText: $("ocrText"),
    offerPayInput: $("offerPayInput"),
    offerMilesInput: $("offerMilesInput"),
    offerMinutesInput: $("offerMinutesInput"),
    offerCompanyInput: $("offerCompanyInput"),
    offerZoneInput: $("offerZoneInput"),
    decisionResult: $("decisionResult"),
    saveOfferAsDeliveryBtn: $("saveOfferAsDeliveryBtn"),
    shiftBtn: $("shiftBtn"),
    exportBtn: $("exportBtn"),
    exportTaxBtn: $("exportTaxBtn"),
    backupBtn: $("backupBtn"),
    restoreRollbackBtn: $("restoreRollbackBtn"),
    importInput: $("importInput"),
    copySummaryBtn: $("copySummaryBtn"),
    saveSettingsBtn: $("saveSettingsBtn"),
    clearTodayBtn: $("clearTodayBtn"),
    toast: $("toast")
  };

  function readJSON(key, fallback) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch {
      return fallback;
    }
  }

  function writeJSON(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch {
      toast("Could not save. Device storage may be full or blocked.");
    }
  }

  function normalizeDeliveries(value) {
    if (!Array.isArray(value)) return [];
    return value.map((item) => normalizeDelivery(item)).filter(Boolean);
  }

  function normalizeDelivery(item) {
    if (!item || typeof item !== "object") return null;
    const earnings = round2(num(item.earnings));
    const miles = round1(num(item.miles));
    const createdRaw = item.createdAt || item.date || item.timestamp;
    const createdAt = new Date(createdRaw);
    const updatedAt = item.updatedAt && !Number.isNaN(new Date(item.updatedAt).getTime())
      ? new Date(item.updatedAt)
      : createdAt;
    if (!earnings || earnings <= 0 || earnings > 10000) return null;
    if (!miles || miles <= 0 || miles > 1000) return null;
    if (Number.isNaN(createdAt.getTime())) return null;
    const company = allowedCompanies.has(item.company) ? item.company : "Other";
    const minutesRaw = num(item.minutes);
    const inferredSource = item.ocrText ? "ocr" : "manual";
    const source = validSources.has(item.source) ? item.source : inferredSource;
    return {
      id: String(item.id || makeId()),
      company,
      earnings,
      miles,
      minutes: minutesRaw > 0 && minutesRaw <= 1440 ? round1(minutesRaw) : 0,
      zone: cleanText(item.zone || "", 80),
      notes: cleanText(item.notes || "", 500),
      source,
      ocrText: cleanText(item.ocrText || "", 20000),
      ocrConfidence: bounded(item.ocrConfidence, 0, 100, 0, 1),
      createdAt: createdAt.toISOString(),
      updatedAt: updatedAt.toISOString(),
      version: Number.isFinite(Number(item.version)) ? Number(item.version) : DATA_VERSION
    };
  }

  function normalizeSettings(value) {
    const raw = value && typeof value === "object" ? value : {};
    return {
      dailyGoal: bounded(raw.dailyGoal, 1, 100000, defaultSettings.dailyGoal, 2),
      defaultCompany: allowedCompanies.has(raw.defaultCompany) ? raw.defaultCompany : defaultSettings.defaultCompany,
      gasPrice: bounded(raw.gasPrice, 0, 20, defaultSettings.gasPrice, 2),
      mpg: bounded(raw.mpg, 1, 200, defaultSettings.mpg, 1),
      maintenancePerMile: bounded(raw.maintenancePerMile, 0, 10, defaultSettings.maintenancePerMile, 2),
      taxMileageRate: bounded(raw.taxMileageRate, 0, 10, defaultSettings.taxMileageRate, 2),
      minPerMile: bounded(raw.minPerMile, 0, 50, defaultSettings.minPerMile, 2),
      minPerHour: bounded(raw.minPerHour, 0, 500, defaultSettings.minPerHour, 2),
      minPayout: bounded(raw.minPayout, 0, 500, defaultSettings.minPayout, 2),
      maxMiles: bounded(raw.maxMiles, 0, 1000, defaultSettings.maxMiles, 1),
      defaultZone: cleanText(raw.defaultZone || "", 80)
    };
  }

  function normalizeShift(value) {
    const raw = value && typeof value === "object" ? value : {};
    const startedAt = raw.startedAt && !Number.isNaN(new Date(raw.startedAt).getTime()) ? new Date(raw.startedAt).toISOString() : null;
    const endedAt = raw.endedAt && !Number.isNaN(new Date(raw.endedAt).getTime()) ? new Date(raw.endedAt).toISOString() : null;
    return {
      active: Boolean(raw.active && startedAt),
      startedAt,
      endedAt
    };
  }

  function cleanText(value, maxLength) {
    return String(value ?? "").replace(/[\u0000-\u001f\u007f]/g, " ").trim().slice(0, maxLength);
  }

  function bounded(value, min, max, fallback, decimals = 2) {
    const parsed = num(value);
    if (!Number.isFinite(parsed) || parsed < min || parsed > max) return fallback;
    return decimals === 1 ? round1(parsed) : round2(parsed);
  }

  function todayKey(date = new Date()) {
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, "0");
    const d = String(date.getDate()).padStart(2, "0");
    return `${y}-${m}-${d}`;
  }

  function isToday(value) {
    const date = new Date(value);
    return !Number.isNaN(date.getTime()) && todayKey(date) === todayKey();
  }

  function num(value) {
    let s = String(value ?? "").trim().replace(/[^0-9.,-]/g, "");
    if (!s || s === "-" || s === "." || s === ",") return 0;
    const isNegative = s.startsWith("-");
    s = s.replace(/-/g, "");
    const lastComma = s.lastIndexOf(",");
    const lastDot = s.lastIndexOf(".");
    if (lastComma > -1 && lastDot > -1) {
      if (lastComma > lastDot) s = s.replace(/\./g, "").replace(/,/g, ".");
      else s = s.replace(/,/g, "");
    } else if (lastComma > -1) {
      const parts = s.split(",");
      s = parts.length === 2 && parts[1].length !== 3 ? s.replace(",", ".") : s.replace(/,/g, "");
    }
    const parsed = Number.parseFloat(s);
    return Number.isFinite(parsed) ? (isNegative ? -parsed : parsed) : 0;
  }

  function todayDeliveries() {
    return deliveries
      .filter((d) => isToday(d.createdAt))
      .sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
  }

  function getWorkWindow(todays) {
    let start = null;
    if (shift.startedAt && isToday(shift.startedAt)) start = new Date(shift.startedAt);
    else if (todays.length) start = new Date(todays[0].createdAt);
    if (!start) return null;

    let end = new Date();
    if (!shift.active && shift.endedAt && isToday(shift.endedAt)) {
      const ended = new Date(shift.endedAt);
      if (ended > start) end = ended;
    }
    if (todays.length) {
      const lastDelivery = new Date(todays[todays.length - 1].createdAt);
      if (lastDelivery > end) end = lastDelivery;
    }
    return { start, end };
  }

  function costPerMile() {
    const fuel = settings.mpg ? settings.gasPrice / settings.mpg : 0;
    return Math.max(0, fuel + settings.maintenancePerMile);
  }

  function deliveryProfit(delivery) {
    const earnings = Number(delivery.earnings || 0);
    const miles = Number(delivery.miles || 0);
    return round2(earnings - miles * costPerMile());
  }

  function calculate(rows) {
    const earnings = rows.reduce((sum, d) => sum + Number(d.earnings || 0), 0);
    const miles = rows.reduce((sum, d) => sum + Number(d.miles || 0), 0);
    const minutes = rows.reduce((sum, d) => sum + Number(d.minutes || 0), 0);
    const orders = rows.length;
    const expenses = miles * costPerMile();
    const profit = earnings - expenses;
    const taxDeduction = miles * Number(settings.taxMileageRate || 0);
    const avgOrder = orders ? earnings / orders : 0;
    const avgMile = miles ? earnings / miles : 0;
    const profitMile = miles ? profit / miles : 0;
    const window = getWorkWindow(rows);
    const hours = window ? Math.max((window.end - window.start) / 36e5, 1 / 60) : (minutes ? minutes / 60 : 0);
    const avgHour = hours ? earnings / hours : 0;
    const profitHour = hours ? profit / hours : 0;
    return { earnings, miles, orders, avgOrder, avgMile, profitMile, avgHour, profitHour, hours, profit, expenses, taxDeduction, minutes };
  }

  function render() {
    const todays = todayDeliveries();
    const c = calculate(todays);
    const goal = Number(settings.dailyGoal || 0);
    const pct = goal ? Math.min((c.earnings / goal) * 100, 999) : 0;
    const remaining = Math.max(goal - c.earnings, 0);
    const score = driverScore(c);

    els.todayEarned.textContent = money.format(c.earnings);
    els.profitLine.textContent = `Estimated profit ${money.format(c.profit)}`;
    els.goalPercent.textContent = `${Math.round(Math.min(pct, 100))}%`;
    els.goalBar.style.width = `${Math.min(pct, 100)}%`;
    els.goalText.textContent = money.format(goal);
    els.shiftStatus.textContent = shiftStatusText(c.hours);
    els.goalRemaining.textContent = buildGoalInsight(c, goal, remaining);

    els.profitToday.textContent = money.format(c.profit);
    els.profitHour.textContent = money.format(c.profitHour);
    els.avgHour.textContent = money.format(c.avgHour);
    els.avgMile.textContent = money.format(c.avgMile);
    els.profitMile.textContent = money.format(c.profitMile);
    els.taxDeduction.textContent = money.format(c.taxDeduction);
    els.ordersCount.textContent = String(c.orders);
    els.milesToday.textContent = c.miles.toFixed(1);
    els.timeWorking.textContent = formatHours(c.hours);

    els.driverScore.textContent = String(score.value);
    els.driverScoreTitle.textContent = score.title;
    els.driverScoreDetail.textContent = score.detail;
    renderHeroStatus(score.value, pct);
    renderTrend(todays);
    renderDailySummary(todays, c);
    renderBreakdown(els.companyBreakdown, todays, "company");
    renderBreakdown(els.zoneBreakdown, todays, "zone");
    renderHistory();
    renderSettings();
    renderShiftButton();
    renderDeliveryPreview();
    renderDecision();
  }

  function renderLive() {
    const todays = todayDeliveries();
    const c = calculate(todays);
    els.avgHour.textContent = money.format(c.avgHour);
    els.profitHour.textContent = money.format(c.profitHour);
    els.timeWorking.textContent = formatHours(c.hours);
    els.shiftStatus.textContent = shiftStatusText(c.hours);
    els.goalRemaining.textContent = buildGoalInsight(c, settings.dailyGoal, Math.max(settings.dailyGoal - c.earnings, 0));
  }

  function renderHeroStatus(score, pct) {
    els.todayHero.classList.remove("status-good", "status-warning", "status-danger", "status-neutral");
    if (!todayDeliveries().length) els.todayHero.classList.add("status-neutral");
    else if (pct >= 100 || score >= 75) els.todayHero.classList.add("status-good");
    else if (score >= 50) els.todayHero.classList.add("status-warning");
    else els.todayHero.classList.add("status-danger");
  }

  function buildGoalInsight(c, goal, remaining) {
    if (!goal) return "Set a daily goal in Settings.";
    if (!c.orders) return "Add your first delivery to start tracking pay, miles, profit, and pace.";
    if (remaining <= 0) return `Goal hit. You're ${money.format(c.earnings - goal)} over target.`;
    if (c.avgHour > 0) {
      const hoursNeeded = remaining / c.avgHour;
      const eta = new Date(Date.now() + hoursNeeded * 36e5);
      return `${money.format(remaining)} left. At this pace, you hit goal around ${eta.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}.`;
    }
    return `${money.format(remaining)} left to hit today's goal.`;
  }

  function shiftStatusText(hours) {
    if (shift.active && shift.startedAt && isToday(shift.startedAt)) return `Shift active · ${formatHours(hours)}`;
    if (shift.endedAt && isToday(shift.endedAt)) return `Shift ended · ${formatHours(hours)}`;
    return "No active shift";
  }

  function driverScore(c) {
    if (!c.orders) return { value: 0, title: "No score yet", detail: "Start a shift and save deliveries to get live feedback." };
    let score = 50;
    if (settings.minPerMile) score += clamp(((c.avgMile / settings.minPerMile) - 1) * 25, -20, 25);
    if (settings.minPerHour) score += clamp(((c.avgHour / settings.minPerHour) - 1) * 25, -20, 25);
    if (c.profit > 0) score += 10;
    if (c.profitMile >= 1) score += 8;
    if (c.orders >= 3) score += 5;
    score = Math.round(clamp(score, 0, 100));

    let title = "Solid shift";
    let detail = `${money.format(c.avgMile)}/mile gross and ${money.format(c.profitHour)}/hour estimated profit.`;
    if (score >= 85) {
      title = "Excellent pace";
      detail = `Strong efficiency: ${money.format(c.avgMile)}/mile gross, ${money.format(c.profitMile)}/mile profit.`;
    } else if (score >= 70) {
      title = "Good money day";
      detail = `You are above most minimums. Keep avoiding low-mileage-profit orders.`;
    } else if (score >= 45) {
      title = "Watch the order quality";
      detail = `You are close, but some orders may be pulling down hourly pace or $/mile.`;
    } else {
      title = "Needs improvement";
      detail = `Current pace is below your targets. Use the Accept calculator before taking similar orders.`;
    }
    return { value: score, title, detail };
  }

  function formatHours(hours) {
    if (!hours) return "0h 00m";
    const totalMinutes = Math.max(0, Math.round(hours * 60));
    const h = Math.floor(totalMinutes / 60);
    const m = totalMinutes % 60;
    return `${h}h ${String(m).padStart(2, "0")}m`;
  }

  function renderTrend(todays) {
    els.trendCard.classList.remove("trend-up", "trend-down");
    if (todays.length === 0) {
      els.trendTitle.textContent = "No deliveries yet";
      els.trendDetail.textContent = "After each delivery, DriveLedger shows whether that delivery helped or hurt your average.";
      return;
    }
    const last = todays[todays.length - 1];
    const lastEarnings = Number(last.earnings || 0);
    const lastMiles = Number(last.miles || 0);
    const perMile = lastMiles ? lastEarnings / lastMiles : 0;
    const profit = deliveryProfit(last);
    const before = todays.slice(0, -1);
    if (!before.length) {
      els.trendTitle.textContent = `${money.format(lastEarnings)} first delivery`;
      els.trendDetail.textContent = `${last.company} · ${lastMiles.toFixed(1)} mi · ${money.format(perMile)}/mi gross · ${money.format(profit)} profit.`;
      return;
    }
    const beforeAvg = before.reduce((s, d) => s + Number(d.earnings || 0), 0) / before.length;
    const afterAvg = todays.reduce((s, d) => s + Number(d.earnings || 0), 0) / todays.length;
    const diff = afterAvg - beforeAvg;
    const helped = diff >= 0 && perMile >= settings.minPerMile;
    els.trendCard.classList.add(helped ? "trend-up" : "trend-down");
    els.trendTitle.textContent = helped ? "Last delivery helped your day" : "Last delivery hurt your average";
    els.trendDetail.textContent = `${last.company}: ${money.format(lastEarnings)}, ${lastMiles.toFixed(1)} mi, ${money.format(perMile)}/mi, ${money.format(profit)} estimated profit. Average delivery changed by ${money.format(diff)}.`;
  }

  function renderDailySummary(todays, c) {
    if (!todays.length) {
      els.dailySummary.textContent = "No shift data yet.";
      return;
    }
    const best = bestDelivery(todays);
    const weak = weakestDelivery(todays);
    const bestCompany = bestGroup(todays, "company");
    const recommendation = c.avgMile < settings.minPerMile
      ? `Recommendation: avoid orders below ${money.format(settings.minPerMile)}/mile.`
      : `Recommendation: keep prioritizing ${bestCompany?.name || "your strongest platform"}.`;
    els.dailySummary.innerHTML = `
      <p>You earned <strong>${money.format(c.earnings)}</strong> today with <strong>${money.format(c.profit)}</strong> estimated profit.</p>
      <p>${c.orders} ${c.orders === 1 ? "delivery" : "deliveries"} · ${c.miles.toFixed(1)} miles · ${money.format(c.avgHour)}/hr gross · ${money.format(c.profitHour)}/hr profit.</p>
      <p>Best delivery: ${best ? `${money.format(best.earnings)} for ${Number(best.miles).toFixed(1)} mi` : "—"}. Weakest delivery: ${weak ? `${money.format(weak.earnings)} for ${Number(weak.miles).toFixed(1)} mi` : "—"}.</p>
      <p>${escapeHTML(recommendation)}</p>
    `;
  }

  function bestDelivery(rows) {
    return [...rows].sort((a, b) => (Number(b.earnings) / Number(b.miles)) - (Number(a.earnings) / Number(a.miles)))[0] || null;
  }

  function weakestDelivery(rows) {
    return [...rows].sort((a, b) => (Number(a.earnings) / Number(a.miles)) - (Number(b.earnings) / Number(b.miles)))[0] || null;
  }

  function bestGroup(rows, key) {
    const grouped = groupRows(rows, key);
    return [...grouped.entries()]
      .map(([name, row]) => ({ name, ...row, avgHour: row.minutes ? row.earnings / (row.minutes / 60) : 0 }))
      .sort((a, b) => (b.miles ? b.earnings / b.miles : 0) - (a.miles ? a.earnings / a.miles : 0))[0] || null;
  }

  function groupRows(rows, key) {
    const grouped = new Map();
    for (const d of rows) {
      const name = key === "zone" ? (d.zone || "Unassigned") : d.company;
      const row = grouped.get(name) || { earnings: 0, miles: 0, count: 0, profit: 0, minutes: 0 };
      row.earnings += Number(d.earnings || 0);
      row.miles += Number(d.miles || 0);
      row.count += 1;
      row.profit += deliveryProfit(d);
      row.minutes += Number(d.minutes || 0);
      grouped.set(name, row);
    }
    return grouped;
  }

  function renderBreakdown(target, rows, key) {
    if (!rows.length) {
      target.className = "breakdown empty";
      target.textContent = key === "zone" ? "No zone data yet." : "No company data yet.";
      return;
    }
    target.className = "breakdown";
    const grouped = groupRows(rows, key);
    target.innerHTML = [...grouped.entries()]
      .sort((a, b) => b[1].profit - a[1].profit)
      .map(([name, row]) => `
        <div class="breakdown-item">
          <div class="breakdown-top"><span>${escapeHTML(name)}</span><strong>${money.format(row.earnings)}</strong></div>
          <div class="breakdown-meta">${row.count} ${row.count === 1 ? "delivery" : "deliveries"} · ${row.miles.toFixed(1)} mi · ${money.format(row.miles ? row.earnings / row.miles : 0)}/mi · ${money.format(row.profit)} profit</div>
        </div>
      `).join("");
  }

  function renderHistory() {
    if (!deliveries.length) {
      els.historyList.className = "history-list empty";
      els.historyList.innerHTML = `No deliveries yet.<br><button class="primary-btn compact empty-action" data-open-add="manual" type="button">Add your first delivery</button>`;
      return;
    }
    els.historyList.className = "history-list";
    const grouped = new Map();
    for (const d of [...deliveries].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))) {
      const key = todayKey(new Date(d.createdAt));
      if (!grouped.has(key)) grouped.set(key, []);
      grouped.get(key).push(d);
    }
    els.historyList.innerHTML = [...grouped.entries()].map(([dateKey, rows]) => {
      const c = calculateForDay(rows);
      const title = dateLabel(dateKey);
      return `
        <section class="history-day">
          <div class="day-summary">
            <div><strong>${escapeHTML(title)}</strong><span>${rows.length} ${rows.length === 1 ? "delivery" : "deliveries"} · ${c.miles.toFixed(1)} mi</span></div>
            <div><strong>${money.format(c.earnings)}</strong><span>${money.format(c.profit)} profit</span></div>
          </div>
          ${rows.map((d) => renderHistoryItem(d)).join("")}
        </section>
      `;
    }).join("");
  }

  function calculateForDay(rows) {
    const earnings = rows.reduce((sum, d) => sum + Number(d.earnings || 0), 0);
    const miles = rows.reduce((sum, d) => sum + Number(d.miles || 0), 0);
    const profit = rows.reduce((sum, d) => sum + deliveryProfit(d), 0);
    return { earnings, miles, profit };
  }

  function renderHistoryItem(d) {
    const earnings = Number(d.earnings || 0);
    const miles = Number(d.miles || 0);
    const perMile = miles ? earnings / miles : 0;
    const profit = deliveryProfit(d);
    const date = new Date(d.createdAt).toLocaleString([], { hour: "numeric", minute: "2-digit" });
    return `
      <article class="history-item">
        <div class="history-top"><span>${escapeHTML(d.company)}</span><strong>${money.format(earnings)}</strong></div>
        <div class="history-meta">${miles.toFixed(1)} mi · ${money.format(perMile)}/mi · ${money.format(profit)} profit · ${date}${d.minutes ? ` · ${d.minutes} min` : ""} · <span class="source-pill">${escapeHTML(sourceLabel(d.source))}</span></div>
        ${d.zone ? `<div class="history-meta">Zone: ${escapeHTML(d.zone)}</div>` : ""}
        ${d.notes ? `<div class="history-meta">${escapeHTML(d.notes)}</div>` : ""}
        <div class="history-actions">
          <button class="mini-btn" data-edit="${escapeHTML(d.id)}" type="button">Edit</button>
          <button class="mini-btn" data-duplicate="${escapeHTML(d.id)}" type="button">Duplicate</button>
          <button class="delete-mini" data-delete="${escapeHTML(d.id)}" type="button">Delete</button>
        </div>
      </article>
    `;
  }

  function sourceLabel(source) {
    if (source === "ocr") return "OCR";
    if (source === "calculator") return "Calculator";
    if (source === "import") return "Import";
    return "Manual";
  }

  function dateLabel(dateKey) {
    if (dateKey === todayKey()) return "Today";
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    if (dateKey === todayKey(yesterday)) return "Yesterday";
    const [year, month, day] = dateKey.split("-").map(Number);
    return new Date(year, month - 1, day).toLocaleDateString([], { month: "short", day: "numeric", year: "numeric" });
  }

  function renderSettings() {
    const pairs = [
      [els.goalInput, settings.dailyGoal],
      [els.defaultCompanyInput, settings.defaultCompany],
      [els.gasPriceInput, settings.gasPrice],
      [els.mpgInput, settings.mpg],
      [els.maintenanceInput, settings.maintenancePerMile],
      [els.taxRateInput, settings.taxMileageRate],
      [els.minPerMileInput, settings.minPerMile],
      [els.minPerHourInput, settings.minPerHour],
      [els.minPayoutInput, settings.minPayout],
      [els.maxMilesInput, settings.maxMiles],
      [els.defaultZoneInput, settings.defaultZone]
    ];
    for (const [input, value] of pairs) {
      if (document.activeElement !== input) input.value = value ?? "";
    }
  }

  function renderShiftButton() {
    if (shift.active && shift.startedAt && isToday(shift.startedAt)) els.shiftBtn.textContent = "End Day";
    else els.shiftBtn.textContent = "Start Day";
  }

  function renderDeliveryPreview() {
    if (!els.deliveryPreview) return;
    const earnings = num(els.earningsInput.value);
    const miles = num(els.milesInput.value);
    const minutes = num(els.minutesInput.value);
    if (!earnings || !miles) {
      els.deliveryPreview.textContent = "Enter earnings and miles to preview profit.";
      els.deliveryPreview.className = "delivery-preview";
      return;
    }
    const profit = earnings - miles * costPerMile();
    const perMile = earnings / miles;
    const profitMile = profit / miles;
    const hourly = minutes ? earnings / (minutes / 60) : 0;
    const good = perMile >= settings.minPerMile && (!minutes || hourly >= settings.minPerHour);
    els.deliveryPreview.className = `delivery-preview ${good ? "good" : "bad"}`;
    els.deliveryPreview.textContent = `${money.format(profit)} estimated profit · ${money.format(perMile)}/mi gross · ${money.format(profitMile)}/mi profit${minutes ? ` · ${money.format(hourly)}/hr` : ""}`;
  }

  function renderDecision() {
    const pay = num(els.offerPayInput.value);
    const miles = num(els.offerMilesInput.value);
    const minutes = num(els.offerMinutesInput.value);
    const decision = evaluateOffer(pay, miles, minutes);
    els.decisionResult.className = `decision-card ${decision.kind}`;
    els.decisionResult.innerHTML = `
      <p class="label">Decision</p>
      <h2>${escapeHTML(decision.title)}</h2>
      <p>${escapeHTML(decision.detail)}</p>
      ${decision.metrics ? `<div class="decision-metrics">${decision.metrics.map((m) => `<span>${escapeHTML(m)}</span>`).join("")}</div>` : ""}
    `;
  }

  function evaluateOffer(pay, miles, minutes) {
    if (!pay || !miles || !minutes) {
      return { kind: "neutral", title: "Enter an offer", detail: "Add pay, miles, and estimated minutes to get an accept/decline recommendation." };
    }
    const perMile = pay / miles;
    const perHour = pay / (minutes / 60);
    const profit = pay - miles * costPerMile();
    const reasons = [];
    if (settings.minPayout && pay < settings.minPayout) reasons.push(`below ${money.format(settings.minPayout)} minimum payout`);
    if (settings.minPerMile && perMile < settings.minPerMile) reasons.push(`below ${money.format(settings.minPerMile)}/mile`);
    if (settings.minPerHour && perHour < settings.minPerHour) reasons.push(`below ${money.format(settings.minPerHour)}/hour`);
    if (settings.maxMiles && miles > settings.maxMiles) reasons.push(`over ${settings.maxMiles} mile maximum`);
    if (profit <= 0) reasons.push("estimated profit is not positive");
    const metrics = [
      `${money.format(perMile)}/mile`,
      `${money.format(perHour)}/hour`,
      `${money.format(profit)} profit`
    ];
    if (!reasons.length) return { kind: "accept", title: "ACCEPT", detail: "This offer clears your current rules.", metrics };
    if (reasons.length === 1 && (perMile >= settings.minPerMile * 0.85 || perHour >= settings.minPerHour * 0.85)) {
      return { kind: "borderline", title: "BORDERLINE", detail: `Reason: ${reasons[0]}.`, metrics };
    }
    return { kind: "decline", title: "DECLINE", detail: `Reasons: ${reasons.join(", ")}.`, metrics };
  }

  function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>'"]/g, (ch) => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#039;", '"': "&quot;"
    }[ch]));
  }

  function makeId() {
    if (globalThis.crypto && typeof globalThis.crypto.randomUUID === "function") return globalThis.crypto.randomUUID();
    if (globalThis.crypto && typeof globalThis.crypto.getRandomValues === "function") {
      const bytes = new Uint8Array(16);
      globalThis.crypto.getRandomValues(bytes);
      return [...bytes].map((b) => b.toString(16).padStart(2, "0")).join("");
    }
    return `${Date.now()}-${Math.random().toString(36).slice(2)}`;
  }

  function round2(v) { return Math.round(Number(v || 0) * 100) / 100; }
  function round1(v) { return Math.round(Number(v || 0) * 10) / 10; }
  function clamp(value, min, max) { return Math.min(max, Math.max(min, value)); }

  function showTab(tab) {
    const screen = $(`tab-${tab}`);
    const button = document.querySelector(`.tab-btn[data-tab="${tab}"]`);
    if (!screen || !button) {
      console.warn(`Unknown tab requested: ${tab}`);
      return;
    }
    document.querySelectorAll(".tab-screen").forEach((el) => el.classList.remove("active"));
    document.querySelectorAll(".tab-btn").forEach((el) => el.classList.remove("active"));
    screen.classList.add("active");
    button.classList.add("active");
  }

  function openAdd(mode = "manual") {
    showTab("add");
    if (!els.editDeliveryId.value) {
      els.companyInput.value = settings.defaultCompany || "DoorDash";
      els.zoneInput.value = settings.defaultZone || "";
    }
    if (mode === "scan") {
      setTimeout(() => {
        if (els.screenshotInput && typeof els.screenshotInput.click === "function") els.screenshotInput.click();
      }, 80);
    } else if (els.earningsInput && typeof els.earningsInput.focus === "function") {
      els.earningsInput.focus();
    }
  }

  async function scanScreenshot(file) {
    if (!file) return;
    clearOCR(false);
    if (els.previewImage.dataset.url) URL.revokeObjectURL(els.previewImage.dataset.url);
    const url = URL.createObjectURL(file);
    els.previewImage.dataset.url = url;
    els.previewImage.src = url;
    els.previewImage.classList.remove("hidden");
    els.scanStatus.classList.remove("hidden");
    els.scanStatus.textContent = "Scanning screenshot…";

    if (!globalThis.Tesseract || typeof globalThis.Tesseract.recognize !== "function") {
      els.scanStatus.textContent = "OCR library is not loaded yet. You can still enter the delivery manually.";
      return;
    }

    try {
      const result = await globalThis.Tesseract.recognize(file, "eng");
      lastOCRText = result?.data?.text || "";
      lastOCRParsed = parseOCR(lastOCRText);
      els.ocrText.textContent = lastOCRText || "No readable text detected.";
      els.ocrDetails.classList.remove("hidden");
      renderOCRReview(lastOCRParsed);
      els.scanStatus.textContent = lastOCRParsed.confidence >= 70 ? "Scan complete. Review before saving." : "Scan complete, but confidence is low. Please review.";
    } catch (err) {
      console.error(err);
      els.scanStatus.textContent = "Could not scan this screenshot. Enter the delivery manually.";
    }
  }

  function renderOCRReview(parsed) {
    if (!parsed) return;
    els.ocrCompany.textContent = parsed.platform || "Needs review";
    els.ocrEarnings.textContent = parsed.earnings ? money.format(parsed.earnings) : "Needs review";
    els.ocrMiles.textContent = parsed.miles ? `${parsed.miles.toFixed(1)} mi` : "Needs review";
    els.ocrConfidence.textContent = `${parsed.confidence}%`;
    els.ocrReview.classList.remove("hidden");
  }

  function applyParsedResult(parsed) {
    if (!parsed) return;
    if (parsed.platform) els.companyInput.value = parsed.platform;
    if (parsed.earnings) els.earningsInput.value = parsed.earnings.toFixed(2);
    if (parsed.miles) els.milesInput.value = parsed.miles.toFixed(1);
    renderDeliveryPreview();
  }

  function clearOCR(clearFile = true) {
    lastOCRText = "";
    lastOCRParsed = null;
    els.ocrReview.classList.add("hidden");
    els.ocrDetails.classList.add("hidden");
    els.ocrText.textContent = "";
    els.scanStatus.classList.add("hidden");
    if (clearFile) {
      els.screenshotInput.value = "";
      if (els.previewImage.dataset.url) {
        URL.revokeObjectURL(els.previewImage.dataset.url);
        delete els.previewImage.dataset.url;
      }
      els.previewImage.removeAttribute("src");
      els.previewImage.classList.add("hidden");
    }
  }

  function parseOCR(text) {
    const normalized = String(text || "").replace(/\s+/g, " ").trim();
    const platform = detectPlatform(normalized);
    const earnings = detectEarnings(normalized);
    const miles = detectMiles(normalized);
    let confidence = 20;
    if (platform) confidence += 25;
    if (earnings) confidence += 30;
    if (miles) confidence += 25;
    return { platform, earnings, miles, confidence: Math.min(confidence, 98) };
  }

  function detectPlatform(text) {
    const low = text.toLowerCase();
    if (/door\s*dash|doordash|dash/.test(low)) return "DoorDash";
    if (/uber\s*eats|ubereats|uber/.test(low)) return "Uber Eats";
    if (/grub\s*hub|grubhub/.test(low)) return "Grubhub";
    if (/instacart/.test(low)) return "Instacart";
    if (/spark|walmart/.test(low)) return "Spark";
    if (/roadie/.test(low)) return "Roadie";
    if (/catering|ezcater/.test(low)) return "Catering";
    return "Other";
  }

  function parseMoneyToken(token) {
    if (/^\d{1,3}(,\d{3})+(\.\d{2})?$/.test(token)) return Number.parseFloat(token.replace(/,/g, ""));
    return Number.parseFloat(token.replace(/,/g, "."));
  }

  function detectEarnings(text) {
    const matches = [];
    const push = (raw, index, bonus) => {
      const value = parseMoneyToken(raw);
      if (!Number.isFinite(value) || value <= 0 || value > 1000) return;
      const context = text.slice(Math.max(0, index - 70), Math.min(text.length, index + 90)).toLowerCase();
      let score = 1 + bonus;
      if (/total|earn|earning|payout|pay|paid|estimate|offer|guarantee|including|tip|fare|base/.test(context)) score += 3;
      if (/balance|cash\s*out|weekly|month|year|tax|fee|subscription|debt|per\s*hour|\/\s*hr/.test(context)) score -= 2;
      if (value >= 2 && value <= 80) score += 1;
      matches.push({ value, score, index });
    };
    const dollarRegex = /(?:\$|usd\s*)\s*([0-9]{1,3}(?:,[0-9]{3})+(?:\.[0-9]{2})?|[0-9]{1,4}(?:[.,][0-9]{2})?)/gi;
    let m;
    while ((m = dollarRegex.exec(text)) !== null) push(m[1], m.index, 0);
    const keywordRegex = /(?:total|earnings?|payout|paid|guarantee|fare|offer)[^0-9$\n]{0,14}([0-9]{1,3}(?:,[0-9]{3})*\.[0-9]{2})/gi;
    while ((m = keywordRegex.exec(text)) !== null) push(m[1], m.index, 2);
    if (!matches.length) return 0;
    matches.sort((a, b) => b.score - a.score || b.value - a.value || a.index - b.index);
    return round2(matches[0].value);
  }

  function detectMiles(text) {
    const matches = [];
    const mileRegex = /([0-9]{1,3}(?:[.,][0-9]{1,2})?)\s*(?:miles|mile|mi)(?![a-z])/gi;
    let m;
    while ((m = mileRegex.exec(text)) !== null) {
      const value = Number.parseFloat(m[1].replace(",", "."));
      if (!Number.isFinite(value) || value <= 0 || value > 300) continue;
      const context = text.slice(Math.max(0, m.index - 60), Math.min(text.length, m.index + 60)).toLowerCase();
      let score = 1;
      if (/total|trip|delivery|distance|route/.test(context)) score += 2;
      if (/mph|minutes|minute|away|radius/.test(context)) score -= 1;
      matches.push({ value, score, index: m.index });
    }
    if (!matches.length) return 0;
    matches.sort((a, b) => b.score - a.score || a.value - b.value);
    return round1(matches[0].value);
  }

  function saveDelivery(event, options = {}) {
    event.preventDefault();
    const earnings = num(els.earningsInput.value);
    const miles = num(els.milesInput.value);
    const minutes = num(els.minutesInput.value);
    const selectedCompany = els.companyInput.value || settings.defaultCompany || "Other";
    const company = allowedCompanies.has(selectedCompany) ? selectedCompany : "Other";

    if (!earnings || earnings <= 0) {
      toast("Enter the delivery earnings first.");
      flagInvalid(els.earningsInput);
      return;
    }
    if (!miles || miles <= 0) {
      toast("Enter the delivery miles first.");
      flagInvalid(els.milesInput);
      return;
    }

    const existingId = els.editDeliveryId.value;
    const existing = existingId ? deliveries.find((d) => d.id === existingId) : null;
    const now = new Date().toISOString();
    const delivery = normalizeDelivery({
      id: existingId || makeId(),
      company,
      earnings,
      miles,
      minutes,
      zone: els.zoneInput.value || settings.defaultZone || "",
      notes: els.notesInput.value,
      source: existing ? existing.source : (lastOCRText ? "ocr" : "manual"),
      ocrText: lastOCRText || existing?.ocrText || "",
      ocrConfidence: lastOCRParsed?.confidence || existing?.ocrConfidence || 0,
      createdAt: existing ? existing.createdAt : now,
      updatedAt: now,
      version: DATA_VERSION
    });
    if (!delivery) return toast("Could not save this delivery. Check the fields and try again.");

    if (existingId) deliveries = deliveries.map((d) => d.id === existingId ? delivery : d);
    else deliveries.push(delivery);
    writeJSON(STORE_KEY, deliveries);
    clearForm(!options.stayOnForm);
    render();
    if (!options.stayOnForm) showTab("today");
    toast(`${existingId ? "Updated" : "Saved"} ${money.format(delivery.earnings)} from ${company}.`);
  }

  function clearForm(keepCompany = true) {
    els.editDeliveryId.value = "";
    if (!keepCompany) els.companyInput.value = settings.defaultCompany || "DoorDash";
    els.earningsInput.value = "";
    els.milesInput.value = "";
    els.minutesInput.value = "";
    els.zoneInput.value = settings.defaultZone || "";
    els.notesInput.value = "";
    els.saveDeliveryBtn.textContent = "Save Delivery";
    els.cancelEditBtn.classList.add("hidden");
    clearOCR(true);
    renderDeliveryPreview();
  }

  function editDelivery(id) {
    const d = deliveries.find((item) => item.id === id);
    if (!d) return;
    els.editDeliveryId.value = d.id;
    els.companyInput.value = d.company;
    els.earningsInput.value = Number(d.earnings).toFixed(2);
    els.milesInput.value = Number(d.miles).toFixed(1);
    els.minutesInput.value = d.minutes ? String(d.minutes) : "";
    els.zoneInput.value = d.zone || "";
    els.notesInput.value = d.notes || "";
    els.saveDeliveryBtn.textContent = "Update Delivery";
    els.cancelEditBtn.classList.remove("hidden");
    showTab("add");
    renderDeliveryPreview();
  }

  function duplicateDelivery(id) {
    const d = deliveries.find((item) => item.id === id);
    if (!d) return;
    const copy = normalizeDelivery({ ...d, id: makeId(), source: "manual", ocrText: "", ocrConfidence: 0, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(), notes: d.notes ? `${d.notes} duplicate` : "" });
    if (!copy) return;
    deliveries.push(copy);
    writeJSON(STORE_KEY, deliveries);
    render();
    toast("Delivery duplicated for today.");
  }

  function deleteDelivery(id) {
    const item = deliveries.find((d) => d.id === id);
    if (!item) return;
    if (!confirm(`Delete ${money.format(Number(item.earnings || 0))} ${item.company} delivery?`)) return;
    lastDeleted = item;
    deliveries = deliveries.filter((d) => d.id !== id);
    writeJSON(STORE_KEY, deliveries);
    render();
    toast("Delivery deleted.", { label: "Undo", handler: undoDelete });
  }

  function undoDelete() {
    if (!lastDeleted) return;
    if (!deliveries.some((d) => d.id === lastDeleted.id)) {
      deliveries.push(lastDeleted);
      deliveries = normalizeDeliveries(deliveries);
      writeJSON(STORE_KEY, deliveries);
      render();
      toast("Delivery restored.");
    }
    lastDeleted = null;
  }

  function clearToday() {
    const todays = todayDeliveries();
    if (!todays.length) return toast("There are no deliveries saved for today.");
    if (!confirm(`Delete ${todays.length} ${todays.length === 1 ? "delivery" : "deliveries"} from today?`)) return;
    const today = todayKey();
    deliveries = deliveries.filter((d) => todayKey(new Date(d.createdAt)) !== today);
    writeJSON(STORE_KEY, deliveries);
    render();
    showTab("today");
    toast("Today's deliveries deleted.");
  }

  function saveSettings() {
    settings = normalizeSettings({
      dailyGoal: els.goalInput.value,
      defaultCompany: els.defaultCompanyInput.value,
      gasPrice: els.gasPriceInput.value,
      mpg: els.mpgInput.value,
      maintenancePerMile: els.maintenanceInput.value,
      taxMileageRate: els.taxRateInput.value,
      minPerMile: els.minPerMileInput.value,
      minPerHour: els.minPerHourInput.value,
      minPayout: els.minPayoutInput.value,
      maxMiles: els.maxMilesInput.value,
      defaultZone: els.defaultZoneInput.value
    });
    writeJSON(SETTINGS_KEY, settings);
    els.companyInput.value = settings.defaultCompany;
    els.offerCompanyInput.value = settings.defaultCompany;
    els.offerZoneInput.value = settings.defaultZone || "";
    els.zoneInput.value = settings.defaultZone || "";
    render();
    showTab("today");
    toast("Settings saved.");
  }

  function toggleShift() {
    if (shift.active && shift.startedAt && isToday(shift.startedAt)) {
      shift = { active: false, startedAt: shift.startedAt, endedAt: new Date().toISOString() };
      toast("Day ended. Time and hourly stats are frozen.");
    } else {
      shift = { active: true, startedAt: new Date().toISOString(), endedAt: null };
      toast("Day started. The clock is running.");
    }
    writeJSON(SHIFT_KEY, shift);
    render();
  }

  function buildCSV(kind = "standard") {
    const header = kind === "tax"
      ? ["date", "company", "earnings", "business_miles", "estimated_mileage_deduction", "estimated_vehicle_cost", "estimated_profit", "zone", "source", "ocr_confidence", "notes"]
      : ["date", "company", "earnings", "miles", "minutes", "dollars_per_mile", "estimated_profit", "zone", "source", "ocr_confidence", "notes"];
    const rows = [...deliveries]
      .sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt))
      .map((d) => kind === "tax"
        ? [
            new Date(d.createdAt).toISOString(),
            d.company,
            d.earnings,
            d.miles,
            round2(Number(d.miles || 0) * settings.taxMileageRate),
            round2(Number(d.miles || 0) * costPerMile()),
            deliveryProfit(d),
            d.zone || "",
            d.source || "manual",
            d.ocrConfidence || "",
            d.notes || ""
          ]
        : [
            new Date(d.createdAt).toISOString(),
            d.company,
            d.earnings,
            d.miles,
            d.minutes || "",
            d.miles ? round2(Number(d.earnings || 0) / Number(d.miles)) : 0,
            deliveryProfit(d),
            d.zone || "",
            d.source || "manual",
            d.ocrConfidence || "",
            d.notes || ""
          ]
      );
    return [header, ...rows]
      .map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(","))
      .join("\r\n");
  }

  async function shareOrDownload(content, filename, type) {
    if (navigator.canShare && typeof File === "function") {
      try {
        const file = new File([content], filename, { type });
        if (navigator.canShare({ files: [file] })) {
          await navigator.share({ files: [file], title: filename });
          return;
        }
      } catch (err) {
        if (err && err.name === "AbortError") return;
      }
    }
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
  }

  async function exportCSV(kind = "standard") {
    if (!deliveries.length) return toast("No deliveries to export yet.");
    const csv = "\uFEFF" + buildCSV(kind);
    const suffix = kind === "tax" ? "tax" : "deliveries";
    await shareOrDownload(csv, `driveledger-${suffix}-${todayKey()}.csv`, "text/csv;charset=utf-8");
    toast(kind === "tax" ? "Tax CSV exported." : "CSV exported.");
  }

  async function exportBackup() {
    const backup = {
      app: "DriveLedger",
      version: BACKUP_VERSION,
      dataVersion: DATA_VERSION,
      exportedAt: new Date().toISOString(),
      settings,
      shift,
      deliveries
    };
    await shareOrDownload(JSON.stringify(backup, null, 2), `driveledger-backup-${todayKey()}.json`, "application/json;charset=utf-8");
    toast("Backup exported.");
  }

  async function importBackup(file) {
    if (!file) return;
    try {
      const text = await file.text();
      const parsed = JSON.parse(text);
      const importedDeliveries = normalizeDeliveries(parsed.deliveries || []);
      const importedSettings = normalizeSettings(parsed.settings || {});
      const importedShift = normalizeShift(parsed.shift || {});
      if (!importedDeliveries.length && !confirm("This backup has no deliveries. Import settings anyway?")) return;
      if (!confirm(`Import ${importedDeliveries.length} deliveries and replace current local data? A rollback copy of your current data will be saved first.`)) return;
      writeJSON(ROLLBACK_KEY, {
        app: "DriveLedger",
        version: BACKUP_VERSION,
        dataVersion: DATA_VERSION,
        savedAt: new Date().toISOString(),
        reason: "pre-import rollback",
        settings,
        shift,
        deliveries
      });
      deliveries = importedDeliveries.map((d) => normalizeDelivery({ ...d, source: validSources.has(d.source) ? d.source : "import" })).filter(Boolean);
      settings = importedSettings;
      shift = importedShift;
      writeJSON(STORE_KEY, deliveries);
      writeJSON(SETTINGS_KEY, settings);
      writeJSON(SHIFT_KEY, shift);
      render();
      toast("Backup imported.");
    } catch (err) {
      console.error(err);
      toast("Could not import backup. Check the JSON file.");
    } finally {
      els.importInput.value = "";
    }
  }

  function restoreRollback() {
    const rollback = readJSON(ROLLBACK_KEY, null);
    if (!rollback) return toast("No import rollback backup found.");
    const rollbackDeliveries = normalizeDeliveries(rollback.deliveries || []);
    const rollbackSettings = normalizeSettings(rollback.settings || {});
    const rollbackShift = normalizeShift(rollback.shift || {});
    if (!confirm(`Restore rollback from ${rollback.savedAt ? new Date(rollback.savedAt).toLocaleString() : "previous import"}? This replaces current local data.`)) return;
    deliveries = rollbackDeliveries;
    settings = rollbackSettings;
    shift = rollbackShift;
    writeJSON(STORE_KEY, deliveries);
    writeJSON(SETTINGS_KEY, settings);
    writeJSON(SHIFT_KEY, shift);
    render();
    toast("Rollback restored.");
  }

  async function copySummary() {
    const todays = todayDeliveries();
    if (!todays.length) return toast("No summary to copy yet.");
    if (!navigator.clipboard || typeof navigator.clipboard.writeText !== "function") {
      toast("Copy is not available in this browser.");
      return;
    }
    const c = calculate(todays);
    const text = `DriveLedger summary for ${todayKey()}\nEarned: ${money.format(c.earnings)}\nEstimated profit: ${money.format(c.profit)}\nDeliveries: ${c.orders}\nMiles: ${c.miles.toFixed(1)}\nGross/hour: ${money.format(c.avgHour)}\nProfit/hour: ${money.format(c.profitHour)}`;
    try {
      await navigator.clipboard.writeText(text);
      toast("Summary copied.");
    } catch {
      toast("Copy is not available in this browser.");
    }
  }

  function saveOfferAsDelivery() {
    const pay = num(els.offerPayInput.value);
    const miles = num(els.offerMilesInput.value);
    const minutes = num(els.offerMinutesInput.value);
    if (!pay || !miles) return toast("Enter offer pay and miles first.");
    const company = allowedCompanies.has(els.offerCompanyInput.value) ? els.offerCompanyInput.value : settings.defaultCompany;
    const now = new Date().toISOString();
    const delivery = normalizeDelivery({
      id: makeId(),
      company,
      earnings: pay,
      miles,
      minutes,
      zone: els.offerZoneInput.value || settings.defaultZone,
      notes: "Saved from accept calculator",
      source: "calculator",
      createdAt: now,
      updatedAt: now,
      version: DATA_VERSION
    });
    if (!delivery) return toast("Could not save this offer.");
    deliveries.push(delivery);
    writeJSON(STORE_KEY, deliveries);
    els.offerPayInput.value = "";
    els.offerMilesInput.value = "";
    els.offerMinutesInput.value = "";
    els.offerZoneInput.value = settings.defaultZone || "";
    render();
    showTab("today");
    toast("Offer saved as a completed delivery.");
  }

  function flagInvalid(input) {
    input.classList.add("invalid");
    input.focus();
    setTimeout(() => input.classList.remove("invalid"), 1200);
  }

  function toast(message, action = null) {
    if (!els.toast) return;
    toastAction = action && typeof action.handler === "function" ? action.handler : null;
    if (toastAction) {
      els.toast.innerHTML = `<span>${escapeHTML(message)}</span><button type="button" data-toast-action>${escapeHTML(action.label || "Undo")}</button>`;
    } else {
      els.toast.textContent = message;
    }
    els.toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
      els.toast.classList.remove("show");
      toastAction = null;
    }, 4200);
  }

  function bindEvents() {
    document.querySelectorAll(".tab-btn").forEach((btn) => btn.addEventListener("click", () => showTab(btn.dataset.tab)));
    document.querySelectorAll("[data-tab-jump]").forEach((btn) => btn.addEventListener("click", () => showTab(btn.dataset.tabJump)));
    document.querySelectorAll("[data-open-add]").forEach((btn) => btn.addEventListener("click", () => openAdd(btn.dataset.openAdd)));
    $("deliveryForm").addEventListener("submit", saveDelivery);
    els.saveSettingsBtn.addEventListener("click", saveSettings);
    els.clearTodayBtn.addEventListener("click", clearToday);
    els.exportBtn.addEventListener("click", () => exportCSV("standard"));
    els.exportTaxBtn.addEventListener("click", () => exportCSV("tax"));
    els.backupBtn.addEventListener("click", exportBackup);
    els.restoreRollbackBtn.addEventListener("click", restoreRollback);
    els.importInput.addEventListener("change", (event) => importBackup(event.target.files?.[0]));
    els.copySummaryBtn.addEventListener("click", copySummary);
    els.shiftBtn.addEventListener("click", toggleShift);
    els.toast.addEventListener("click", (event) => {
      if (event.target.closest("[data-toast-action]") && toastAction) {
        const action = toastAction;
        toastAction = null;
        action();
      }
    });
    els.screenshotInput.addEventListener("change", (event) => scanScreenshot(event.target.files?.[0]));
    els.applyOcrBtn.addEventListener("click", () => applyParsedResult(lastOCRParsed));
    els.clearOcrBtn.addEventListener("click", () => clearOCR(true));
    els.saveAddAnotherBtn.addEventListener("click", () => saveDelivery({ preventDefault() {} }, { stayOnForm: true }));
    els.cancelEditBtn.addEventListener("click", () => { clearForm(false); render(); });
    [els.earningsInput, els.milesInput, els.minutesInput].forEach((input) => input.addEventListener("input", renderDeliveryPreview));
    [els.offerPayInput, els.offerMilesInput, els.offerMinutesInput, els.offerCompanyInput].forEach((input) => input.addEventListener("input", renderDecision));
    els.saveOfferAsDeliveryBtn.addEventListener("click", saveOfferAsDelivery);
    els.historyList.addEventListener("click", (event) => {
      const action = event.target.closest("[data-delete],[data-edit],[data-duplicate],[data-open-add]");
      if (!action) return;
      if (action.dataset.delete) deleteDelivery(action.dataset.delete);
      else if (action.dataset.edit) editDelivery(action.dataset.edit);
      else if (action.dataset.duplicate) duplicateDelivery(action.dataset.duplicate);
      else if (action.dataset.openAdd) openAdd(action.dataset.openAdd);
    });
    document.addEventListener("visibilitychange", () => {
      if (!document.hidden) checkDayAndRender(true);
    });
    window.addEventListener("pageshow", () => checkDayAndRender(true));
  }

  function checkDayAndRender(full = false) {
    const key = todayKey();
    if (key !== lastDayKey) {
      lastDayKey = key;
      render();
      return;
    }
    if (full) render();
    else renderLive();
  }

  function registerServiceWorker() {
    if (!document.querySelector('link[rel="manifest"]')) return;
    if ("serviceWorker" in navigator && ["http:", "https:"].includes(location.protocol)) {
      navigator.serviceWorker.register("service-worker.js").catch((err) => console.warn("Service worker registration failed", err));
    }
  }

  function init() {
    els.companyInput.value = settings.defaultCompany;
    els.offerCompanyInput.value = settings.defaultCompany;
    els.offerZoneInput.value = settings.defaultZone || "";
    els.zoneInput.value = settings.defaultZone || "";
    bindEvents();
    render();
    registerServiceWorker();
    setInterval(() => checkDayAndRender(false), 30000);
  }

  init();
})();
