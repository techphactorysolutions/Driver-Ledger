# DriveLedger v2.1 Baseline Engineering Audit

## Project type found

The uploaded project is a static Progressive Web App. It does not contain a FastAPI/backend app, Python route modules, database migrations, or backend dependency files. This phase therefore preserves the static local-first architecture instead of adding a fake backend.

## Audit scope

Checked:

- Static ZIP/package structure.
- HTML asset references.
- Manifest and icon paths.
- Service worker syntax and cache references.
- JavaScript syntax.
- DOM IDs referenced by `app.js`.
- Visible controls and event wiring.
- LocalStorage key namespacing.
- Corrupted localStorage startup resilience.
- Manual delivery save.
- Save + Add Another flow.
- Accept Calculator recommendation rendering.
- Accept Calculator save-to-delivery behavior.
- Calculator delivery zone/source persistence.
- Shift start persistence.
- Backend/API call absence.

## Issues found and fixed in this phase

### 1. Calculator-saved deliveries did not capture a zone

The Accept Calculator could save a completed delivery, but it always used the default zone instead of letting the driver capture the zone for that order.

Fix:

- Added `offerZoneInput` to the Decide tab.
- Saved calculator deliveries now persist the entered zone.
- Smoke test now verifies a calculator delivery persists `source: "calculator"` and the selected zone.

### 2. Delivery source metadata was incomplete

The upgraded app had OCR, manual entry, calculator entry, imports, and duplication flows, but saved delivery records did not consistently preserve a `source` field or OCR confidence.

Fix:

- Added source normalization for `manual`, `ocr`, `calculator`, and `import`.
- Added normalized `ocrConfidence`, `updatedAt`, and `version` fields.
- Manual saves persist `source: "manual"`.
- OCR-applied saves persist `source: "ocr"` and OCR confidence.
- Calculator saves persist `source: "calculator"`.
- Duplicated deliveries are treated as new manual entries and clear OCR metadata.
- History now displays a source label.

### 3. JSON import replacement had no local rollback copy

Importing a backup replaced local data after confirmation, but there was no emergency local rollback point.

Fix:

- Added `driveledger.rollback.v1` localStorage key.
- Before import replacement, the current deliveries, settings, and shift state are saved as a rollback snapshot.
- Added a visible **Restore Import Rollback** button wired to real restore logic.

### 4. Manual entry needed faster repeated-save workflow

The app had a normal save flow, but repeated delivery entry required returning from the Today screen.

Fix:

- Added **Save + Add Another**.
- The button saves the delivery, keeps the user in the Add flow, and clears the entry fields for the next order.
- Smoke test now verifies this persists a second delivery.

### 5. Exports did not include source metadata

CSV exports did not expose whether a row came from manual entry, OCR, calculator, or import.

Fix:

- Standard CSV and tax CSV now include `source` and `ocr_confidence` columns.

## Files changed

- `index.html`
  - Added Save + Add Another button.
  - Added Accept Calculator zone input.
  - Added Restore Import Rollback control.

- `styles.css`
  - Adjusted export grid for the added rollback button.
  - Added source badge styling.

- `app.js`
  - Added `DATA_VERSION` and `ROLLBACK_KEY`.
  - Added delivery metadata normalization.
  - Added delivery source labels.
  - Added calculator zone persistence.
  - Added save-and-add-another behavior.
  - Added import rollback snapshot and restore logic.
  - Added source/OCR confidence columns to CSV exports.

- `tools/smoke-startup.js`
  - Added assertions for delivery metadata.
  - Added Save + Add Another smoke coverage.
  - Added calculator zone/source persistence coverage.

- `tests/test_static_app.py`
  - Added checks for new DOM IDs, event bindings, storage key, source metadata, and rollback function.

- `README.md`
  - Updated feature list, storage keys, test coverage, and architecture notes.

- `package.json`
  - Bumped version to `2.1.0`.

- `service-worker.js`
  - Bumped cache name to `driveledger-v4` so upgraded static assets refresh cleanly.

## Tests run

```bash
npm run syntax
npm run smoke
python -m unittest discover -s tests -v
```

Results:

```text
npm run syntax: passed
npm run smoke: passed
python unittest: Ran 10 tests — OK
```

## Remaining risks

- The app is still local-first and browser-storage based. If the user clears browser data, records can be lost unless they export a JSON backup.
- OCR still depends on the remote Tesseract.js CDN on first load. Manual entry remains available if OCR cannot load.
- The smoke test uses a mocked browser, not real iOS Safari automation.
- Expense and tax figures are estimates; users should keep editable settings updated for their actual vehicle and tax situation.
- Backup import currently uses replace + rollback. A merge/deduplicate import mode is still a recommended future phase.
- The quick-add flow is improved with Save + Add Another, but it is still tab-based rather than a true bottom sheet/modal.

## Manual QA checklist

Use this checklist on iPhone/iPad Safari or a hosted Netlify build:

1. Open app fresh with no saved data.
2. Start a shift.
3. Add a manual delivery.
4. Use Save + Add Another for a second delivery.
5. Verify Today totals update.
6. Open Decide tab and enter pay, miles, minutes, company, and zone.
7. Save offer as completed delivery.
8. Verify calculator delivery appears in History with Calculator source and selected zone.
9. Edit a delivery and confirm totals update.
10. Duplicate a delivery.
11. Delete a delivery and undo the delete.
12. Export standard CSV.
13. Export tax CSV.
14. Export JSON backup.
15. Import JSON backup and verify rollback prompt/control behavior.
16. Restore import rollback if needed.
17. Reload the page and confirm data persists.
18. Test offline reload after PWA install.
