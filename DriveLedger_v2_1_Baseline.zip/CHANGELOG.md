# Changelog

## 2.1.0

- Added calculator zone capture.
- Added delivery source metadata normalization.
- Added OCR confidence, updatedAt, and version metadata on normalized delivery records.
- Added source labels in History.
- Added Save + Add Another for faster repeated manual entry.
- Added pre-import rollback snapshots.
- Added Restore Import Rollback control.
- Added source and OCR confidence columns to standard and tax CSV exports.
- Expanded mocked startup smoke coverage.
- Bumped PWA service worker cache to `driveledger-v4`.
