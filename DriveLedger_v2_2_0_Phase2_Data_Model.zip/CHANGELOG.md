# Changelog

## 2.2.0

- Completed Phase 2 data model and storage upgrade.
- Added full normalized delivery schema fields: date, note/notes, OCR text, tags, deleted flag, and current data version.
- Added long-form settings keys with backward-compatible aliases for existing UI logic.
- Added shift `lastSummary`, `shiftHistory`, and shift-history normalization.
- Added startup persistence for normalized migrated localStorage state.
- Added backup schema metadata to JSON exports.
- Improved backup import source normalization for unknown-source records.
- Expanded smoke tests for legacy data migration and shift-history persistence.
- Expanded Python static tests for Phase 2 schema and migration hooks.
- Bumped PWA service worker cache to `driveledger-v6`.

## 2.1.1

- Completed Phase 1 full audit/stabilization pass on the v2.1 baseline.
- Fixed summary copy feedback so the app no longer claims a summary was copied when the Clipboard API is unavailable.
- Expanded the mocked startup smoke test to cover unavailable Clipboard API behavior.
- Expanded Python static tests to verify service-worker cached assets exist.
- Expanded event-binding checks for Save + Add Another and Cancel Edit.
- Bumped PWA service worker cache to `driveledger-v5`.

## 2.1.0

- Added calculator zone capture.
- Added delivery source metadata normalization.
- Added OCR confidence, updatedAt, and version metadata on normalized delivery records.
- Added source labels in History.
- Added Save + Add Another for faster repeated manual entry.
- Added pre-import rollback snapshots.
- Added Restore Import Rollback control.
- Added source and OCR confidence columns to standard and tax CSV exports.
- Expanded mocked startup smoke coverage.
- Bumped PWA service worker cache to `driveledger-v4`.
