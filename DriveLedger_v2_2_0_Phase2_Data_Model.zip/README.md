# DriveLedger

DriveLedger is a local-first Progressive Web App for gig delivery drivers. It tracks daily earnings, mileage, estimated profit, tax mileage deduction, platform performance, zone performance, shift pace, screenshot OCR-assisted entry, and accept/decline order decisions.

## Current release

Version: `2.2.0` Phase 2 data model and storage upgrade.

This release preserves the static PWA architecture. There is no backend, database server, framework, build step, or account system. The app runs from plain static files and stores user data locally in the browser.

## Included features

- Today Command Center with gross earnings, estimated profit, hourly pace, $/mile, tax deduction, shift status, driver score, and goal ETA.
- Profit Mode using editable gas price, MPG, maintenance cost per mile, and mileage deduction rate.
- Accept Calculator that recommends **ACCEPT**, **BORDERLINE**, or **DECLINE** using user-defined minimum payout, $/mile, $/hour, and max-mile rules.
- Accept Calculator zone capture so saved calculator deliveries contribute to zone analytics.
- Screenshot OCR review card with detected company, earnings, miles, and confidence before applying values.
- Fast manual delivery entry with optional minutes, zone, notes, and **Save + Add Another** support.
- Delivery edit, duplicate, delete, and undo-delete support.
- Grouped History by day with daily totals, per-delivery profit details, and source labels.
- Company and zone performance breakdowns.
- Daily shift summary with copy support.
- Standard CSV export, tax CSV export, JSON backup, JSON import, and pre-import rollback restore.
- Local-first storage using browser `localStorage` under `driveledger.*` keys.

## Phase 2 storage upgrade notes

The v2.2.0 pass strengthens the local data model so future analytics, tax reports, import/restore workflows, OCR confidence review, and shift summaries have a stable schema.

Delivery records are normalized on app startup and when saved/imported. The current delivery schema includes:

```text
id
date
createdAt
updatedAt
company
earnings
miles
minutes
zone
note
notes
source: manual, ocr, calculator, import
ocrText
ocrConfidence
tags
deleted
version
```

Settings are also normalized and now include clearer long-form keys while preserving the older short aliases used by existing UI code:

```text
dailyGoal
defaultCompany
defaultZone
gasPrice
vehicleMpg / mpg
maintenanceCostPerMile / maintenancePerMile
mileageDeductionRate / taxMileageRate
minimumDollarPerMile / minPerMile
minimumDollarPerHour / minPerHour
minimumPayout / minPayout
maxMiles
theme
appDataVersion
```

Shift data now includes:

```text
active
startedAt
endedAt
lastSummary
shiftHistory
appDataVersion
```

On startup, DriveLedger normalizes and re-saves the local state. This gives older saved data the new fields without requiring a backend migration. Corrupted JSON or impossible values are safely defaulted or discarded instead of crashing the app.

## Local data keys

DriveLedger currently uses these localStorage keys:

- `driveledger.deliveries.v1`
- `driveledger.settings.v1`
- `driveledger.shift.v1`
- `driveledger.rollback.v1`

## Run locally

Because this is a static PWA, no backend server is required. Open `index.html` directly for simple testing, or serve the folder with any static server:

```bash
python -m http.server 8000
```

Then open `http://localhost:8000`.

## Install on iPhone/iPad

1. Host the folder with HTTPS, such as Netlify Drop.
2. Open the hosted site in Safari.
3. Tap Share.
4. Tap **Add to Home Screen**.

## Tests

The ZIP includes a no-dependency smoke test suite. It checks static package structure, manifest/icon paths, JavaScript syntax, UI wiring, local storage namespacing, startup behavior in a mocked browser, manual delivery save, save-and-add-another, calculator zone/source persistence, accept-calculator behavior, shift persistence, shift history persistence, local schema migration, service-worker cached asset references, and Clipboard API fallback behavior.

```bash
python -m unittest discover -s tests -v
```

Optional Node scripts:

```bash
npm run syntax
npm run smoke
```

## Architecture notes

- There is no FastAPI/backend layer in this ZIP.
- Data is stored locally in browser `localStorage`.
- Screenshot OCR uses Tesseract.js from jsDelivr on first load. If the CDN is unavailable, the app falls back to manual entry.
- Tax and expense numbers are estimates. The mileage rate, gas price, MPG, and maintenance cost are editable in Settings.
- The smoke test is a mocked browser test, not a substitute for manual iPhone/iPad Safari testing.
