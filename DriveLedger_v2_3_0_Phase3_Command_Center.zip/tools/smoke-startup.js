#!/usr/bin/env node
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { webcrypto } = require('node:crypto');

const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const appCode = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const idMatches = [...html.matchAll(/\sid=["']([^"']+)["']/g)].map((m) => m[1]);
const tabNames = [...html.matchAll(/data-tab=["']([^"']+)["']/g)].map((m) => m[1]);
const openAddModes = [...html.matchAll(/data-open-add=["']([^"']+)["']/g)].map((m) => m[1]);
const tabJumpNames = [...html.matchAll(/data-tab-jump=["']([^"']+)["']/g)].map((m) => m[1]);

class MockClassList {
  constructor() { this.values = new Set(); }
  add(...items) { items.forEach((item) => this.values.add(item)); }
  remove(...items) { items.forEach((item) => this.values.delete(item)); }
  contains(item) { return this.values.has(item); }
}

function createElement(id = '') {
  return {
    id,
    value: '',
    textContent: '',
    innerHTML: '',
    dataset: {},
    style: {},
    files: [],
    classList: new MockClassList(),
    listeners: {},
    addEventListener(type, handler) {
      this.listeners[type] ||= [];
      this.listeners[type].push(handler);
    },
    appendChild() {},
    remove() {},
    click() {},
    focus() { document.activeElement = this; },
    blur() { if (document.activeElement === this) document.activeElement = null; },
    setAttribute(name, value) { this[name] = value; },
    removeAttribute(name) { delete this[name]; },
    closest(selector) {
      if (selector === '[data-toast-action]' && this.dataset.toastAction !== undefined) return this;
      return null;
    }
  };
}

function createHarness(seedStorage = {}, options = {}) {
  const elements = new Map();
  for (const id of idMatches) elements.set(id, createElement(id));

  const trendCard = createElement('trend-card');
  const tabButtons = [...new Set(tabNames)].map((tab) => {
    const el = createElement(`tab-btn-${tab}`);
    el.dataset.tab = tab;
    return el;
  });
  const addButtons = [...new Set(openAddModes)].map((mode) => {
    const el = createElement(`open-add-${mode}`);
    el.dataset.openAdd = mode;
    return el;
  });
  const jumpButtons = [...new Set(tabJumpNames)].map((tab) => {
    const el = createElement(`jump-${tab}`);
    el.dataset.tabJump = tab;
    return el;
  });
  const screens = [...new Set(tabNames)].map((tab) => elements.get(`tab-${tab}`)).filter(Boolean);

  const storage = new Map(Object.entries(seedStorage));
  global.document = {
    activeElement: null,
    hidden: false,
    body: createElement('body'),
    getElementById(id) { return elements.get(id) || null; },
    querySelector(selector) {
      if (selector === '.trend-card') return trendCard;
      if (selector === 'link[rel="manifest"]') return createElement('manifest-link');
      const tabMatch = selector.match(/^\.tab-btn\[data-tab="(.+)"\]$/);
      if (tabMatch) return tabButtons.find((button) => button.dataset.tab === tabMatch[1]) || null;
      return null;
    },
    querySelectorAll(selector) {
      if (selector === '.tab-btn') return tabButtons;
      if (selector === '[data-open-add]') return addButtons;
      if (selector === '[data-tab-jump]') return jumpButtons;
      if (selector === '.tab-screen') return screens;
      return [];
    },
    createElement(tag) { return createElement(tag); },
    addEventListener() {}
  };
  const document = global.document;

  const context = {
    console,
    document,
    window: { addEventListener() {} },
    navigator: options.navigator || { clipboard: { writeText: async () => {} } },
    location: { protocol: 'http:', hostname: 'localhost' },
    localStorage: {
      getItem(key) { return storage.has(key) ? storage.get(key) : null; },
      setItem(key, value) { storage.set(key, String(value)); }
    },
    confirm: () => true,
    crypto: webcrypto,
    setInterval: () => 1,
    clearInterval: () => {},
    setTimeout: (fn) => { if (typeof fn === 'function') fn(); return 1; },
    clearTimeout: () => {},
    URL: {
      createObjectURL: () => 'blob:mock',
      revokeObjectURL: () => {}
    },
    Blob,
    File: typeof File === 'function' ? File : class File extends Blob { constructor(parts, name, opts) { super(parts, opts); this.name = name; } },
    Intl,
    Date,
    Math,
    Number,
    String,
    RegExp,
    Map,
    Set,
    Array,
    Object,
    JSON,
    Promise,
    Uint8Array,
    globalThis: null
  };
  context.globalThis = context;
  return { context, elements, storage };
}

function callFirst(element, type, event = {}) {
  if (!element.listeners[type] || !element.listeners[type].length) throw new Error(`${element.id} has no ${type} listener`);
  return element.listeners[type][0](event);
}

function runStartup(seedStorage) {
  const harness = createHarness(seedStorage);
  vm.runInNewContext(appCode, harness.context, { filename: 'app.js' });

  const form = harness.elements.get('deliveryForm');
  harness.elements.get('companyInput').value = 'DoorDash';
  harness.elements.get('earningsInput').value = '18.75';
  harness.elements.get('milesInput').value = '5.4';
  harness.elements.get('minutesInput').value = '24';
  harness.elements.get('zoneInput').value = 'South City';
  callFirst(form, 'submit', { preventDefault() {} });

  const saved = harness.storage.get('driveledger.deliveries.v1');
  if (!saved || !saved.includes('18.75') || !saved.includes('South City')) {
    throw new Error('manual delivery save did not persist full delivery details to localStorage');
  }
  const firstDelivery = JSON.parse(saved)[0];
  if (firstDelivery.source !== 'manual' || !firstDelivery.updatedAt || !firstDelivery.version) {
    throw new Error('manual delivery did not persist normalized metadata');
  }
  for (const key of ['date', 'note', 'notes', 'tags', 'deleted', 'createdAt', 'updatedAt', 'version']) {
    if (!(key in firstDelivery)) throw new Error(`manual delivery missing normalized ${key} field`);
  }

  harness.elements.get('companyInput').value = 'Uber Eats';
  harness.elements.get('earningsInput').value = '11.50';
  harness.elements.get('milesInput').value = '3.1';
  harness.elements.get('minutesInput').value = '18';
  harness.elements.get('zoneInput').value = 'Tower Grove';
  callFirst(harness.elements.get('saveAddAnotherBtn'), 'click', {});
  const afterAddAnother = JSON.parse(harness.storage.get('driveledger.deliveries.v1'));
  if (afterAddAnother.length < 2 || !afterAddAnother.some((d) => d.zone === 'Tower Grove')) {
    throw new Error('save + add another did not persist a second delivery');
  }

  harness.elements.get('offerPayInput').value = '9.75';
  harness.elements.get('offerMilesInput').value = '4.2';
  harness.elements.get('offerMinutesInput').value = '22';
  harness.elements.get('offerZoneInput').value = 'Kirkwood';
  callFirst(harness.elements.get('offerPayInput'), 'input', {});
  if (!harness.elements.get('decisionResult').innerHTML.includes('ACCEPT')) {
    throw new Error('accept calculator did not render an ACCEPT decision for a strong offer');
  }
  callFirst(harness.elements.get('saveOfferAsDeliveryBtn'), 'click', {});
  const savedAfterOffer = JSON.parse(harness.storage.get('driveledger.deliveries.v1'));
  if (savedAfterOffer.length < 3) throw new Error('save offer as delivery did not persist');
  if (!savedAfterOffer.some((d) => d.source === 'calculator' && d.zone === 'Kirkwood')) {
    throw new Error('calculator delivery did not persist source and zone metadata');
  }

  if (!harness.elements.get('heroShiftBtn').listeners.click?.length) {
    throw new Error('hero shift action is not wired');
  }
  callFirst(harness.elements.get('shiftBtn'), 'click', {});
  if (!harness.storage.get('driveledger.shift.v1')?.includes('startedAt')) {
    throw new Error('shift toggle did not persist shift state');
  }
  callFirst(harness.elements.get('shiftBtn'), 'click', {});
  const completedShift = JSON.parse(harness.storage.get('driveledger.shift.v1'));
  if (!Array.isArray(completedShift.shiftHistory) || !completedShift.shiftHistory.length || !completedShift.lastSummary) {
    throw new Error('ending a shift did not persist lastSummary and shiftHistory');
  }

  for (const id of ['projectedTotal', 'goalEta', 'avgDeliveryValue', 'taxMiles', 'vehicleCostToday', 'bestCompanyToday', 'bestZoneToday', 'performanceRecommendation']) {
    const el = harness.elements.get(id);
    if (!el) throw new Error(`phase 3 command center element missing in smoke harness: ${id}`);
    const rendered = `${el.textContent || ''} ${el.innerHTML || ''}`;
    if (/NaN|Infinity|undefined|null/.test(rendered)) {
      throw new Error(`phase 3 command center rendered unsafe value in ${id}: ${rendered}`);
    }
  }

  if (!harness.elements.get('bestCompanyToday').textContent || harness.elements.get('bestCompanyToday').textContent === '—') {
    throw new Error('best company command metric did not update after saved deliveries');
  }
  if (!harness.elements.get('bestZoneToday').textContent || harness.elements.get('bestZoneToday').textContent === '—') {
    throw new Error('best zone command metric did not update after saved deliveries');
  }
}

runStartup({});

function runMigrationSmoke() {
  const legacyDate = new Date().toISOString();
  const legacyDeliveries = [{
    id: 'legacy-1',
    company: 'NotAPlatform',
    earnings: '$22.40',
    miles: '0',
    minutes: 'bad',
    zone: '  South City  ',
    note: 'legacy note',
    createdAt: legacyDate,
    tags: ['Lunch', ' lunch ', '<script>']
  }];
  const legacySettings = {
    dailyGoal: '250',
    defaultCompany: 'BadApp',
    gasPrice: '3.25',
    mpg: '28',
    maintenancePerMile: '0.15',
    taxMileageRate: '0.70',
    minPerMile: '1.75',
    minPerHour: '24',
    minPayout: '8',
    maxMiles: '10',
    theme: 'neon'
  };
  const legacyShift = {
    active: true,
    startedAt: legacyDate,
    lastSummary: 123,
    shiftHistory: [{ startedAt: legacyDate, endedAt: legacyDate, summary: 'old shift' }]
  };
  const harness = createHarness({
    'driveledger.deliveries.v1': JSON.stringify(legacyDeliveries),
    'driveledger.settings.v1': JSON.stringify(legacySettings),
    'driveledger.shift.v1': JSON.stringify(legacyShift)
  });
  vm.runInNewContext(appCode, harness.context, { filename: 'app.js' });
  const migratedDeliveries = JSON.parse(harness.storage.get('driveledger.deliveries.v1'));
  const migratedSettings = JSON.parse(harness.storage.get('driveledger.settings.v1'));
  const migratedShift = JSON.parse(harness.storage.get('driveledger.shift.v1'));

  if (migratedDeliveries.length !== 1) throw new Error('legacy delivery was not preserved during migration');
  const d = migratedDeliveries[0];
  if (d.company !== 'Other' || d.miles !== 0 || d.note !== 'legacy note' || d.notes !== 'legacy note') {
    throw new Error('legacy delivery fields were not normalized safely');
  }
  for (const key of ['date', 'source', 'ocrText', 'ocrConfidence', 'tags', 'deleted', 'version']) {
    if (!(key in d)) throw new Error(`migrated delivery missing ${key}`);
  }
  if (migratedSettings.vehicleMpg !== 28 || migratedSettings.mpg !== 28) {
    throw new Error('settings MPG alias migration failed');
  }
  if (migratedSettings.maintenanceCostPerMile !== 0.15 || migratedSettings.maintenancePerMile !== 0.15) {
    throw new Error('settings maintenance alias migration failed');
  }
  if (migratedSettings.mileageDeductionRate !== 0.7 || migratedSettings.taxMileageRate !== 0.7) {
    throw new Error('settings mileage deduction alias migration failed');
  }
  if (migratedSettings.defaultCompany !== 'DoorDash' || migratedSettings.theme !== 'system' || migratedSettings.appDataVersion !== 4) {
    throw new Error('invalid settings were not defaulted during migration');
  }
  if (!Array.isArray(migratedShift.shiftHistory) || migratedShift.shiftHistory.length !== 1 || migratedShift.appDataVersion !== 4) {
    throw new Error('shift history migration failed');
  }
}

function runClipboardUnavailableSmoke() {
  const harness = createHarness({}, { navigator: {} });
  vm.runInNewContext(appCode, harness.context, { filename: 'app.js' });

  const form = harness.elements.get('deliveryForm');
  harness.elements.get('companyInput').value = 'DoorDash';
  harness.elements.get('earningsInput').value = '10.00';
  harness.elements.get('milesInput').value = '2.0';
  callFirst(form, 'submit', { preventDefault() {} });

  callFirst(harness.elements.get('copySummaryBtn'), 'click', {});
  if (!harness.elements.get('toast').textContent.includes('Copy is not available')) {
    throw new Error('copy summary should not claim success when Clipboard API is unavailable');
  }
}

runStartup({
  'driveledger.deliveries.v1': '{"not":"an array"}',
  'driveledger.settings.v1': '{"dailyGoal":"bad","defaultCompany":"Unknown","gasPrice":"NaN"}',
  'driveledger.shift.v1': '{"active":true,"startedAt":"not a date"}'
});
runClipboardUnavailableSmoke();
runMigrationSmoke();
console.log('DriveLedger startup smoke test passed');
