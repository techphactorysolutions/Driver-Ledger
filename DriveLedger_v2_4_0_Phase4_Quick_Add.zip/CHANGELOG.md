# Changelog

## 2.4.0

- Completed Phase 4 Fast Quick-Add Flow.
- Added a prominent Today-screen Quick Add button that opens a bottom-sheet entry flow instead of switching tabs.
- Added quick-add fields for company, earnings, miles, minutes, zone, and collapsible optional notes.
- Added quick-add validation for valid company, earnings greater than 0, miles 0 or greater, and minutes 0 or greater.
- Added smart quick-add defaults from the most recent saved company/zone, with Settings fallback.
- Added Quick Add Save and Save + Add Another actions with immediate localStorage persistence, dashboard updates, and toast feedback.
- Added quick-add preview support, including safe zero-mile handling without unsafe Infinity math.
- Expanded mocked startup smoke tests for quick-add open/save/invalid-save behavior and dashboard refresh after quick save.
- Expanded Python static tests for Phase 4 bottom-sheet surfaces and helper functions.
- Bumped PWA service worker cache to `driveledger-v8`.

## 2.3.0

- Completed Phase 3 Premium Today Command Center.
- Reworked Today into dedicated Pace, Efficiency, Tax, Performance, and Last Delivery Impact cards.
- Added projected today total and explicit goal ETA metrics.
- Added best company and best zone command metrics.
- Added in-hero Start/End Day action wired to the existing shift toggle.
- Added live pace, efficiency, and performance recommendation text based on real local data.
- Added safe $/mile ranking helper to avoid unsafe Infinity math with zero-mile legacy records.
- Expanded smoke tests for Phase 3 command center rendering and hero shift wiring.
- Expanded Python static tests for Phase 3 Today screen surfaces and helper functions.
- Bumped PWA service worker cache to `driveledger-v7`.

## 2.2.0

- Completed Phase 2 data model and storage upgrade.
- Added full normalized delivery schema fields: date, note/notes, OCR text, tags, deleted flag, and current data version.
- Added long-form settings keys with backward-compatible aliases for existing UI logic.
- Added shift `lastSummary`, `shiftHistory`, and shift-history normalization.
- Added startup persistence for normalized migrated localStorage state.
- Added backup schema metadata to JSON exports.
- Improved backup import source normalization for unknown-source records.
- Expanded smoke tests for legacy data migration and shift-history persistence.
- Expanded Python static tests for Phase 2 schema and migration hooks.
- Bumped PWA service worker cache to `driveledger-v6`.

## 2.1.1

- Completed Phase 1 full audit/stabilization pass on the v2.1 baseline.
- Fixed summary copy feedback so the app no longer claims a summary was copied when the Clipboard API is unavailable.
- Expanded the mocked startup smoke test to cover unavailable Clipboard API behavior.
- Expanded Python static tests to verify service-worker cached assets exist.
- Expanded event-binding checks for Save + Add Another and Cancel Edit.
- Bumped PWA service worker cache to `driveledger-v5`.

## 2.1.0

- Added calculator zone capture.
- Added delivery source metadata normalization.
- Added OCR confidence, updatedAt, and version metadata on normalized delivery records.
- Added source labels in History.
- Added Save + Add Another for faster repeated manual entry.
- Added pre-import rollback snapshots.
- Added Restore Import Rollback control.
- Added source and OCR confidence columns to standard and tax CSV exports.
- Expanded mocked startup smoke coverage.
- Bumped PWA service worker cache to `driveledger-v4`.
