# DriveLedger

DriveLedger is a local-first Progressive Web App for gig delivery drivers. It tracks daily earnings, mileage, estimated profit, tax mileage deduction, platform performance, zone performance, shift pace, screenshot OCR-assisted entry, and accept/decline order decisions.

## Current release

Version: `2.4.0` Phase 4 Fast Quick-Add Flow.

This release preserves the static PWA architecture. There is no backend, database server, framework, build step, or account system. The app runs from plain static files and stores user data locally in the browser.

## Included features

- Premium Today Command Center with dedicated Pace, Efficiency, Tax, Performance, and Last Delivery Impact cards.
- **Fast Quick Add bottom sheet from Today** so drivers can add a delivery without switching tabs.
- Quick Add fields for company, earnings, miles, minutes, zone, and optional collapsible notes.
- Quick Add validation for valid company, earnings greater than 0, miles 0 or greater, and minutes 0 or greater.
- Quick Add smart defaults using the last saved company/zone, falling back to Settings defaults.
- Quick Add **Save** and **Save + Add Another** actions with immediate dashboard updates and toast confirmation.
- Main hero card with gross earnings, estimated profit, daily goal percentage, progress bar, shift status, and an in-card start/end day action.
- Pace card with gross/hour, profit/hour, projected today total, goal ETA, and a live pace recommendation.
- Efficiency card with gross $/mile, profit $/mile, business miles, average delivery value, and order-quality coaching.
- Tax card with mileage deduction estimate, mileage deduction rate, tracked business miles, estimated vehicle cost, and delivery count.
- Performance card with driver score, best company today, best zone today, time working, and simple recommendation text.
- Profit Mode using editable gas price, MPG, maintenance cost per mile, and mileage deduction rate.
- Accept Calculator that recommends **ACCEPT**, **BORDERLINE**, or **DECLINE** using user-defined minimum payout, $/mile, $/hour, and max-mile rules.
- Accept Calculator zone capture so saved calculator deliveries contribute to zone analytics.
- Screenshot OCR review card with detected company, earnings, miles, and confidence before applying values.
- Existing Add tab manual delivery entry with optional minutes, zone, notes, and **Save + Add Another** support.
- Delivery edit, duplicate, delete, and undo-delete support.
- Grouped History by day with daily totals, per-delivery profit details, and source labels.
- Company and zone performance breakdowns.
- Daily shift summary with copy support.
- Standard CSV export, tax CSV export, JSON backup, JSON import, and pre-import rollback restore.
- Local-first storage using browser `localStorage` under `driveledger.*` keys.

## Phase 4 quick-add notes

The Today screen now has a prominent **Quick Add** button that opens a one-hand bottom sheet instead of sending the user to the Add tab. The sheet keeps the command center in context and is optimized for fast delivery entry between orders.

Quick Add supports:

```text
Company
Earnings
Miles
Minutes
Zone
Optional notes
Save
Save + Add Another
Cancel
```

The quick-add flow writes the same normalized delivery records as the full Add tab. A zero-mile value is allowed for quick add when the driver does not yet know mileage, but a blank mileage field is still rejected so accidental saves are avoided.

## Phase 3 command center notes

The Today screen uses real local delivery, shift, and settings data to answer:

```text
How much did I earn today?
What is my estimated profit?
Am I ahead or behind goal?
What is my gross hourly pace?
What is my profit hourly pace?
What is my gross and profit $/mile?
How many business miles and deliveries did I track?
Which company is strongest today?
Which zone is strongest today?
When will I hit my goal at the current pace?
What is my driver score?
```

The command cards intentionally avoid fake charts or fake data. Empty states stay descriptive until real deliveries are saved. All displayed values are guarded against `NaN`, `Infinity`, `undefined`, and `null` in normal startup and smoke-tested flows.

## Phase 2 storage upgrade notes

Delivery records are normalized on app startup and when saved/imported. The current delivery schema includes:

```text
id
date
createdAt
updatedAt
company
earnings
miles
minutes
zone
note
notes
source: manual, ocr, calculator, import
ocrText
ocrConfidence
tags
deleted
version
```

Settings are also normalized and include clearer long-form keys while preserving older aliases used by existing UI code:

```text
dailyGoal
defaultCompany
defaultZone
gasPrice
vehicleMpg / mpg
maintenanceCostPerMile / maintenancePerMile
mileageDeductionRate / taxMileageRate
minimumDollarPerMile / minPerMile
minimumDollarPerHour / minPerHour
minimumPayout / minPayout
maxMiles
theme
appDataVersion
```

Shift data includes:

```text
active
startedAt
endedAt
lastSummary
shiftHistory
appDataVersion
```

On startup, DriveLedger normalizes and re-saves the local state. This gives older saved data the new fields without requiring a backend migration. Corrupted JSON or impossible values are safely defaulted or discarded instead of crashing the app.

## Local data keys

DriveLedger currently uses these localStorage keys:

- `driveledger.deliveries.v1`
- `driveledger.settings.v1`
- `driveledger.shift.v1`
- `driveledger.rollback.v1`

## Run locally

Because this is a static PWA, no backend server is required. Open `index.html` directly for simple testing, or serve the folder with any static server:

```bash
python -m http.server 8000
```

Then open `http://localhost:8000`.

## Install on iPhone/iPad

1. Host the folder with HTTPS, such as Netlify Drop.
2. Open the hosted site in Safari.
3. Tap Share.
4. Tap **Add to Home Screen**.

## Tests

The ZIP includes a no-dependency smoke test suite. It checks static package structure, manifest/icon paths, JavaScript syntax, UI wiring, local storage namespacing, startup behavior in a mocked browser, manual delivery save, quick-add open/save/invalid-save behavior, save-and-add-another, calculator zone/source persistence, accept-calculator behavior, shift persistence, shift history persistence, local schema migration, service-worker cached asset references, Clipboard API fallback behavior, and command center rendering safety.

```bash
python -m unittest discover -s tests -v
```

Optional Node scripts:

```bash
npm run syntax
npm run smoke
```

## Architecture notes

- There is no FastAPI/backend layer in this ZIP.
- Data is stored locally in browser `localStorage`.
- Screenshot OCR uses Tesseract.js from jsDelivr on first load. If the CDN is unavailable, the app falls back to manual entry.
- Tax and expense numbers are estimates. The mileage rate, gas price, MPG, and maintenance cost are editable in Settings.
- The smoke test is a mocked browser test, not a substitute for manual iPhone/iPad Safari testing.
