# Audit Report

## 2.7.0 — Phase 7 Centralized Profit Engine

Phase 7 was implemented on top of the Phase 6 Accept / Decline Calculator ZIP while preserving the static, local-first PWA architecture. No backend, framework, build step, or account system was added.

## Findings and fixes

### `app.js`

- Added a centralized `ProfitEngine` section for the app's core financial calculations.
- Added reusable calculation helpers for:
  - fuel cost per mile
  - maintenance cost
  - vehicle cost per mile
  - estimated delivery profit
  - estimated profit per mile
  - gross dollar per mile
  - gross hourly rate
  - profit hourly rate
  - mileage deduction
  - projected daily earnings
  - goal ETA
  - driver score
  - row/day summaries
- Updated dashboard summaries, command-center cards, delivery previews, quick-add preview, OCR preview, Accept Calculator, History rows, shift recap, and CSV exports to use centralized helpers.
- Preserved compatibility wrappers including `costPerMile()`, `deliveryProfit()`, `safeRate()`, and `hourlyRate()` so earlier Phase 6 logic remains stable.
- Replaced scattered formulas such as direct `earnings / miles` and `earnings - miles * costPerMile()` with safe Profit Engine calls where they affected app surfaces.
- Hardened `bounded()` so malformed strings such as `"NaN"` or nonnumeric values fall back to defaults instead of being interpreted as `0`. Valid zero settings still remain valid where allowed.

### `tools/smoke-startup.js`

- Added smoke checks for expected first-delivery estimated profit and mileage deduction output using the centralized math path.
- Existing smoke coverage still verifies manual save, quick add, calculator decisions, OCR review, shift persistence, migration safety, and unsafe-output prevention.

### `tests/test_static_app.py`

- Added Phase 7 static tests confirming the Profit Engine exists.
- Added checks for the reusable calculation helper names.
- Added checks that old direct vehicle-cost formulas were removed from app surfaces.

### `service-worker.js`

- Bumped cache version to `driveledger-v11`.

### `package.json`

- Bumped app version to `2.7.0`.

### `README.md` and `CHANGELOG.md`

- Documented the centralized Profit Engine and Phase 7 behavior.

## Tests run

```bash
npm run syntax
npm run smoke
python -m unittest discover -s tests -v
```

Results after implementation:

```text
npm run syntax: passed
npm run smoke: passed
python unittest: Ran 17 tests — OK
```

## Acceptance criteria status

- Fuel cost per mile helper: passed.
- Maintenance cost helper: passed.
- Vehicle cost per mile helper: passed.
- Estimated delivery profit helper: passed.
- Estimated profit per mile helper: passed.
- Gross dollar per mile helper: passed.
- Gross hourly helper: passed.
- Profit hourly helper: passed.
- Mileage deduction helper: passed.
- Projected daily earnings helper: passed.
- Goal ETA helper: passed.
- Driver score helper: passed.
- Dashboard uses centralized summary math: passed.
- Calculator uses centralized math: passed.
- History/export surfaces use centralized math: passed.
- No unsafe NaN/Infinity output in tested states: passed.
- Tests pass: passed.

## Remaining risks

- Profit, deduction, and driver score values remain estimates based on user-maintained settings.
- Real-world variables such as restaurant wait time, parking, traffic, hidden tips, and drop-off difficulty are not automatically detected.
- Smoke tests use a mocked browser, not real iPhone/iPad Safari automation.
- Data is still stored in browser `localStorage`; users should export JSON backups before clearing site data.
- OCR still depends on the remote Tesseract.js CDN on first load.

## Manual QA checklist

Use this checklist on iPhone/iPad Safari or a hosted Netlify build:

1. Open the Today screen fresh.
2. Add a manual delivery with earnings, miles, and minutes.
3. Confirm estimated profit, tax deduction, gross $/mile, profit $/mile, and hourly pace update.
4. Open Quick Add and save another delivery.
5. Confirm Today, History, and company/zone breakdowns use matching totals.
6. Open Decide, calculate a strong offer, and confirm ACCEPT metrics match the expected profit math.
7. Save the offer as completed and confirm History shows calculator source.
8. Use OCR review and confirm preview profit uses the same vehicle-cost assumptions.
9. Export standard CSV and tax CSV.
10. Confirm export profit/deduction values match the app surfaces.
11. Change gas price, MPG, maintenance, and mileage deduction settings.
12. Confirm dashboard, calculator, and previews update consistently.
13. Reload and confirm data persists.

## 2.6.0 — Phase 6 Accept / Decline Calculator v2

Phase 6 was implemented on top of the Phase 5 OCR Review ZIP while preserving the static, local-first PWA architecture. No backend, framework, build step, or account system was added.

## Findings and fixes

### `app.js`

- Upgraded the Decide tab decision logic into a transparent order decision assistant.
- Added `safeRate()` and `hourlyRate()` helpers to avoid unsafe division output.
- Added `buildOfferThresholds()` and `makeThreshold()` so each offer shows pass/fail rows for active rules.
- Added gross $/mile, gross hourly pace, estimated profit, profit $/mile, and profit hourly metrics.
- Added settings-based decisions using minimum payout, minimum $/mile, minimum $/hour, max miles, gas price, MPG, and maintenance cost per mile.
- Added explicit invalid-input handling so zero/missing pay, miles, or minutes do not save a calculator delivery.
- Added `buildDecisionSummaryText()` and `copyDecisionSummary()` for copyable order recommendations.
- Added `clearOfferCalculator()` for a real Clear action.
- Updated calculator saves to persist selected company, zone, optional note, `source: "calculator"`, and a decision tag.
- Fixed a data-normalization issue in `bounded()` where missing numeric settings with a minimum of `0` could normalize to `0` instead of the intended default. This affected defaults such as gas price, maintenance cost, tax rate, and order thresholds.

### `index.html`

- Added optional calculator note input.
- Added Calculate Only, Clear, Copy Decision, and Save as Completed actions.
- Preserved the existing Decide tab and static PWA structure.

### `styles.css`

- Added mobile-friendly action layout for the calculator.
- Added pass/fail threshold row styling.

### `tools/smoke-startup.js`

- Added Phase 6 calculator smoke coverage for:
  - ACCEPT case
  - BORDERLINE case
  - DECLINE case
  - invalid zero-input rejection
  - Save as completed delivery with `source: "calculator"`
  - calculator note persistence
  - copy decision summary
  - clear action
  - settings thresholds affecting decision results
  - no unsafe `NaN`, `Infinity`, `undefined`, or `null` calculator output

### `tests/test_static_app.py`

- Added static checks for Phase 6 DOM surfaces.
- Added event-binding checks for Calculate Only, Clear, Copy Decision, and Save as Completed.
- Added helper-function checks for the upgraded decision logic.

### `service-worker.js`

- Bumped cache version to `driveledger-v10`.

### `package.json`

- Bumped app version to `2.6.0`.

### `README.md`

- Documented Phase 6 calculator behavior, inputs, outputs, actions, and persistence.

### `CHANGELOG.md`

- Added the `2.6.0` Phase 6 release entry.

## Tests run

```bash
npm run syntax
npm run smoke
python -m unittest discover -s tests -v
```

Results after implementation:

```text
npm run syntax: passed
npm run smoke: passed
python unittest: Ran 16 tests — OK
```

## Acceptance criteria status

- Input fields for company, payout, miles, estimated minutes, zone, and optional note: passed.
- Settings used for minimum $/mile, minimum $/hour, minimum payout, max miles, gas price, MPG, and maintenance cost per mile: passed.
- ACCEPT output: passed.
- BORDERLINE output: passed.
- DECLINE output: passed.
- Gross $/mile shown: passed.
- Estimated gross hourly shown: passed.
- Estimated profit shown: passed.
- Estimated profit $/mile shown: passed.
- Estimated profit hourly shown: passed.
- Threshold pass/fail rows shown: passed.
- Calculate Only action: passed.
- Save as completed delivery action: passed.
- Clear calculator action: passed.
- Copy decision summary action: passed.
- Invalid/zero inputs rejected safely: passed.
- Save offer creates delivery with `source: "calculator"`: passed.
- No unsafe NaN/Infinity output in tested calculator states: passed.
- Tests pass: passed.

## Remaining risks

- Calculator decisions are estimates and depend on user-maintained settings.
- Real-world wait time, traffic, restaurant speed, parking, and drop-off difficulty are not automatically detected.
- Smoke tests use a mocked browser, not real iPhone/iPad Safari automation.
- Data is still stored in browser `localStorage`; users should export JSON backups before clearing site data.
- OCR still depends on the remote Tesseract.js CDN on first load.
- Backup import still supports replace + rollback. Merge/deduplicate import mode remains a future phase.

## Manual QA checklist

Use this checklist on iPhone/iPad Safari or a hosted Netlify build:

1. Open the Decide tab.
2. Enter a strong offer and tap Calculate Only. Confirm ACCEPT.
3. Confirm gross $/mile, gross hourly, profit, profit $/mile, and profit hourly show.
4. Confirm all threshold rows show Pass for a strong offer.
5. Enter a close offer and confirm BORDERLINE.
6. Enter a weak offer and confirm DECLINE.
7. Enter zero or blank values and confirm saving is rejected.
8. Add a note and tap Copy Decision. Confirm copied text includes decision and note.
9. Tap Clear and confirm fields reset.
10. Save a valid offer as completed.
11. Confirm Today updates immediately.
12. Confirm History shows the delivery with Calculator source, zone, minutes, and note.
13. Change decision thresholds in Settings and confirm the same offer can change decision result.
14. Reload and confirm saved calculator delivery persists.

---

# DriveLedger Phase 5 Audit Report

## Phase

Phase 5 — Screenshot OCR Review System

## Base ZIP

`DriveLedger_v2_4_0_Phase4_Quick_Add.zip`

## Objective

Upgrade screenshot scanning so OCR results are reviewed, edited, and explicitly saved by the user before any delivery is written to localStorage.

## Architecture status

- Static PWA preserved: passed.
- No backend added: passed.
- No framework/build system added: passed.
- Existing Today Command Center preserved: passed.
- Existing Quick Add bottom sheet preserved: passed.
- Existing Add tab manual flow preserved: passed.
- Existing localStorage data model preserved: passed.
- Existing exports, history, settings, calculator, and rollback features preserved: passed.

## Changes made

### `index.html`

- Rebuilt the OCR review card into a review-first workflow.
- Added editable OCR review fields:
  - `ocrCompanyInput`
  - `ocrEarningsInput`
  - `ocrMilesInput`
  - `ocrMinutesInput`
- Added detected minutes display with `ocrMinutes`.
- Added confidence label display with `ocrConfidenceLabel`.
- Added `ocrSavePreview` for reviewed OCR profit/pace preview.
- Added direct **Save Reviewed** action with `saveOcrBtn`.
- Added explicit **Cancel** action with `cancelOcrBtn`.
- Preserved **Use in Form** and **Clear Scan** actions.
- Preserved expandable raw OCR text display.

### `styles.css`

- Added scan state styling for loading, success, and failed states.
- Added OCR review header layout.
- Added editable OCR grid layout.
- Added responsive OCR action layout for mobile screens.
- Added confidence label status styling for good, warning, and bad confidence states.

### `app.js`

- Added OCR DOM references for editable review fields and direct save actions.
- Added `setScanState()` to centralize loading/success/failed OCR state display.
- Added `confidenceLabel()` with:
  - High confidence
  - Medium confidence
  - Needs review
- Added `detectMinutes()` for OCR minute extraction.
- Updated `parseOCR()` to return company, earnings, miles, minutes, and confidence.
- Changed unknown platform detection to require review instead of automatically boosting confidence as `Other`.
- Updated `renderOCRReview()` to populate editable fields and confidence labels.
- Added `renderOCRSavePreview()` for reviewed OCR delivery preview.
- Added `readOCRReviewFields()` with validation before saving.
- Added `saveReviewedOCR()` so OCR can be saved directly only after explicit user review.
- Updated **Use in Form** to move reviewed values into the manual form rather than raw parsed values.
- Hardened Tesseract unavailable and Tesseract failure states so OCR failure does not crash the app.
- Preserved manual Add tab, Quick Add, Accept Calculator, history, exports, and backup flows.

### `tools/smoke-startup.js`

- Added mocked Tesseract success coverage.
- Added sample DoorDash OCR parsing coverage for company, earnings, miles, and minutes.
- Added reviewed OCR save coverage verifying `source: "ocr"` and OCR metadata.
- Added low-confidence OCR coverage proving scans do not autosave.
- Added invalid low-confidence save rejection coverage.
- Added Tesseract failure coverage proving the app shows a failed scan state instead of crashing.

### `tests/test_static_app.py`

- Added static coverage for Phase 5 OCR review DOM surfaces.
- Added wiring checks for `saveOcrBtn` and `cancelOcrBtn`.
- Added checks for OCR review helper functions and smoke coverage markers.

### `service-worker.js`

- Bumped cache version to `driveledger-v9`.

### `package.json`

- Bumped app version to `2.5.0`.

### `README.md`

- Documented the Phase 5 OCR review-first workflow.
- Updated current release and test coverage notes.

### `CHANGELOG.md`

- Added the `2.5.0` Phase 5 release entry.

## Tests run

```bash
npm run syntax
npm run smoke
python -m unittest discover -s tests -v
```

Results after implementation:

```text
npm run syntax: passed
npm run smoke: passed
python unittest: Ran 15 tests — OK
```

## Acceptance criteria status

- Screenshot upload input: passed.
- OCR loading state: passed.
- OCR success state: passed.
- OCR failed state: passed.
- Parses likely company: passed.
- Parses likely earnings: passed.
- Parses likely miles: passed.
- Parses likely minutes when present: passed.
- Shows OCR review card before saving: passed.
- Shows detected company, earnings, miles, minutes, confidence, and raw text: passed.
- User can edit detected fields: passed.
- User can save reviewed OCR as delivery: passed.
- User can cancel OCR review: passed.
- User can clear OCR result: passed.
- Low confidence shows Needs review: passed.
- OCR failure does not crash the app: passed.
- Low-confidence OCR does not autosave: passed.
- Saving reviewed OCR writes `source: "ocr"`: passed.
- Tests pass: passed.

## Remaining risks

- OCR still depends on the remote Tesseract.js CDN on first load.
- OCR parsing is heuristic and may still misread unusual screenshots; the review-first workflow is designed to catch this.
- Smoke tests use mocked Tesseract/browser behavior, not real iPhone Safari camera/gallery OCR automation.
- Data is still stored in browser `localStorage`; users should export JSON backups before clearing site data.
- Backup import still supports replace + rollback. Merge/deduplicate import mode remains a future phase.
- Expense, profit, and tax calculations are estimates and depend on user-maintained settings.

## Manual QA checklist

Use this checklist on iPhone/iPad Safari or a hosted Netlify build:

1. Open app fresh.
2. Tap Scan Screenshot from Today.
3. Select a DoorDash/Uber-style screenshot.
4. Confirm scanning state appears.
5. Confirm review card appears after scan.
6. Confirm company, earnings, miles, minutes, confidence, and raw text appear.
7. Edit detected earnings, miles, or minutes.
8. Confirm OCR save preview updates.
9. Tap Save Reviewed.
10. Confirm the delivery appears in Today and History with source OCR.
11. Test Use in Form and confirm reviewed values move into the manual form.
12. Test Cancel and confirm no delivery is saved.
13. Test Clear Scan and confirm review/raw text/image reset.
14. Turn off internet or block Tesseract and confirm OCR failure message appears without crashing.
15. Confirm Quick Add still works.
16. Confirm manual Add tab still works.
17. Confirm Accept Calculator still works.
18. Reload and confirm data persists.
