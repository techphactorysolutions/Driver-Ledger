(() => {
  const STORE_KEY = "driveledger.deliveries.v1";
  const SETTINGS_KEY = "driveledger.settings.v1";
  const SHIFT_KEY = "driveledger.shift.v1";
  const ROLLBACK_KEY = "driveledger.rollback.v1";
  const DATA_VERSION = 4;
  const BACKUP_VERSION = 4;

  const money = new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" });
  const $ = (id) => document.getElementById(id);

  const allowedCompanies = new Set([
    "DoorDash",
    "Uber Eats",
    "Grubhub",
    "Catering",
    "Instacart",
    "Spark",
    "Roadie",
    "Other"
  ]);

  const validSources = new Set(["manual", "ocr", "calculator", "import"]);

  const defaultSettings = {
    dailyGoal: 200,
    defaultCompany: "DoorDash",
    defaultZone: "",
    gasPrice: 3.5,
    vehicleMpg: 25,
    maintenanceCostPerMile: 0.12,
    mileageDeductionRate: 0.67,
    minimumDollarPerMile: 1.5,
    minimumDollarPerHour: 20,
    minimumPayout: 7,
    maxMiles: 12,
    theme: "system",
    appDataVersion: DATA_VERSION
  };

  let deliveries = normalizeDeliveries(readJSON(STORE_KEY, []));
  let settings = normalizeSettings(readJSON(SETTINGS_KEY, {}));
  let shift = normalizeShift(readJSON(SHIFT_KEY, { active: false, startedAt: null, endedAt: null }));
  let lastOCRText = "";
  let lastOCRParsed = null;
  let lastDayKey = todayKey();
  let toastTimer = null;
  let lastDeleted = null;
  let toastAction = null;

  const els = {
    todayHero: $("todayHero"),
    todayEarned: $("todayEarned"),
    profitLine: $("profitLine"),
    goalPercent: $("goalPercent"),
    goalBar: $("goalBar"),
    goalText: $("goalText"),
    goalRemaining: $("goalRemaining"),
    shiftStatus: $("shiftStatus"),
    heroStatusLabel: $("heroStatusLabel"),
    heroShiftBtn: $("heroShiftBtn"),
    paceCard: $("paceCard"),
    paceStatus: $("paceStatus"),
    paceRecommendation: $("paceRecommendation"),
    projectedTotal: $("projectedTotal"),
    goalEta: $("goalEta"),
    efficiencyCard: $("efficiencyCard"),
    efficiencyStatus: $("efficiencyStatus"),
    efficiencyRecommendation: $("efficiencyRecommendation"),
    profitToday: $("profitToday"),
    profitHour: $("profitHour"),
    avgHour: $("avgHour"),
    avgMile: $("avgMile"),
    profitMile: $("profitMile"),
    avgDeliveryValue: $("avgDeliveryValue"),
    taxCard: $("taxCard"),
    taxDeduction: $("taxDeduction"),
    taxRateLabel: $("taxRateLabel"),
    taxMiles: $("taxMiles"),
    vehicleCostToday: $("vehicleCostToday"),
    taxRecommendation: $("taxRecommendation"),
    ordersCount: $("ordersCount"),
    milesToday: $("milesToday"),
    performanceCard: $("performanceCard"),
    bestCompanyToday: $("bestCompanyToday"),
    bestZoneToday: $("bestZoneToday"),
    performanceRecommendation: $("performanceRecommendation"),
    timeWorking: $("timeWorking"),
    driverScore: $("driverScore"),
    driverScoreTitle: $("driverScoreTitle"),
    driverScoreDetail: $("driverScoreDetail"),
    trendTitle: $("trendTitle"),
    trendDetail: $("trendDetail"),
    trendCard: document.querySelector(".trend-card"),
    dailySummary: $("dailySummary"),
    companyBreakdown: $("companyBreakdown"),
    zoneBreakdown: $("zoneBreakdown"),
    historyList: $("historyList"),
    goalInput: $("goalInput"),
    defaultCompanyInput: $("defaultCompanyInput"),
    gasPriceInput: $("gasPriceInput"),
    mpgInput: $("mpgInput"),
    maintenanceInput: $("maintenanceInput"),
    taxRateInput: $("taxRateInput"),
    minPerMileInput: $("minPerMileInput"),
    minPerHourInput: $("minPerHourInput"),
    minPayoutInput: $("minPayoutInput"),
    maxMilesInput: $("maxMilesInput"),
    defaultZoneInput: $("defaultZoneInput"),
    editDeliveryId: $("editDeliveryId"),
    companyInput: $("companyInput"),
    earningsInput: $("earningsInput"),
    milesInput: $("milesInput"),
    minutesInput: $("minutesInput"),
    zoneInput: $("zoneInput"),
    notesInput: $("notesInput"),
    quickAddOpenBtn: $("quickAddOpenBtn"),
    quickAddSheet: $("quickAddSheet"),
    quickAddForm: $("quickAddForm"),
    quickCancelBtn: $("quickCancelBtn"),
    quickCompanyInput: $("quickCompanyInput"),
    quickEarningsInput: $("quickEarningsInput"),
    quickMilesInput: $("quickMilesInput"),
    quickMinutesInput: $("quickMinutesInput"),
    quickZoneInput: $("quickZoneInput"),
    quickNotesDetails: $("quickNotesDetails"),
    quickNotesInput: $("quickNotesInput"),
    quickDeliveryPreview: $("quickDeliveryPreview"),
    quickSaveBtn: $("quickSaveBtn"),
    quickSaveAnotherBtn: $("quickSaveAnotherBtn"),
    deliveryPreview: $("deliveryPreview"),
    saveDeliveryBtn: $("saveDeliveryBtn"),
    saveAddAnotherBtn: $("saveAddAnotherBtn"),
    cancelEditBtn: $("cancelEditBtn"),
    screenshotInput: $("screenshotInput"),
    previewImage: $("previewImage"),
    scanStatus: $("scanStatus"),
    ocrReview: $("ocrReview"),
    ocrCompany: $("ocrCompany"),
    ocrEarnings: $("ocrEarnings"),
    ocrMiles: $("ocrMiles"),
    ocrMinutes: $("ocrMinutes"),
    ocrConfidence: $("ocrConfidence"),
    ocrConfidenceLabel: $("ocrConfidenceLabel"),
    ocrCompanyInput: $("ocrCompanyInput"),
    ocrEarningsInput: $("ocrEarningsInput"),
    ocrMilesInput: $("ocrMilesInput"),
    ocrMinutesInput: $("ocrMinutesInput"),
    ocrSavePreview: $("ocrSavePreview"),
    saveOcrBtn: $("saveOcrBtn"),
    applyOcrBtn: $("applyOcrBtn"),
    cancelOcrBtn: $("cancelOcrBtn"),
    clearOcrBtn: $("clearOcrBtn"),
    ocrDetails: $("ocrDetails"),
    ocrText: $("ocrText"),
    offerPayInput: $("offerPayInput"),
    offerMilesInput: $("offerMilesInput"),
    offerMinutesInput: $("offerMinutesInput"),
    offerCompanyInput: $("offerCompanyInput"),
    offerZoneInput: $("offerZoneInput"),
    offerNoteInput: $("offerNoteInput"),
    decisionResult: $("decisionResult"),
    calculateOfferBtn: $("calculateOfferBtn"),
    clearOfferBtn: $("clearOfferBtn"),
    copyDecisionBtn: $("copyDecisionBtn"),
    saveOfferAsDeliveryBtn: $("saveOfferAsDeliveryBtn"),
    shiftBtn: $("shiftBtn"),
    exportBtn: $("exportBtn"),
    exportTaxBtn: $("exportTaxBtn"),
    backupBtn: $("backupBtn"),
    restoreRollbackBtn: $("restoreRollbackBtn"),
    importInput: $("importInput"),
    copySummaryBtn: $("copySummaryBtn"),
    saveSettingsBtn: $("saveSettingsBtn"),
    clearTodayBtn: $("clearTodayBtn"),
    toast: $("toast")
  };

  function readJSON(key, fallback) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch {
      return fallback;
    }
  }

  function writeJSON(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch {
      toast("Could not save. Device storage may be full or blocked.");
    }
  }

  function persistNormalizedState() {
    writeJSON(STORE_KEY, deliveries);
    writeJSON(SETTINGS_KEY, settings);
    writeJSON(SHIFT_KEY, shift);
  }

  function normalizeDeliveries(value) {
    if (!Array.isArray(value)) return [];
    return value.map((item) => normalizeDelivery(item)).filter(Boolean);
  }

  function normalizeDelivery(item) {
    if (!item || typeof item !== "object") return null;
    const earnings = round2(num(item.earnings));
    const miles = round1(num(item.miles));
    const createdRaw = item.createdAt || item.date || item.timestamp || new Date().toISOString();
    const createdAt = new Date(createdRaw);
    const updatedAt = item.updatedAt && !Number.isNaN(new Date(item.updatedAt).getTime())
      ? new Date(item.updatedAt)
      : createdAt;
    if (!earnings || earnings <= 0 || earnings > 10000) return null;
    if (!Number.isFinite(miles) || miles < 0 || miles > 1000) return null;
    if (Number.isNaN(createdAt.getTime())) return null;
    const company = allowedCompanies.has(item.company) ? item.company : "Other";
    const minutesRaw = num(item.minutes);
    const notes = cleanText(item.notes ?? item.note ?? "", 500);
    const inferredSource = item.ocrText ? "ocr" : "manual";
    const source = validSources.has(item.source) ? item.source : inferredSource;
    const normalized = {
      id: String(item.id || makeId()),
      date: todayKey(createdAt),
      company,
      earnings,
      miles,
      minutes: minutesRaw > 0 && minutesRaw <= 1440 ? round1(minutesRaw) : 0,
      zone: cleanText(item.zone || "", 80),
      note: notes,
      notes,
      source,
      ocrText: cleanText(item.ocrText || "", 20000),
      ocrConfidence: bounded(item.ocrConfidence, 0, 100, 0, 1),
      tags: normalizeTags(item.tags),
      deleted: Boolean(item.deleted),
      createdAt: createdAt.toISOString(),
      updatedAt: updatedAt.toISOString(),
      version: DATA_VERSION
    };
    return normalized;
  }

  function normalizeSettings(value) {
    const raw = value && typeof value === "object" ? value : {};
    const vehicleMpg = bounded(raw.vehicleMpg ?? raw.mpg, 1, 200, defaultSettings.vehicleMpg, 1);
    const maintenanceCostPerMile = bounded(raw.maintenanceCostPerMile ?? raw.maintenancePerMile, 0, 10, defaultSettings.maintenanceCostPerMile, 2);
    const mileageDeductionRate = bounded(raw.mileageDeductionRate ?? raw.taxMileageRate, 0, 10, defaultSettings.mileageDeductionRate, 2);
    const minimumDollarPerMile = bounded(raw.minimumDollarPerMile ?? raw.minPerMile, 0, 50, defaultSettings.minimumDollarPerMile, 2);
    const minimumDollarPerHour = bounded(raw.minimumDollarPerHour ?? raw.minPerHour, 0, 500, defaultSettings.minimumDollarPerHour, 2);
    const normalized = {
      dailyGoal: bounded(raw.dailyGoal, 1, 100000, defaultSettings.dailyGoal, 2),
      defaultCompany: allowedCompanies.has(raw.defaultCompany) ? raw.defaultCompany : defaultSettings.defaultCompany,
      defaultZone: cleanText(raw.defaultZone || "", 80),
      gasPrice: bounded(raw.gasPrice, 0, 20, defaultSettings.gasPrice, 2),
      vehicleMpg,
      maintenanceCostPerMile,
      mileageDeductionRate,
      minimumDollarPerMile,
      minimumDollarPerHour,
      minimumPayout: bounded(raw.minimumPayout ?? raw.minPayout, 0, 500, defaultSettings.minimumPayout, 2),
      maxMiles: bounded(raw.maxMiles, 0, 1000, defaultSettings.maxMiles, 1),
      theme: ["system", "light", "dark"].includes(raw.theme) ? raw.theme : defaultSettings.theme,
      appDataVersion: DATA_VERSION
    };

    // Backward-compatible aliases used by existing UI/calculation code.
    normalized.mpg = normalized.vehicleMpg;
    normalized.maintenancePerMile = normalized.maintenanceCostPerMile;
    normalized.taxMileageRate = normalized.mileageDeductionRate;
    normalized.minPerMile = normalized.minimumDollarPerMile;
    normalized.minPerHour = normalized.minimumDollarPerHour;
    normalized.minPayout = normalized.minimumPayout;
    return normalized;
  }

  function normalizeShift(value) {
    const raw = value && typeof value === "object" ? value : {};
    const startedAt = raw.startedAt && !Number.isNaN(new Date(raw.startedAt).getTime()) ? new Date(raw.startedAt).toISOString() : null;
    const endedAt = raw.endedAt && !Number.isNaN(new Date(raw.endedAt).getTime()) ? new Date(raw.endedAt).toISOString() : null;
    const shiftHistory = Array.isArray(raw.shiftHistory)
      ? raw.shiftHistory.map((item) => normalizeShiftHistoryItem(item)).filter(Boolean).slice(-100)
      : [];
    return {
      active: Boolean(raw.active && startedAt),
      startedAt,
      endedAt,
      lastSummary: cleanText(raw.lastSummary || "", 1000),
      shiftHistory,
      appDataVersion: DATA_VERSION
    };
  }

  function normalizeShiftHistoryItem(item) {
    if (!item || typeof item !== "object") return null;
    const startedAt = item.startedAt && !Number.isNaN(new Date(item.startedAt).getTime()) ? new Date(item.startedAt).toISOString() : null;
    const endedAt = item.endedAt && !Number.isNaN(new Date(item.endedAt).getTime()) ? new Date(item.endedAt).toISOString() : null;
    if (!startedAt || !endedAt) return null;
    return {
      id: String(item.id || makeId()),
      startedAt,
      endedAt,
      summary: cleanText(item.summary || "", 1000),
      createdAt: item.createdAt && !Number.isNaN(new Date(item.createdAt).getTime()) ? new Date(item.createdAt).toISOString() : endedAt,
      version: DATA_VERSION
    };
  }

  function normalizeTags(value) {
    if (!Array.isArray(value)) return [];
    const seen = new Set();
    return value
      .map((tag) => cleanText(tag, 40).toLowerCase())
      .filter((tag) => tag && !seen.has(tag) && seen.add(tag))
      .slice(0, 12);
  }

  function cleanText(value, maxLength) {
    return String(value ?? "").replace(/[\u0000-\u001f\u007f]/g, " ").trim().slice(0, maxLength);
  }

  function bounded(value, min, max, fallback, decimals = 2) {
    if (value === undefined || value === null) return fallback;
    const raw = String(value).trim();
    if (!raw || !/[0-9]/.test(raw)) return fallback;
    const parsed = num(raw);
    if (!Number.isFinite(parsed) || parsed < min || parsed > max) return fallback;
    return decimals === 1 ? round1(parsed) : round2(parsed);
  }

  function todayKey(date = new Date()) {
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, "0");
    const d = String(date.getDate()).padStart(2, "0");
    return `${y}-${m}-${d}`;
  }

  function isToday(value) {
    const date = new Date(value);
    return !Number.isNaN(date.getTime()) && todayKey(date) === todayKey();
  }

  function num(value) {
    let s = String(value ?? "").trim().replace(/[^0-9.,-]/g, "");
    if (!s || s === "-" || s === "." || s === ",") return 0;
    const isNegative = s.startsWith("-");
    s = s.replace(/-/g, "");
    const lastComma = s.lastIndexOf(",");
    const lastDot = s.lastIndexOf(".");
    if (lastComma > -1 && lastDot > -1) {
      if (lastComma > lastDot) s = s.replace(/\./g, "").replace(/,/g, ".");
      else s = s.replace(/,/g, "");
    } else if (lastComma > -1) {
      const parts = s.split(",");
      s = parts.length === 2 && parts[1].length !== 3 ? s.replace(",", ".") : s.replace(/,/g, "");
    }
    const parsed = Number.parseFloat(s);
    return Number.isFinite(parsed) ? (isNegative ? -parsed : parsed) : 0;
  }

  function todayDeliveries() {
    return deliveries
      .filter((d) => !d.deleted && isToday(d.createdAt))
      .sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
  }

  function getWorkWindow(todays) {
    let start = null;
    if (shift.startedAt && isToday(shift.startedAt)) start = new Date(shift.startedAt);
    else if (todays.length) start = new Date(todays[0].createdAt);
    if (!start) return null;

    let end = new Date();
    if (!shift.active && shift.endedAt && isToday(shift.endedAt)) {
      const ended = new Date(shift.endedAt);
      if (ended > start) end = ended;
    }
    if (todays.length) {
      const lastDelivery = new Date(todays[todays.length - 1].createdAt);
      if (lastDelivery > end) end = lastDelivery;
    }
    return { start, end };
  }

  const ProfitEngine = {
    number(value, fallback = 0) {
      const parsed = Number(value);
      return Number.isFinite(parsed) ? parsed : fallback;
    },
    positive(value, fallback = 0) {
      return Math.max(0, this.number(value, fallback));
    },
    fuelCostPerMile(config = settings) {
      const gasPrice = this.positive(config.gasPrice, defaultSettings.gasPrice);
      const mpg = this.positive(config.vehicleMpg ?? config.mpg, defaultSettings.vehicleMpg);
      return mpg > 0 ? round2(gasPrice / mpg) : 0;
    },
    maintenanceCost(miles = 0, config = settings) {
      const distance = this.positive(miles, 0);
      const maintenancePerMile = this.positive(config.maintenanceCostPerMile ?? config.maintenancePerMile, defaultSettings.maintenanceCostPerMile);
      return round2(distance * maintenancePerMile);
    },
    vehicleCostPerMile(config = settings) {
      const maintenancePerMile = this.positive(config.maintenanceCostPerMile ?? config.maintenancePerMile, defaultSettings.maintenanceCostPerMile);
      return round2(this.fuelCostPerMile(config) + maintenancePerMile);
    },
    vehicleCost(miles = 0, config = settings) {
      return round2(this.positive(miles, 0) * this.vehicleCostPerMile(config));
    },
    estimatedDeliveryProfit(delivery, config = settings) {
      const earnings = this.positive(delivery?.earnings, 0);
      const miles = this.positive(delivery?.miles, 0);
      return round2(earnings - this.vehicleCost(miles, config));
    },
    estimatedProfitPerMile(profitOrDelivery, miles, config = settings) {
      if (profitOrDelivery && typeof profitOrDelivery === "object") {
        const profit = this.estimatedDeliveryProfit(profitOrDelivery, config);
        return this.grossDollarPerMile(profit, profitOrDelivery.miles);
      }
      return this.grossDollarPerMile(this.number(profitOrDelivery, 0), miles);
    },
    grossDollarPerMile(earnings, miles) {
      const distance = this.positive(miles, 0);
      return distance > 0 ? round2(this.number(earnings, 0) / distance) : 0;
    },
    grossHourlyRate(earnings, minutes) {
      const mins = this.positive(minutes, 0);
      return mins > 0 ? round2(this.number(earnings, 0) / (mins / 60)) : 0;
    },
    profitHourlyRate(profit, minutes) {
      return this.grossHourlyRate(profit, minutes);
    },
    mileageDeduction(miles, config = settings) {
      const rate = this.positive(config.mileageDeductionRate ?? config.taxMileageRate, defaultSettings.mileageDeductionRate);
      return round2(this.positive(miles, 0) * rate);
    },
    projectedDailyEarnings(earnings, grossHourly, hours, active = shift.active) {
      const current = this.positive(earnings, 0);
      const hourly = this.positive(grossHourly, 0);
      const worked = this.positive(hours, 0);
      if (!current || !hourly) return current;
      const projectedHours = active ? Math.max(worked, 8) : worked;
      return round2(Math.max(current, hourly * projectedHours));
    },
    goalETA(summary, goal, remaining, now = new Date()) {
      const target = this.positive(goal, 0);
      const left = this.positive(remaining, 0);
      if (!target) return { label: "No goal set", date: null, hoursNeeded: 0 };
      if (!summary?.orders) return { label: "Add delivery", date: null, hoursNeeded: 0 };
      if (left <= 0) return { label: "Goal hit", date: null, hoursNeeded: 0 };
      if (!summary.avgHour) return { label: "Need pace", date: null, hoursNeeded: 0 };
      const hoursNeeded = left / summary.avgHour;
      if (!Number.isFinite(hoursNeeded) || hoursNeeded > 24) return { label: "Over 24h", date: null, hoursNeeded };
      const date = new Date(now.getTime() + hoursNeeded * 36e5);
      return {
        label: date.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" }),
        date,
        hoursNeeded
      };
    },
    driverScore(summary, config = settings) {
      const c = summary || {};
      if (!c.orders) return { value: 0, title: "No score yet", detail: "Start a shift and save deliveries to get live feedback." };
      const minPerMile = this.positive(config.minimumDollarPerMile ?? config.minPerMile, defaultSettings.minimumDollarPerMile);
      const minPerHour = this.positive(config.minimumDollarPerHour ?? config.minPerHour, defaultSettings.minimumDollarPerHour);
      let score = 50;
      if (minPerMile) score += clamp(((c.avgMile / minPerMile) - 1) * 25, -20, 25);
      if (minPerHour) score += clamp(((c.avgHour / minPerHour) - 1) * 25, -20, 25);
      if (c.profit > 0) score += 10;
      if (c.profitMile >= 1) score += 8;
      if (c.orders >= 3) score += 5;
      score = Math.round(clamp(score, 0, 100));

      let title = "Solid shift";
      let detail = `${money.format(c.avgMile)}/mile gross and ${money.format(c.profitHour)}/hour estimated profit.`;
      if (score >= 85) {
        title = "Excellent pace";
        detail = `Strong efficiency: ${money.format(c.avgMile)}/mile gross, ${money.format(c.profitMile)}/mile profit.`;
      } else if (score >= 70) {
        title = "Good money day";
        detail = "You are above most minimums. Keep avoiding low-mileage-profit orders.";
      } else if (score >= 45) {
        title = "Watch the order quality";
        detail = "You are close, but some orders may be pulling down hourly pace or $/mile.";
      } else {
        title = "Needs improvement";
        detail = "Current pace is below your targets. Use the Accept calculator before taking similar orders.";
      }
      return { value: score, title, detail };
    },
    summarizeRows(rows = [], { config = settings, workWindow = null, activeShift = shift.active } = {}) {
      const safeRows = Array.isArray(rows) ? rows : [];
      const earnings = round2(safeRows.reduce((sum, d) => sum + this.positive(d.earnings, 0), 0));
      const miles = round2(safeRows.reduce((sum, d) => sum + this.positive(d.miles, 0), 0));
      const minutes = round1(safeRows.reduce((sum, d) => sum + this.positive(d.minutes, 0), 0));
      const orders = safeRows.length;
      const expenses = this.vehicleCost(miles, config);
      const profit = round2(earnings - expenses);
      const taxDeduction = this.mileageDeduction(miles, config);
      const avgOrder = orders ? round2(earnings / orders) : 0;
      const avgMile = this.grossDollarPerMile(earnings, miles);
      const profitMile = this.estimatedProfitPerMile(profit, miles, config);
      const hours = workWindow
        ? Math.max((workWindow.end - workWindow.start) / 36e5, 1 / 60)
        : (minutes ? minutes / 60 : 0);
      const avgHour = hours ? round2(earnings / hours) : 0;
      const profitHour = hours ? round2(profit / hours) : 0;
      const projectedTotal = this.projectedDailyEarnings(earnings, avgHour, hours, activeShift);
      return { earnings, miles, orders, avgOrder, avgMile, profitMile, avgHour, profitHour, hours, profit, expenses, taxDeduction, minutes, projectedTotal };
    }
  };

  function fuelCostPerMile(config = settings) {
    return ProfitEngine.fuelCostPerMile(config);
  }

  function maintenanceCost(miles = 0, config = settings) {
    return ProfitEngine.maintenanceCost(miles, config);
  }

  function vehicleCostPerMile(config = settings) {
    return ProfitEngine.vehicleCostPerMile(config);
  }

  function costPerMile() {
    return vehicleCostPerMile(settings);
  }

  function deliveryProfit(delivery) {
    return estimatedDeliveryProfit(delivery, settings);
  }

  function estimatedDeliveryProfit(delivery, config = settings) {
    return ProfitEngine.estimatedDeliveryProfit(delivery, config);
  }

  function estimatedProfitPerMile(profitOrDelivery, miles, config = settings) {
    return ProfitEngine.estimatedProfitPerMile(profitOrDelivery, miles, config);
  }

  function grossDollarPerMile(earnings, miles) {
    return ProfitEngine.grossDollarPerMile(earnings, miles);
  }

  function safeRate(value, divisor) {
    return grossDollarPerMile(value, divisor);
  }

  function grossPerMile(delivery) {
    return grossDollarPerMile(delivery?.earnings, delivery?.miles);
  }

  function grossHourlyRate(earnings, minutes) {
    return ProfitEngine.grossHourlyRate(earnings, minutes);
  }

  function hourlyRate(value, minutes) {
    return grossHourlyRate(value, minutes);
  }

  function profitHourlyRate(profit, minutes) {
    return ProfitEngine.profitHourlyRate(profit, minutes);
  }

  function mileageDeduction(miles, config = settings) {
    return ProfitEngine.mileageDeduction(miles, config);
  }

  function projectedDailyEarnings(earnings, grossHourly, hours) {
    return ProfitEngine.projectedDailyEarnings(earnings, grossHourly, hours, shift.active);
  }

  function projectedDailyTotal(earnings, avgHour, hours) {
    return projectedDailyEarnings(earnings, avgHour, hours);
  }

  function goalETA(c, goal, remaining) {
    return ProfitEngine.goalETA(c, goal, remaining);
  }

  function calculate(rows) {
    return ProfitEngine.summarizeRows(rows, {
      config: settings,
      workWindow: getWorkWindow(rows),
      activeShift: shift.active
    });
  }

  function render() {
    const todays = todayDeliveries();
    const c = calculate(todays);
    const goal = Number(settings.dailyGoal || 0);
    const pct = goal ? Math.min((c.earnings / goal) * 100, 999) : 0;
    const remaining = Math.max(goal - c.earnings, 0);
    const score = driverScore(c);

    els.todayEarned.textContent = money.format(c.earnings);
    els.profitLine.textContent = `Estimated profit ${money.format(c.profit)}`;
    els.goalPercent.textContent = `${Math.round(Math.min(pct, 100))}%`;
    els.goalBar.style.width = `${Math.min(pct, 100)}%`;
    els.goalText.textContent = money.format(goal);
    els.shiftStatus.textContent = shiftStatusText(c.hours);
    els.goalRemaining.textContent = buildGoalInsight(c, goal, remaining);

    const bestCompany = bestGroup(todays, "company");
    const bestZone = bestGroup(todays, "zone");

    renderCommandMetrics(todays, c, goal, remaining, score, bestCompany, bestZone);

    els.driverScore.textContent = String(score.value);
    els.driverScoreTitle.textContent = score.title;
    els.driverScoreDetail.textContent = score.detail;
    renderHeroStatus(score.value, pct);
    renderTrend(todays);
    renderDailySummary(todays, c);
    renderBreakdown(els.companyBreakdown, todays, "company");
    renderBreakdown(els.zoneBreakdown, todays, "zone");
    renderHistory();
    renderSettings();
    renderShiftButton();
    renderDeliveryPreview();
    renderDecision();
  }

  function renderLive() {
    const todays = todayDeliveries();
    const c = calculate(todays);
    const goal = Number(settings.dailyGoal || 0);
    const remaining = Math.max(goal - c.earnings, 0);
    const score = driverScore(c);
    const bestCompany = bestGroup(todays, "company");
    const bestZone = bestGroup(todays, "zone");
    renderCommandMetrics(todays, c, goal, remaining, score, bestCompany, bestZone);
    els.shiftStatus.textContent = shiftStatusText(c.hours);
    els.goalRemaining.textContent = buildGoalInsight(c, goal, remaining);
  }

  function renderCommandMetrics(todays, c, goal, remaining, score, bestCompany, bestZone) {
    const goalEta = buildGoalEta(c, goal, remaining);
    const paceStatus = paceStatusLabel(c);
    const efficiencyStatus = efficiencyStatusLabel(c);
    const taxRate = Number(settings.taxMileageRate || 0);

    els.profitToday.textContent = money.format(c.profit);
    els.profitHour.textContent = money.format(c.profitHour);
    els.avgHour.textContent = money.format(c.avgHour);
    els.projectedTotal.textContent = money.format(c.projectedTotal);
    els.goalEta.textContent = goalEta;
    els.paceStatus.textContent = paceStatus.label;
    els.paceRecommendation.textContent = paceRecommendation(c, goal, remaining);
    setStatusClass(els.paceCard, paceStatus.kind);

    els.avgMile.textContent = money.format(c.avgMile);
    els.profitMile.textContent = money.format(c.profitMile);
    els.milesToday.textContent = c.miles.toFixed(1);
    els.avgDeliveryValue.textContent = money.format(c.avgOrder);
    els.efficiencyStatus.textContent = efficiencyStatus.label;
    els.efficiencyRecommendation.textContent = efficiencyRecommendation(c);
    setStatusClass(els.efficiencyCard, efficiencyStatus.kind);

    els.taxDeduction.textContent = money.format(c.taxDeduction);
    els.taxRateLabel.textContent = `${money.format(taxRate)}/mi`;
    els.taxMiles.textContent = `${c.miles.toFixed(1)} mi`;
    els.vehicleCostToday.textContent = money.format(c.expenses);
    els.ordersCount.textContent = String(c.orders);
    els.taxRecommendation.textContent = c.miles
      ? `${money.format(c.taxDeduction)} estimated deduction on ${c.miles.toFixed(1)} tracked business miles.`
      : "Save miles with each delivery to build a cleaner tax log.";
    setStatusClass(els.taxCard, c.miles ? "good" : "neutral");

    els.bestCompanyToday.textContent = bestCompany ? bestCompany.name : "—";
    els.bestZoneToday.textContent = bestZone ? bestZone.name : "—";
    els.timeWorking.textContent = formatHours(c.hours);
    els.performanceRecommendation.textContent = performanceRecommendation(c, bestCompany, bestZone);
    els.heroStatusLabel.textContent = heroStatusLabel(c, score.value, goal);
    setStatusClass(els.performanceCard, scoreKind(score.value, c.orders));
  }

  function buildGoalEta(c, goal, remaining) {
    return goalETA(c, goal, remaining).label;
  }

  function paceStatusLabel(c) {
    if (!c.orders) return { kind: "neutral", label: "Waiting for data" };
    if (c.avgHour >= settings.minPerHour * 1.15) return { kind: "good", label: "Ahead of pace" };
    if (c.avgHour >= settings.minPerHour * 0.9) return { kind: "warning", label: "Close to target" };
    return { kind: "danger", label: "Behind pace" };
  }

  function efficiencyStatusLabel(c) {
    if (!c.orders || !c.miles) return { kind: "neutral", label: "No miles yet" };
    if (c.avgMile >= settings.minPerMile * 1.15) return { kind: "good", label: "Efficient" };
    if (c.avgMile >= settings.minPerMile * 0.9) return { kind: "warning", label: "Borderline" };
    return { kind: "danger", label: "Low $/mile" };
  }

  function paceRecommendation(c, goal, remaining) {
    if (!c.orders) return "Start a shift and save a delivery to calculate live pace.";
    if (remaining <= 0) return `Goal reached with ${money.format(c.earnings - goal)} over target.`;
    if (c.avgHour >= settings.minPerHour) return `${money.format(remaining)} left. Current pace beats your ${money.format(settings.minPerHour)}/hr target.`;
    return `Current gross pace is below your ${money.format(settings.minPerHour)}/hr target. Use Decide before accepting similar orders.`;
  }

  function efficiencyRecommendation(c) {
    if (!c.orders) return "Use miles on every delivery to keep profit accurate.";
    if (!c.miles) return "Zero tracked miles makes $/mile impossible. Add mileage for tax and profit accuracy.";
    if (c.avgMile >= settings.minPerMile) return `Good order quality: ${money.format(c.avgMile)}/mile beats your ${money.format(settings.minPerMile)}/mile floor.`;
    return `Order quality is low. Try to avoid offers below ${money.format(settings.minPerMile)}/mile.`;
  }

  function performanceRecommendation(c, bestCompany, bestZone) {
    if (!c.orders) return "Add your first delivery to unlock platform and zone coaching.";
    const company = bestCompany ? bestCompany.name : "your best platform";
    const zone = bestZone ? bestZone.name : "your best zone";
    if (c.avgMile < settings.minPerMile) return `Prioritize shorter, higher-pay offers. ${company} is currently strongest, but $/mile needs attention.`;
    if (c.avgHour < settings.minPerHour) return `Efficiency is okay; hourly pace needs help. Watch wait time and favor ${zone}.`;
    return `Keep prioritizing ${company}${zone !== "Unassigned" ? ` in ${zone}` : ""}; it is producing your strongest mix today.`;
  }

  function heroStatusLabel(c, score, goal) {
    if (!c.orders) return "No data yet";
    if (goal && c.earnings >= goal) return "Goal reached";
    if (score >= 75) return "Strong day";
    if (score >= 50) return "Watch pace";
    return "Needs attention";
  }

  function scoreKind(score, orders) {
    if (!orders) return "neutral";
    if (score >= 75) return "good";
    if (score >= 50) return "warning";
    return "danger";
  }

  function setStatusClass(el, kind) {
    if (!el) return;
    el.classList.remove("status-good", "status-warning", "status-danger", "status-neutral");
    el.classList.add(`status-${kind || "neutral"}`);
  }

  function renderHeroStatus(score, pct) {
    if (!todayDeliveries().length) setStatusClass(els.todayHero, "neutral");
    else if (pct >= 100 || score >= 75) setStatusClass(els.todayHero, "good");
    else if (score >= 50) setStatusClass(els.todayHero, "warning");
    else setStatusClass(els.todayHero, "danger");
  }

  function buildGoalInsight(c, goal, remaining) {
    if (!goal) return "Set a daily goal in Settings.";
    if (!c.orders) return "Add your first delivery to start tracking pay, miles, profit, and pace.";
    if (remaining <= 0) return `Goal hit. You're ${money.format(c.earnings - goal)} over target.`;
    if (c.avgHour > 0) {
      const eta = goalETA(c, goal, remaining);
      return `${money.format(remaining)} left. At this pace, you hit goal around ${eta.label}.`;
    }
    return `${money.format(remaining)} left to hit today's goal.`;
  }

  function shiftStatusText(hours) {
    if (shift.active && shift.startedAt && isToday(shift.startedAt)) return `Shift active · ${formatHours(hours)}`;
    if (shift.endedAt && isToday(shift.endedAt)) return `Shift ended · ${formatHours(hours)}`;
    return "No active shift";
  }

  function driverScore(c) {
    return ProfitEngine.driverScore(c, settings);
  }

  function formatHours(hours) {
    if (!hours) return "0h 00m";
    const totalMinutes = Math.max(0, Math.round(hours * 60));
    const h = Math.floor(totalMinutes / 60);
    const m = totalMinutes % 60;
    return `${h}h ${String(m).padStart(2, "0")}m`;
  }

  function renderTrend(todays) {
    els.trendCard.classList.remove("trend-up", "trend-down");
    if (todays.length === 0) {
      els.trendTitle.textContent = "No deliveries yet";
      els.trendDetail.textContent = "After each delivery, DriveLedger shows whether that delivery helped or hurt your average.";
      return;
    }
    const last = todays[todays.length - 1];
    const lastEarnings = Number(last.earnings || 0);
    const lastMiles = Number(last.miles || 0);
    const perMile = grossDollarPerMile(lastEarnings, lastMiles);
    const profit = estimatedDeliveryProfit(last);
    const before = todays.slice(0, -1);
    if (!before.length) {
      els.trendTitle.textContent = `${money.format(lastEarnings)} first delivery`;
      els.trendDetail.textContent = `${last.company} · ${lastMiles.toFixed(1)} mi · ${money.format(perMile)}/mi gross · ${money.format(profit)} profit.`;
      return;
    }
    const beforeAvg = before.reduce((s, d) => s + Number(d.earnings || 0), 0) / before.length;
    const afterAvg = todays.reduce((s, d) => s + Number(d.earnings || 0), 0) / todays.length;
    const diff = afterAvg - beforeAvg;
    const helped = diff >= 0 && perMile >= settings.minPerMile;
    els.trendCard.classList.add(helped ? "trend-up" : "trend-down");
    els.trendTitle.textContent = helped ? "Last delivery helped your day" : "Last delivery hurt your average";
    els.trendDetail.textContent = `${last.company}: ${money.format(lastEarnings)}, ${lastMiles.toFixed(1)} mi, ${money.format(perMile)}/mi, ${money.format(profit)} estimated profit. Average delivery changed by ${money.format(diff)}.`;
  }

  function renderDailySummary(todays, c) {
    if (!todays.length) {
      els.dailySummary.textContent = "No shift data yet.";
      return;
    }
    const best = bestDelivery(todays);
    const weak = weakestDelivery(todays);
    const bestCompany = bestGroup(todays, "company");
    const recommendation = c.avgMile < settings.minPerMile
      ? `Recommendation: avoid orders below ${money.format(settings.minPerMile)}/mile.`
      : `Recommendation: keep prioritizing ${bestCompany?.name || "your strongest platform"}.`;
    els.dailySummary.innerHTML = `
      <p>You earned <strong>${money.format(c.earnings)}</strong> today with <strong>${money.format(c.profit)}</strong> estimated profit.</p>
      <p>${c.orders} ${c.orders === 1 ? "delivery" : "deliveries"} · ${c.miles.toFixed(1)} miles · ${money.format(c.avgHour)}/hr gross · ${money.format(c.profitHour)}/hr profit.</p>
      <p>Best delivery: ${best ? `${money.format(best.earnings)} for ${Number(best.miles).toFixed(1)} mi` : "—"}. Weakest delivery: ${weak ? `${money.format(weak.earnings)} for ${Number(weak.miles).toFixed(1)} mi` : "—"}.</p>
      <p>${escapeHTML(recommendation)}</p>
    `;
  }

  function bestDelivery(rows) {
    return [...rows].sort((a, b) => grossPerMile(b) - grossPerMile(a))[0] || null;
  }

  function weakestDelivery(rows) {
    return [...rows].sort((a, b) => grossPerMile(a) - grossPerMile(b))[0] || null;
  }

  function bestGroup(rows, key) {
    const grouped = groupRows(rows, key);
    return [...grouped.entries()]
      .map(([name, row]) => ({ name, ...row, avgHour: row.minutes ? row.earnings / (row.minutes / 60) : 0, grossPerMile: grossPerMile(row) }))
      .sort((a, b) => b.grossPerMile - a.grossPerMile || b.profit - a.profit)[0] || null;
  }

  function groupRows(rows, key) {
    const grouped = new Map();
    for (const d of rows) {
      const name = key === "zone" ? (d.zone || "Unassigned") : d.company;
      const row = grouped.get(name) || { earnings: 0, miles: 0, count: 0, profit: 0, minutes: 0 };
      row.earnings += Number(d.earnings || 0);
      row.miles += Number(d.miles || 0);
      row.count += 1;
      row.profit += deliveryProfit(d);
      row.minutes += Number(d.minutes || 0);
      grouped.set(name, row);
    }
    return grouped;
  }

  function renderBreakdown(target, rows, key) {
    if (!rows.length) {
      target.className = "breakdown empty";
      target.textContent = key === "zone" ? "No zone data yet." : "No company data yet.";
      return;
    }
    target.className = "breakdown";
    const grouped = groupRows(rows, key);
    target.innerHTML = [...grouped.entries()]
      .sort((a, b) => b[1].profit - a[1].profit)
      .map(([name, row]) => `
        <div class="breakdown-item">
          <div class="breakdown-top"><span>${escapeHTML(name)}</span><strong>${money.format(row.earnings)}</strong></div>
          <div class="breakdown-meta">${row.count} ${row.count === 1 ? "delivery" : "deliveries"} · ${row.miles.toFixed(1)} mi · ${money.format(row.miles ? row.earnings / row.miles : 0)}/mi · ${money.format(row.profit)} profit</div>
        </div>
      `).join("");
  }

  function renderHistory() {
    if (!deliveries.length) {
      els.historyList.className = "history-list empty";
      els.historyList.innerHTML = `No deliveries yet.<br><button class="primary-btn compact empty-action" data-open-add="manual" type="button">Add your first delivery</button>`;
      return;
    }
    els.historyList.className = "history-list";
    const grouped = new Map();
    for (const d of deliveries.filter((item) => !item.deleted).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))) {
      const key = todayKey(new Date(d.createdAt));
      if (!grouped.has(key)) grouped.set(key, []);
      grouped.get(key).push(d);
    }
    els.historyList.innerHTML = [...grouped.entries()].map(([dateKey, rows]) => {
      const c = calculateForDay(rows);
      const title = dateLabel(dateKey);
      return `
        <section class="history-day">
          <div class="day-summary">
            <div><strong>${escapeHTML(title)}</strong><span>${rows.length} ${rows.length === 1 ? "delivery" : "deliveries"} · ${c.miles.toFixed(1)} mi</span></div>
            <div><strong>${money.format(c.earnings)}</strong><span>${money.format(c.profit)} profit</span></div>
          </div>
          ${rows.map((d) => renderHistoryItem(d)).join("")}
        </section>
      `;
    }).join("");
  }

  function calculateForDay(rows) {
    return ProfitEngine.summarizeRows(rows, { config: settings, activeShift: false });
  }

  function renderHistoryItem(d) {
    const earnings = Number(d.earnings || 0);
    const miles = Number(d.miles || 0);
    const perMile = grossDollarPerMile(earnings, miles);
    const profit = estimatedDeliveryProfit(d);
    const date = new Date(d.createdAt).toLocaleString([], { hour: "numeric", minute: "2-digit" });
    return `
      <article class="history-item">
        <div class="history-top"><span>${escapeHTML(d.company)}</span><strong>${money.format(earnings)}</strong></div>
        <div class="history-meta">${miles.toFixed(1)} mi · ${money.format(perMile)}/mi · ${money.format(profit)} profit · ${date}${d.minutes ? ` · ${d.minutes} min` : ""} · <span class="source-pill">${escapeHTML(sourceLabel(d.source))}</span></div>
        ${d.zone ? `<div class="history-meta">Zone: ${escapeHTML(d.zone)}</div>` : ""}
        ${d.notes ? `<div class="history-meta">${escapeHTML(d.notes)}</div>` : ""}
        <div class="history-actions">
          <button class="mini-btn" data-edit="${escapeHTML(d.id)}" type="button">Edit</button>
          <button class="mini-btn" data-duplicate="${escapeHTML(d.id)}" type="button">Duplicate</button>
          <button class="delete-mini" data-delete="${escapeHTML(d.id)}" type="button">Delete</button>
        </div>
      </article>
    `;
  }

  function sourceLabel(source) {
    if (source === "ocr") return "OCR";
    if (source === "calculator") return "Calculator";
    if (source === "import") return "Import";
    return "Manual";
  }

  function dateLabel(dateKey) {
    if (dateKey === todayKey()) return "Today";
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    if (dateKey === todayKey(yesterday)) return "Yesterday";
    const [year, month, day] = dateKey.split("-").map(Number);
    return new Date(year, month - 1, day).toLocaleDateString([], { month: "short", day: "numeric", year: "numeric" });
  }

  function renderSettings() {
    const pairs = [
      [els.goalInput, settings.dailyGoal],
      [els.defaultCompanyInput, settings.defaultCompany],
      [els.gasPriceInput, settings.gasPrice],
      [els.mpgInput, settings.mpg],
      [els.maintenanceInput, settings.maintenancePerMile],
      [els.taxRateInput, settings.taxMileageRate],
      [els.minPerMileInput, settings.minPerMile],
      [els.minPerHourInput, settings.minPerHour],
      [els.minPayoutInput, settings.minPayout],
      [els.maxMilesInput, settings.maxMiles],
      [els.defaultZoneInput, settings.defaultZone]
    ];
    for (const [input, value] of pairs) {
      if (document.activeElement !== input) input.value = value ?? "";
    }
  }

  function renderShiftButton() {
    const label = shift.active && shift.startedAt && isToday(shift.startedAt) ? "End Day" : "Start Day";
    els.shiftBtn.textContent = label;
    if (els.heroShiftBtn) els.heroShiftBtn.textContent = label;
  }

  function renderDeliveryPreview() {
    if (!els.deliveryPreview) return;
    const earnings = num(els.earningsInput.value);
    const miles = num(els.milesInput.value);
    const minutes = num(els.minutesInput.value);
    if (!earnings || !miles) {
      els.deliveryPreview.textContent = "Enter earnings and miles to preview profit.";
      els.deliveryPreview.className = "delivery-preview";
      return;
    }
    const profit = estimatedDeliveryProfit({ earnings, miles });
    const perMile = grossDollarPerMile(earnings, miles);
    const profitMile = estimatedProfitPerMile(profit, miles);
    const hourly = grossHourlyRate(earnings, minutes);
    const good = perMile >= settings.minPerMile && (!minutes || hourly >= settings.minPerHour);
    els.deliveryPreview.className = `delivery-preview ${good ? "good" : "bad"}`;
    els.deliveryPreview.textContent = `${money.format(profit)} estimated profit · ${money.format(perMile)}/mi gross · ${money.format(profitMile)}/mi profit${minutes ? ` · ${money.format(hourly)}/hr` : ""}`;
  }

  function renderDecision({ announce = false } = {}) {
    const pay = num(els.offerPayInput.value);
    const miles = num(els.offerMilesInput.value);
    const minutes = num(els.offerMinutesInput.value);
    const decision = evaluateOffer(pay, miles, minutes);
    els.decisionResult.className = `decision-card ${decision.kind}`;
    els.decisionResult.innerHTML = `
      <p class="label">Decision</p>
      <h2>${escapeHTML(decision.title)}</h2>
      <p>${escapeHTML(decision.detail)}</p>
      ${decision.metrics?.length ? `<div class="decision-metrics">${decision.metrics.map((m) => `<span>${escapeHTML(m)}</span>`).join("")}</div>` : ""}
      ${decision.thresholds?.length ? `<div class="threshold-list">${decision.thresholds.map((item) => `
        <div class="threshold-row ${item.passed ? "passed" : "failed"}">
          <span>${escapeHTML(item.label)}</span>
          <strong>${item.passed ? "Pass" : "Fail"}</strong>
          <small>${escapeHTML(item.actual)} vs ${escapeHTML(item.target)}</small>
        </div>
      `).join("")}</div>` : ""}
    `;
    if (announce) toast(`${decision.title}: ${decision.detail}`);
    return decision;
  }

  function evaluateOffer(pay, miles, minutes) {
    const validation = [];
    if (!(pay > 0)) validation.push("pay must be greater than $0");
    if (!(miles > 0)) validation.push("miles must be greater than 0");
    if (!(minutes > 0)) validation.push("estimated minutes must be greater than 0");
    if (validation.length) {
      return {
        kind: "neutral",
        title: "Enter a valid offer",
        detail: `Fix input: ${validation.join(", ")}.`,
        metrics: ["No decision yet"],
        thresholds: []
      };
    }

    const grossPerMile = grossDollarPerMile(pay, miles);
    const grossHourly = grossHourlyRate(pay, minutes);
    const profit = estimatedDeliveryProfit({ earnings: pay, miles });
    const profitPerMile = estimatedProfitPerMile(profit, miles);
    const profitHourly = profitHourlyRate(profit, minutes);
    const thresholdRows = buildOfferThresholds({ pay, miles, grossPerMile, grossHourly, profit });
    const failed = thresholdRows.filter((row) => !row.passed);
    const severeFailures = thresholdRows.filter((row) => !row.passed && row.severe);
    const metrics = [
      `${money.format(grossPerMile)}/mile gross`,
      `${money.format(grossHourly)}/hr gross`,
      `${money.format(profit)} profit`,
      `${money.format(profitPerMile)}/mile profit`,
      `${money.format(profitHourly)}/hr profit`
    ];

    if (!failed.length) {
      return {
        kind: "accept",
        title: "ACCEPT",
        detail: `Above your minimums. Estimated profit is ${money.format(profit)} after vehicle costs.`,
        metrics,
        thresholds: thresholdRows
      };
    }

    if (!severeFailures.length && failed.length <= 2) {
      return {
        kind: "borderline",
        title: "BORDERLINE",
        detail: `Close call: ${failed.map((row) => row.reason).join("; ")}. Consider wait time, restaurant speed, and drop-off difficulty.`,
        metrics,
        thresholds: thresholdRows
      };
    }

    return {
      kind: "decline",
      title: "DECLINE",
      detail: `Too weak: ${failed.map((row) => row.reason).join("; ")}. Estimated profit is ${money.format(profit)} after vehicle costs.`,
      metrics,
      thresholds: thresholdRows
    };
  }

  function buildOfferThresholds({ pay, miles, grossPerMile, grossHourly, profit }) {
    const rows = [];
    if (settings.minPayout > 0) {
      rows.push(makeThreshold({
        label: "Minimum payout",
        actualValue: pay,
        targetValue: settings.minPayout,
        passed: pay >= settings.minPayout,
        actual: money.format(pay),
        target: `${money.format(settings.minPayout)}+`,
        reason: `${money.format(pay)} payout is below your ${money.format(settings.minPayout)} minimum`,
        severe: pay < settings.minPayout * 0.8
      }));
    }
    if (settings.minPerMile > 0) {
      rows.push(makeThreshold({
        label: "Gross $/mile",
        actualValue: grossPerMile,
        targetValue: settings.minPerMile,
        passed: grossPerMile >= settings.minPerMile,
        actual: `${money.format(grossPerMile)}/mile`,
        target: `${money.format(settings.minPerMile)}/mile+`,
        reason: `${money.format(grossPerMile)}/mile is below your ${money.format(settings.minPerMile)}/mile minimum`,
        severe: grossPerMile < settings.minPerMile * 0.8
      }));
    }
    if (settings.minPerHour > 0) {
      rows.push(makeThreshold({
        label: "Gross hourly pace",
        actualValue: grossHourly,
        targetValue: settings.minPerHour,
        passed: grossHourly >= settings.minPerHour,
        actual: `${money.format(grossHourly)}/hr`,
        target: `${money.format(settings.minPerHour)}/hr+`,
        reason: `${money.format(grossHourly)}/hr is below your ${money.format(settings.minPerHour)}/hr minimum`,
        severe: grossHourly < settings.minPerHour * 0.8
      }));
    }
    if (settings.maxMiles > 0) {
      rows.push(makeThreshold({
        label: "Maximum distance",
        actualValue: miles,
        targetValue: settings.maxMiles,
        passed: miles <= settings.maxMiles,
        actual: `${round1(miles)} miles`,
        target: `${round1(settings.maxMiles)} miles or less`,
        reason: `${round1(miles)} miles is over your ${round1(settings.maxMiles)} mile maximum`,
        severe: miles > settings.maxMiles * 1.2
      }));
    }
    rows.push(makeThreshold({
      label: "Estimated profit",
      actualValue: profit,
      targetValue: 0,
      passed: profit > 0,
      actual: money.format(profit),
      target: "positive after vehicle costs",
      reason: "estimated profit is not positive after gas and maintenance",
      severe: profit <= 0
    }));
    return rows;
  }

  function makeThreshold(row) {
    return {
      label: row.label,
      actual: row.actual,
      target: row.target,
      passed: Boolean(row.passed),
      reason: row.reason,
      severe: Boolean(row.severe)
    };
  }

  function buildDecisionSummaryText(decision = renderDecision()) {
    const company = allowedCompanies.has(els.offerCompanyInput.value) ? els.offerCompanyInput.value : settings.defaultCompany;
    const zone = cleanText(els.offerZoneInput.value || settings.defaultZone || "", 80) || "Unspecified zone";
    const note = cleanText(els.offerNoteInput.value || "", 200);
    const lines = [
      `DriveLedger order decision: ${decision.title}`,
      `Company: ${company}`,
      `Zone: ${zone}`,
      `Pay: ${money.format(num(els.offerPayInput.value))}`,
      `Miles: ${round1(num(els.offerMilesInput.value))}`,
      `Minutes: ${round1(num(els.offerMinutesInput.value))}`,
      `Reason: ${decision.detail}`
    ];
    if (decision.metrics?.length) lines.push(`Metrics: ${decision.metrics.join(" | ")}`);
    if (decision.thresholds?.length) lines.push(`Rules: ${decision.thresholds.map((row) => `${row.label} ${row.passed ? "PASS" : "FAIL"} (${row.actual} vs ${row.target})`).join(" | ")}`);
    if (note) lines.push(`Note: ${note}`);
    return lines.join("\n");
  }

  async function copyDecisionSummary() {
    const decision = renderDecision();
    if (decision.kind === "neutral") return toast("Enter a valid offer before copying a decision.");
    if (!navigator.clipboard || typeof navigator.clipboard.writeText !== "function") return toast("Copy is not available in this browser.");
    try {
      await navigator.clipboard.writeText(buildDecisionSummaryText(decision));
      toast("Decision copied.");
    } catch {
      toast("Copy is not available in this browser.");
    }
  }

  function clearOfferCalculator({ keepCompany = true } = {}) {
    els.offerPayInput.value = "";
    els.offerMilesInput.value = "";
    els.offerMinutesInput.value = "";
    els.offerZoneInput.value = settings.defaultZone || "";
    els.offerNoteInput.value = "";
    if (!keepCompany) els.offerCompanyInput.value = settings.defaultCompany;
    renderDecision();
  }

  function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>'"]/g, (ch) => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#039;", '"': "&quot;"
    }[ch]));
  }

  function makeId() {
    if (globalThis.crypto && typeof globalThis.crypto.randomUUID === "function") return globalThis.crypto.randomUUID();
    if (globalThis.crypto && typeof globalThis.crypto.getRandomValues === "function") {
      const bytes = new Uint8Array(16);
      globalThis.crypto.getRandomValues(bytes);
      return [...bytes].map((b) => b.toString(16).padStart(2, "0")).join("");
    }
    return `${Date.now()}-${Math.random().toString(36).slice(2)}`;
  }

  function round2(v) { return Math.round(Number(v || 0) * 100) / 100; }
  function round1(v) { return Math.round(Number(v || 0) * 10) / 10; }
  function clamp(value, min, max) { return Math.min(max, Math.max(min, value)); }

  function showTab(tab) {
    const screen = $(`tab-${tab}`);
    const button = document.querySelector(`.tab-btn[data-tab="${tab}"]`);
    if (!screen || !button) {
      console.warn(`Unknown tab requested: ${tab}`);
      return;
    }
    document.querySelectorAll(".tab-screen").forEach((el) => el.classList.remove("active"));
    document.querySelectorAll(".tab-btn").forEach((el) => el.classList.remove("active"));
    screen.classList.add("active");
    button.classList.add("active");
  }

  function openAdd(mode = "manual") {
    showTab("add");
    if (!els.editDeliveryId.value) {
      els.companyInput.value = settings.defaultCompany || "DoorDash";
      els.zoneInput.value = settings.defaultZone || "";
    }
    if (mode === "scan") {
      setTimeout(() => {
        if (els.screenshotInput && typeof els.screenshotInput.click === "function") els.screenshotInput.click();
      }, 80);
    } else if (els.earningsInput && typeof els.earningsInput.focus === "function") {
      els.earningsInput.focus();
    }
  }

  function latestDelivery() {
    return deliveries
      .filter((d) => !d.deleted)
      .slice()
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))[0] || null;
  }

  function quickDefaultCompany() {
    const last = latestDelivery();
    return allowedCompanies.has(last?.company) ? last.company : (settings.defaultCompany || "DoorDash");
  }

  function quickDefaultZone() {
    const last = latestDelivery();
    return cleanText(last?.zone || settings.defaultZone || "", 80);
  }

  function setQuickAddDefaults(clearValues = true) {
    if (!els.quickAddForm) return;
    els.quickCompanyInput.value = quickDefaultCompany();
    els.quickZoneInput.value = quickDefaultZone();
    if (clearValues) {
      [els.quickEarningsInput, els.quickMilesInput, els.quickMinutesInput, els.quickNotesInput].forEach((input) => {
        input.value = "";
        input.classList.remove("invalid");
      });
      els.quickNotesDetails.open = false;
    }
    renderQuickAddPreview();
  }

  function openQuickAdd() {
    setQuickAddDefaults(true);
    els.quickAddSheet.classList.remove("hidden");
    els.quickAddSheet.setAttribute("aria-hidden", "false");
    document.body.classList.add("sheet-open");
    setTimeout(() => {
      if (els.quickEarningsInput && typeof els.quickEarningsInput.focus === "function") els.quickEarningsInput.focus();
    }, 40);
  }

  function closeQuickAdd() {
    els.quickAddSheet.classList.add("hidden");
    els.quickAddSheet.setAttribute("aria-hidden", "true");
    document.body.classList.remove("sheet-open");
  }

  function renderQuickAddPreview() {
    if (!els.quickDeliveryPreview) return;
    const earnings = num(els.quickEarningsInput.value);
    const milesRaw = String(els.quickMilesInput.value || "").trim();
    const miles = num(milesRaw);
    const minutes = num(els.quickMinutesInput.value);
    if (!earnings || milesRaw === "") {
      els.quickDeliveryPreview.textContent = "Enter earnings and miles to preview profit.";
      els.quickDeliveryPreview.className = "delivery-preview";
      return;
    }
    const profit = estimatedDeliveryProfit({ earnings, miles });
    const hourly = grossHourlyRate(earnings, minutes);
    const perMile = grossDollarPerMile(earnings, miles);
    const profitMile = estimatedProfitPerMile(profit, miles);
    const good = miles === 0 ? earnings >= settings.minPayout : perMile >= settings.minPerMile && (!minutes || hourly >= settings.minPerHour);
    els.quickDeliveryPreview.className = `delivery-preview ${good ? "good" : "bad"}`;
    if (miles === 0) {
      els.quickDeliveryPreview.textContent = `${money.format(profit)} estimated profit · mileage not tracked yet${minutes ? ` · ${money.format(hourly)}/hr` : ""}`;
      return;
    }
    els.quickDeliveryPreview.textContent = `${money.format(profit)} estimated profit · ${money.format(perMile)}/mi gross · ${money.format(profitMile)}/mi profit${minutes ? ` · ${money.format(hourly)}/hr` : ""}`;
  }

  function readQuickNumber(input, label, { required = false, allowZero = true } = {}) {
    const raw = String(input.value || "").trim();
    if (required && raw === "") {
      toast(`Enter ${label}.`);
      flagInvalid(input);
      return null;
    }
    const value = num(raw);
    if ((!allowZero && value <= 0) || (allowZero && value < 0)) {
      toast(`${label} must be ${allowZero ? "0 or more" : "greater than 0"}.`);
      flagInvalid(input);
      return null;
    }
    return value;
  }

  function saveQuickDelivery(event, options = {}) {
    event.preventDefault();
    const company = allowedCompanies.has(els.quickCompanyInput.value) ? els.quickCompanyInput.value : null;
    if (!company) {
      toast("Choose a valid company.");
      flagInvalid(els.quickCompanyInput);
      return;
    }
    const earnings = readQuickNumber(els.quickEarningsInput, "earnings", { required: true, allowZero: false });
    if (earnings === null) return;
    const miles = readQuickNumber(els.quickMilesInput, "miles", { required: true, allowZero: true });
    if (miles === null) return;
    const minutes = readQuickNumber(els.quickMinutesInput, "minutes", { required: false, allowZero: true });
    if (minutes === null) return;

    const now = new Date().toISOString();
    const delivery = normalizeDelivery({
      id: makeId(),
      company,
      earnings,
      miles,
      minutes,
      zone: els.quickZoneInput.value || settings.defaultZone || "",
      notes: els.quickNotesInput.value,
      source: "manual",
      createdAt: now,
      updatedAt: now,
      version: DATA_VERSION
    });
    if (!delivery) {
      toast("Could not save this delivery. Check the quick-add fields.");
      return;
    }
    deliveries.push(delivery);
    writeJSON(STORE_KEY, deliveries);
    render();
    toast(`Saved ${money.format(delivery.earnings)} from ${delivery.company}.`);
    if (options.addAnother) {
      els.quickCompanyInput.value = delivery.company;
      els.quickZoneInput.value = delivery.zone || settings.defaultZone || "";
      [els.quickEarningsInput, els.quickMilesInput, els.quickMinutesInput, els.quickNotesInput].forEach((input) => {
        input.value = "";
        input.classList.remove("invalid");
      });
      els.quickNotesDetails.open = false;
      renderQuickAddPreview();
      if (typeof els.quickEarningsInput.focus === "function") els.quickEarningsInput.focus();
      return;
    }
    closeQuickAdd();
  }

  async function scanScreenshot(file) {
    if (!file) return;
    clearOCR(false);
    if (els.previewImage.dataset.url) URL.revokeObjectURL(els.previewImage.dataset.url);
    const url = URL.createObjectURL(file);
    els.previewImage.dataset.url = url;
    els.previewImage.src = url;
    els.previewImage.classList.remove("hidden");
    setScanState("loading", "Scanning screenshot…");

    if (!globalThis.Tesseract || typeof globalThis.Tesseract.recognize !== "function") {
      setScanState("failed", "OCR library is not loaded yet. You can still enter the delivery manually.");
      return;
    }

    try {
      const result = await globalThis.Tesseract.recognize(file, "eng");
      lastOCRText = result?.data?.text || "";
      lastOCRParsed = parseOCR(lastOCRText);
      els.ocrText.textContent = lastOCRText || "No readable text detected.";
      els.ocrDetails.classList.remove("hidden");
      renderOCRReview(lastOCRParsed);
      const label = confidenceLabel(lastOCRParsed.confidence);
      const message = label === "Needs review"
        ? "Scan complete, but confidence is low. Review and correct the fields before saving."
        : "Scan complete. Review before saving.";
      setScanState("success", message);
    } catch (err) {
      console.error(err);
      lastOCRParsed = null;
      setScanState("failed", "Could not scan this screenshot. Enter the delivery manually or try another image.");
    }
  }

  function setScanState(state, message) {
    els.scanStatus.classList.remove("hidden", "loading", "success", "failed");
    els.scanStatus.classList.add(state);
    els.scanStatus.textContent = message;
  }

  function confidenceLabel(score) {
    if (score >= 80) return "High confidence";
    if (score >= 60) return "Medium confidence";
    return "Needs review";
  }

  function renderOCRReview(parsed) {
    if (!parsed) return;
    const label = confidenceLabel(parsed.confidence);
    const platform = allowedCompanies.has(parsed.platform) ? parsed.platform : "Other";
    els.ocrCompany.textContent = parsed.platform || "Needs review";
    els.ocrEarnings.textContent = parsed.earnings ? money.format(parsed.earnings) : "Needs review";
    els.ocrMiles.textContent = parsed.miles ? `${parsed.miles.toFixed(1)} mi` : "Needs review";
    els.ocrMinutes.textContent = parsed.minutes ? `${parsed.minutes} min` : "Optional";
    els.ocrConfidence.textContent = `${parsed.confidence}%`;
    els.ocrConfidenceLabel.textContent = label;
    els.ocrConfidenceLabel.className = `status-chip ${label === "High confidence" ? "good" : label === "Medium confidence" ? "warning" : "bad"}`;
    els.ocrCompanyInput.value = platform;
    els.ocrEarningsInput.value = parsed.earnings ? parsed.earnings.toFixed(2) : "";
    els.ocrMilesInput.value = parsed.miles ? parsed.miles.toFixed(1) : "";
    els.ocrMinutesInput.value = parsed.minutes ? String(parsed.minutes) : "";
    renderOCRSavePreview();
    els.ocrReview.classList.remove("hidden");
  }

  function renderOCRSavePreview() {
    const earnings = num(els.ocrEarningsInput.value);
    const milesRaw = String(els.ocrMilesInput.value || "").trim();
    const miles = num(milesRaw);
    const minutes = num(els.ocrMinutesInput.value);
    if (!earnings || earnings <= 0 || milesRaw === "" || miles < 0 || minutes < 0) {
      els.ocrSavePreview.className = "delivery-preview warning";
      els.ocrSavePreview.textContent = "Review company, earnings, miles, and optional minutes before saving.";
      return;
    }
    const profit = estimatedDeliveryProfit({ earnings, miles });
    const perMile = grossDollarPerMile(earnings, miles);
    const perMileText = miles > 0 ? `${money.format(perMile)}/mi gross` : "No miles entered";
    const hourlyText = minutes > 0 ? ` · ${money.format(grossHourlyRate(earnings, minutes))}/hr` : "";
    els.ocrSavePreview.className = `delivery-preview ${miles > 0 && perMile >= settings.minPerMile ? "good" : "warning"}`;
    els.ocrSavePreview.textContent = `${money.format(profit)} estimated profit · ${perMileText}${hourlyText}`;
  }

  function applyParsedResult(parsed) {
    if (!parsed) return;
    const reviewed = readOCRReviewFields();
    if (!reviewed) return;
    els.companyInput.value = reviewed.company;
    els.earningsInput.value = reviewed.earnings.toFixed(2);
    els.milesInput.value = reviewed.miles.toFixed(1);
    els.minutesInput.value = reviewed.minutes ? String(reviewed.minutes) : "";
    renderDeliveryPreview();
    toast("Reviewed OCR fields moved into the manual form.");
  }

  function readOCRReviewFields() {
    const company = allowedCompanies.has(els.ocrCompanyInput.value) ? els.ocrCompanyInput.value : "Other";
    const earnings = num(els.ocrEarningsInput.value);
    const milesRaw = String(els.ocrMilesInput.value || "").trim();
    const miles = num(milesRaw);
    const minutes = num(els.ocrMinutesInput.value);
    if (!earnings || earnings <= 0) {
      toast("Review OCR earnings before saving.");
      flagInvalid(els.ocrEarningsInput);
      return null;
    }
    if (milesRaw === "" || miles < 0) {
      toast("Review OCR miles before saving.");
      flagInvalid(els.ocrMilesInput);
      return null;
    }
    if (minutes < 0) {
      toast("Minutes cannot be negative.");
      flagInvalid(els.ocrMinutesInput);
      return null;
    }
    return { company, earnings, miles, minutes };
  }

  function saveReviewedOCR() {
    if (!lastOCRParsed) return toast("Scan a screenshot before saving OCR results.");
    const reviewed = readOCRReviewFields();
    if (!reviewed) return;
    const now = new Date().toISOString();
    const delivery = normalizeDelivery({
      id: makeId(),
      company: reviewed.company,
      earnings: reviewed.earnings,
      miles: reviewed.miles,
      minutes: reviewed.minutes,
      zone: els.zoneInput.value || settings.defaultZone || "",
      notes: els.notesInput.value,
      source: "ocr",
      ocrText: lastOCRText,
      ocrConfidence: lastOCRParsed.confidence,
      createdAt: now,
      updatedAt: now,
      version: DATA_VERSION
    });
    if (!delivery) return toast("Could not save the reviewed OCR delivery.");
    deliveries.push(delivery);
    writeJSON(STORE_KEY, deliveries);
    clearForm(false);
    render();
    showTab("today");
    toast(`Saved reviewed OCR delivery: ${money.format(delivery.earnings)} from ${delivery.company}.`);
  }

  function clearOCR(clearFile = true) {
    lastOCRText = "";
    lastOCRParsed = null;
    els.ocrReview.classList.add("hidden");
    els.ocrDetails.classList.add("hidden");
    els.ocrText.textContent = "";
    els.ocrCompany.textContent = "—";
    els.ocrEarnings.textContent = "—";
    els.ocrMiles.textContent = "—";
    els.ocrMinutes.textContent = "—";
    els.ocrConfidence.textContent = "—";
    els.ocrConfidenceLabel.textContent = "Needs review";
    els.ocrConfidenceLabel.className = "status-chip";
    els.ocrCompanyInput.value = settings.defaultCompany || "DoorDash";
    els.ocrEarningsInput.value = "";
    els.ocrMilesInput.value = "";
    els.ocrMinutesInput.value = "";
    els.ocrSavePreview.textContent = "Review the detected fields before saving.";
    els.ocrSavePreview.className = "delivery-preview";
    els.scanStatus.classList.add("hidden");
    els.scanStatus.classList.remove("loading", "success", "failed");
    if (clearFile) {
      els.screenshotInput.value = "";
      if (els.previewImage.dataset.url) {
        URL.revokeObjectURL(els.previewImage.dataset.url);
        delete els.previewImage.dataset.url;
      }
      els.previewImage.removeAttribute("src");
      els.previewImage.classList.add("hidden");
    }
  }

  function parseOCR(text) {
    const normalized = String(text || "").replace(/\s+/g, " ").trim();
    const platform = detectPlatform(normalized);
    const earnings = detectEarnings(normalized);
    const miles = detectMiles(normalized);
    const minutes = detectMinutes(normalized);
    let confidence = 15;
    if (platform) confidence += 25;
    if (earnings) confidence += 30;
    if (miles) confidence += 25;
    if (minutes) confidence += 8;
    return { platform, earnings, miles, minutes, confidence: Math.min(confidence, 98) };
  }

  function detectPlatform(text) {
    const low = text.toLowerCase();
    if (/door\s*dash|doordash|dash/.test(low)) return "DoorDash";
    if (/uber\s*eats|ubereats|uber/.test(low)) return "Uber Eats";
    if (/grub\s*hub|grubhub/.test(low)) return "Grubhub";
    if (/instacart/.test(low)) return "Instacart";
    if (/spark|walmart/.test(low)) return "Spark";
    if (/roadie/.test(low)) return "Roadie";
    if (/catering|ezcater/.test(low)) return "Catering";
    return "";
  }

  function parseMoneyToken(token) {
    if (/^\d{1,3}(,\d{3})+(\.\d{2})?$/.test(token)) return Number.parseFloat(token.replace(/,/g, ""));
    return Number.parseFloat(token.replace(/,/g, "."));
  }

  function detectEarnings(text) {
    const matches = [];
    const push = (raw, index, bonus) => {
      const value = parseMoneyToken(raw);
      if (!Number.isFinite(value) || value <= 0 || value > 1000) return;
      const context = text.slice(Math.max(0, index - 70), Math.min(text.length, index + 90)).toLowerCase();
      let score = 1 + bonus;
      if (/total|earn|earning|payout|pay|paid|estimate|offer|guarantee|including|tip|fare|base/.test(context)) score += 3;
      if (/balance|cash\s*out|weekly|month|year|tax|fee|subscription|debt|per\s*hour|\/\s*hr/.test(context)) score -= 2;
      if (value >= 2 && value <= 80) score += 1;
      matches.push({ value, score, index });
    };
    const dollarRegex = /(?:\$|usd\s*)\s*([0-9]{1,3}(?:,[0-9]{3})+(?:\.[0-9]{2})?|[0-9]{1,4}(?:[.,][0-9]{2})?)/gi;
    let m;
    while ((m = dollarRegex.exec(text)) !== null) push(m[1], m.index, 0);
    const keywordRegex = /(?:total|earnings?|payout|paid|guarantee|fare|offer)[^0-9$\n]{0,14}([0-9]{1,3}(?:,[0-9]{3})*\.[0-9]{2})/gi;
    while ((m = keywordRegex.exec(text)) !== null) push(m[1], m.index, 2);
    if (!matches.length) return 0;
    matches.sort((a, b) => b.score - a.score || b.value - a.value || a.index - b.index);
    return round2(matches[0].value);
  }

  function detectMiles(text) {
    const matches = [];
    const mileRegex = /([0-9]{1,3}(?:[.,][0-9]{1,2})?)\s*(?:miles|mile|mi)(?![a-z])/gi;
    let m;
    while ((m = mileRegex.exec(text)) !== null) {
      const value = Number.parseFloat(m[1].replace(",", "."));
      if (!Number.isFinite(value) || value <= 0 || value > 300) continue;
      const context = text.slice(Math.max(0, m.index - 60), Math.min(text.length, m.index + 60)).toLowerCase();
      let score = 1;
      if (/total|trip|delivery|distance|route/.test(context)) score += 2;
      if (/mph|minutes|minute|away|radius/.test(context)) score -= 1;
      matches.push({ value, score, index: m.index });
    }
    if (!matches.length) return 0;
    matches.sort((a, b) => b.score - a.score || a.value - b.value);
    return round1(matches[0].value);
  }

  function detectMinutes(text) {
    const matches = [];
    const minuteRegex = /([0-9]{1,3})\s*(?:minutes|minute|mins|min)(?![a-z])/gi;
    let m;
    while ((m = minuteRegex.exec(text)) !== null) {
      const value = Number.parseInt(m[1], 10);
      if (!Number.isFinite(value) || value <= 0 || value > 600) continue;
      const context = text.slice(Math.max(0, m.index - 60), Math.min(text.length, m.index + 60)).toLowerCase();
      let score = 1;
      if (/estimate|estimated|time|duration|trip|delivery|total/.test(context)) score += 2;
      if (/away|pickup|arrive|eta|radius/.test(context)) score -= 1;
      matches.push({ value, score, index: m.index });
    }
    if (!matches.length) return 0;
    matches.sort((a, b) => b.score - a.score || a.value - b.value);
    return matches[0].value;
  }

  function saveDelivery(event, options = {}) {
    event.preventDefault();
    const earnings = num(els.earningsInput.value);
    const miles = num(els.milesInput.value);
    const minutes = num(els.minutesInput.value);
    const selectedCompany = els.companyInput.value || settings.defaultCompany || "Other";
    const company = allowedCompanies.has(selectedCompany) ? selectedCompany : "Other";

    if (!earnings || earnings <= 0) {
      toast("Enter the delivery earnings first.");
      flagInvalid(els.earningsInput);
      return;
    }
    if (!miles || miles <= 0) {
      toast("Enter the delivery miles first.");
      flagInvalid(els.milesInput);
      return;
    }

    const existingId = els.editDeliveryId.value;
    const existing = existingId ? deliveries.find((d) => d.id === existingId) : null;
    const now = new Date().toISOString();
    const delivery = normalizeDelivery({
      id: existingId || makeId(),
      company,
      earnings,
      miles,
      minutes,
      zone: els.zoneInput.value || settings.defaultZone || "",
      notes: els.notesInput.value,
      source: existing ? existing.source : (lastOCRText ? "ocr" : "manual"),
      ocrText: lastOCRText || existing?.ocrText || "",
      ocrConfidence: lastOCRParsed?.confidence || existing?.ocrConfidence || 0,
      createdAt: existing ? existing.createdAt : now,
      updatedAt: now,
      version: DATA_VERSION
    });
    if (!delivery) return toast("Could not save this delivery. Check the fields and try again.");

    if (existingId) deliveries = deliveries.map((d) => d.id === existingId ? delivery : d);
    else deliveries.push(delivery);
    writeJSON(STORE_KEY, deliveries);
    clearForm(!options.stayOnForm);
    render();
    if (!options.stayOnForm) showTab("today");
    toast(`${existingId ? "Updated" : "Saved"} ${money.format(delivery.earnings)} from ${company}.`);
  }

  function clearForm(keepCompany = true) {
    els.editDeliveryId.value = "";
    if (!keepCompany) els.companyInput.value = settings.defaultCompany || "DoorDash";
    els.earningsInput.value = "";
    els.milesInput.value = "";
    els.minutesInput.value = "";
    els.zoneInput.value = settings.defaultZone || "";
    els.notesInput.value = "";
    els.saveDeliveryBtn.textContent = "Save Delivery";
    els.cancelEditBtn.classList.add("hidden");
    clearOCR(true);
    renderDeliveryPreview();
  }

  function editDelivery(id) {
    const d = deliveries.find((item) => item.id === id);
    if (!d) return;
    els.editDeliveryId.value = d.id;
    els.companyInput.value = d.company;
    els.earningsInput.value = Number(d.earnings).toFixed(2);
    els.milesInput.value = Number(d.miles).toFixed(1);
    els.minutesInput.value = d.minutes ? String(d.minutes) : "";
    els.zoneInput.value = d.zone || "";
    els.notesInput.value = d.notes || "";
    els.saveDeliveryBtn.textContent = "Update Delivery";
    els.cancelEditBtn.classList.remove("hidden");
    showTab("add");
    renderDeliveryPreview();
  }

  function duplicateDelivery(id) {
    const d = deliveries.find((item) => item.id === id);
    if (!d) return;
    const copy = normalizeDelivery({ ...d, id: makeId(), source: "manual", ocrText: "", ocrConfidence: 0, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(), notes: d.notes ? `${d.notes} duplicate` : "" });
    if (!copy) return;
    deliveries.push(copy);
    writeJSON(STORE_KEY, deliveries);
    render();
    toast("Delivery duplicated for today.");
  }

  function deleteDelivery(id) {
    const item = deliveries.find((d) => d.id === id);
    if (!item) return;
    if (!confirm(`Delete ${money.format(Number(item.earnings || 0))} ${item.company} delivery?`)) return;
    lastDeleted = item;
    deliveries = deliveries.filter((d) => d.id !== id);
    writeJSON(STORE_KEY, deliveries);
    render();
    toast("Delivery deleted.", { label: "Undo", handler: undoDelete });
  }

  function undoDelete() {
    if (!lastDeleted) return;
    if (!deliveries.some((d) => d.id === lastDeleted.id)) {
      deliveries.push(lastDeleted);
      deliveries = normalizeDeliveries(deliveries);
      writeJSON(STORE_KEY, deliveries);
      render();
      toast("Delivery restored.");
    }
    lastDeleted = null;
  }

  function clearToday() {
    const todays = todayDeliveries();
    if (!todays.length) return toast("There are no deliveries saved for today.");
    if (!confirm(`Delete ${todays.length} ${todays.length === 1 ? "delivery" : "deliveries"} from today?`)) return;
    const today = todayKey();
    deliveries = deliveries.filter((d) => todayKey(new Date(d.createdAt)) !== today);
    writeJSON(STORE_KEY, deliveries);
    render();
    showTab("today");
    toast("Today's deliveries deleted.");
  }

  function saveSettings() {
    settings = normalizeSettings({
      dailyGoal: els.goalInput.value,
      defaultCompany: els.defaultCompanyInput.value,
      gasPrice: els.gasPriceInput.value,
      mpg: els.mpgInput.value,
      maintenancePerMile: els.maintenanceInput.value,
      taxMileageRate: els.taxRateInput.value,
      minPerMile: els.minPerMileInput.value,
      minPerHour: els.minPerHourInput.value,
      minPayout: els.minPayoutInput.value,
      maxMiles: els.maxMilesInput.value,
      defaultZone: els.defaultZoneInput.value
    });
    writeJSON(SETTINGS_KEY, settings);
    els.companyInput.value = settings.defaultCompany;
    els.offerCompanyInput.value = settings.defaultCompany;
    els.offerZoneInput.value = settings.defaultZone || "";
    if (els.offerNoteInput) els.offerNoteInput.value = "";
    els.zoneInput.value = settings.defaultZone || "";
    render();
    showTab("today");
    toast("Settings saved.");
  }

  function toggleShift() {
    if (shift.active && shift.startedAt && isToday(shift.startedAt)) {
      const now = new Date().toISOString();
      const todays = todayDeliveries();
      const summary = buildShiftSummaryText(todays, calculate(todays));
      shift = normalizeShift({
        ...shift,
        active: false,
        startedAt: shift.startedAt,
        endedAt: now,
        lastSummary: summary,
        shiftHistory: [
          ...(shift.shiftHistory || []),
          { id: makeId(), startedAt: shift.startedAt, endedAt: now, summary, createdAt: now, version: DATA_VERSION }
        ]
      });
      toast("Day ended. Time and hourly stats are frozen.");
    } else {
      shift = normalizeShift({ ...shift, active: true, startedAt: new Date().toISOString(), endedAt: null });
      toast("Day started. The clock is running.");
    }
    writeJSON(SHIFT_KEY, shift);
    render();
  }

  function buildShiftSummaryText(rows, c = calculate(rows)) {
    if (!rows.length) return `No deliveries saved for ${todayKey()}.`;
    const bestCompany = bestGroup(rows, "company");
    const bestZone = bestGroup(rows, "zone");
    return [
      `DriveLedger summary for ${todayKey()}`,
      `Earned: ${money.format(c.earnings)}`,
      `Estimated profit: ${money.format(c.profit)}`,
      `Deliveries: ${c.orders}`,
      `Miles: ${c.miles.toFixed(1)}`,
      `Gross/hour: ${money.format(c.avgHour)}`,
      `Profit/hour: ${money.format(c.profitHour)}`,
      `Best company: ${bestCompany ? bestCompany.name : "Not enough data"}`,
      `Best zone: ${bestZone ? bestZone.name : "Not enough data"}`
    ].join("\n");
  }

  function buildCSV(kind = "standard") {
    const header = kind === "tax"
      ? ["date", "company", "earnings", "business_miles", "estimated_mileage_deduction", "estimated_vehicle_cost", "estimated_profit", "zone", "source", "ocr_confidence", "notes"]
      : ["date", "company", "earnings", "miles", "minutes", "dollars_per_mile", "estimated_profit", "zone", "source", "ocr_confidence", "notes"];
    const rows = deliveries.filter((item) => !item.deleted)
      .sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt))
      .map((d) => kind === "tax"
        ? [
            new Date(d.createdAt).toISOString(),
            d.company,
            d.earnings,
            d.miles,
            mileageDeduction(d.miles),
            ProfitEngine.vehicleCost(d.miles, settings),
            deliveryProfit(d),
            d.zone || "",
            d.source || "manual",
            d.ocrConfidence || "",
            d.notes || ""
          ]
        : [
            new Date(d.createdAt).toISOString(),
            d.company,
            d.earnings,
            d.miles,
            d.minutes || "",
            grossDollarPerMile(d.earnings, d.miles),
            deliveryProfit(d),
            d.zone || "",
            d.source || "manual",
            d.ocrConfidence || "",
            d.notes || ""
          ]
      );
    return [header, ...rows]
      .map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(","))
      .join("\r\n");
  }

  async function shareOrDownload(content, filename, type) {
    if (navigator.canShare && typeof File === "function") {
      try {
        const file = new File([content], filename, { type });
        if (navigator.canShare({ files: [file] })) {
          await navigator.share({ files: [file], title: filename });
          return;
        }
      } catch (err) {
        if (err && err.name === "AbortError") return;
      }
    }
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
  }

  async function exportCSV(kind = "standard") {
    if (!deliveries.length) return toast("No deliveries to export yet.");
    const csv = "\uFEFF" + buildCSV(kind);
    const suffix = kind === "tax" ? "tax" : "deliveries";
    await shareOrDownload(csv, `driveledger-${suffix}-${todayKey()}.csv`, "text/csv;charset=utf-8");
    toast(kind === "tax" ? "Tax CSV exported." : "CSV exported.");
  }

  async function exportBackup() {
    const backup = {
      app: "DriveLedger",
      version: BACKUP_VERSION,
      dataVersion: DATA_VERSION,
      exportedAt: new Date().toISOString(),
      schema: {
        delivery: ["id", "date", "createdAt", "updatedAt", "company", "earnings", "miles", "minutes", "zone", "note", "notes", "source", "ocrText", "ocrConfidence", "tags", "deleted", "version"],
        settings: ["dailyGoal", "defaultCompany", "defaultZone", "gasPrice", "vehicleMpg", "maintenanceCostPerMile", "mileageDeductionRate", "minimumDollarPerMile", "minimumDollarPerHour", "minimumPayout", "maxMiles", "theme", "appDataVersion"],
        shift: ["active", "startedAt", "endedAt", "lastSummary", "shiftHistory", "appDataVersion"]
      },
      settings,
      shift,
      deliveries
    };
    await shareOrDownload(JSON.stringify(backup, null, 2), `driveledger-backup-${todayKey()}.json`, "application/json;charset=utf-8");
    toast("Backup exported.");
  }

  async function importBackup(file) {
    if (!file) return;
    try {
      const text = await file.text();
      const parsed = JSON.parse(text);
      const rawImportedDeliveries = Array.isArray(parsed.deliveries) ? parsed.deliveries : [];
      const importedDeliveries = rawImportedDeliveries
        .map((d) => normalizeDelivery({ ...d, source: validSources.has(d?.source) ? d.source : "import" }))
        .filter(Boolean);
      const importedSettings = normalizeSettings(parsed.settings || {});
      const importedShift = normalizeShift(parsed.shift || {});
      if (!importedDeliveries.length && !confirm("This backup has no deliveries. Import settings anyway?")) return;
      if (!confirm(`Import ${importedDeliveries.length} deliveries and replace current local data? A rollback copy of your current data will be saved first.`)) return;
      writeJSON(ROLLBACK_KEY, {
        app: "DriveLedger",
        version: BACKUP_VERSION,
        dataVersion: DATA_VERSION,
        savedAt: new Date().toISOString(),
        reason: "pre-import rollback",
        settings,
        shift,
        deliveries
      });
      deliveries = importedDeliveries;
      settings = importedSettings;
      shift = importedShift;
      writeJSON(STORE_KEY, deliveries);
      writeJSON(SETTINGS_KEY, settings);
      writeJSON(SHIFT_KEY, shift);
      render();
      toast("Backup imported.");
    } catch (err) {
      console.error(err);
      toast("Could not import backup. Check the JSON file.");
    } finally {
      els.importInput.value = "";
    }
  }

  function restoreRollback() {
    const rollback = readJSON(ROLLBACK_KEY, null);
    if (!rollback) return toast("No import rollback backup found.");
    const rollbackDeliveries = normalizeDeliveries(rollback.deliveries || []);
    const rollbackSettings = normalizeSettings(rollback.settings || {});
    const rollbackShift = normalizeShift(rollback.shift || {});
    if (!confirm(`Restore rollback from ${rollback.savedAt ? new Date(rollback.savedAt).toLocaleString() : "previous import"}? This replaces current local data.`)) return;
    deliveries = rollbackDeliveries;
    settings = rollbackSettings;
    shift = rollbackShift;
    writeJSON(STORE_KEY, deliveries);
    writeJSON(SETTINGS_KEY, settings);
    writeJSON(SHIFT_KEY, shift);
    render();
    toast("Rollback restored.");
  }

  async function copySummary() {
    const todays = todayDeliveries();
    if (!todays.length) return toast("No summary to copy yet.");
    if (!navigator.clipboard || typeof navigator.clipboard.writeText !== "function") {
      toast("Copy is not available in this browser.");
      return;
    }
    const c = calculate(todays);
    const text = `DriveLedger summary for ${todayKey()}\nEarned: ${money.format(c.earnings)}\nEstimated profit: ${money.format(c.profit)}\nDeliveries: ${c.orders}\nMiles: ${c.miles.toFixed(1)}\nGross/hour: ${money.format(c.avgHour)}\nProfit/hour: ${money.format(c.profitHour)}`;
    try {
      await navigator.clipboard.writeText(text);
      toast("Summary copied.");
    } catch {
      toast("Copy is not available in this browser.");
    }
  }

  function saveOfferAsDelivery() {
    const pay = num(els.offerPayInput.value);
    const miles = num(els.offerMilesInput.value);
    const minutes = num(els.offerMinutesInput.value);
    const decision = evaluateOffer(pay, miles, minutes);
    if (decision.kind === "neutral") {
      renderDecision();
      if (!(pay > 0)) flagInvalid(els.offerPayInput);
      else if (!(miles > 0)) flagInvalid(els.offerMilesInput);
      else if (!(minutes > 0)) flagInvalid(els.offerMinutesInput);
      return toast("Enter valid pay, miles, and minutes before saving.");
    }
    const company = allowedCompanies.has(els.offerCompanyInput.value) ? els.offerCompanyInput.value : settings.defaultCompany;
    const note = cleanText(els.offerNoteInput.value || "Saved from accept calculator", 400);
    const now = new Date().toISOString();
    const delivery = normalizeDelivery({
      id: makeId(),
      company,
      earnings: pay,
      miles,
      minutes,
      zone: els.offerZoneInput.value || settings.defaultZone,
      notes: note,
      source: "calculator",
      tags: [decision.title.toLowerCase()],
      createdAt: now,
      updatedAt: now,
      version: DATA_VERSION
    });
    if (!delivery) return toast("Could not save this offer.");
    deliveries.push(delivery);
    writeJSON(STORE_KEY, deliveries);
    clearOfferCalculator();
    render();
    showTab("today");
    toast(`${decision.title} offer saved as a completed delivery.`);
  }

  function flagInvalid(input) {
    input.classList.add("invalid");
    input.focus();
    setTimeout(() => input.classList.remove("invalid"), 1200);
  }

  function toast(message, action = null) {
    if (!els.toast) return;
    toastAction = action && typeof action.handler === "function" ? action.handler : null;
    if (toastAction) {
      els.toast.innerHTML = `<span>${escapeHTML(message)}</span><button type="button" data-toast-action>${escapeHTML(action.label || "Undo")}</button>`;
    } else {
      els.toast.textContent = message;
    }
    els.toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
      els.toast.classList.remove("show");
      toastAction = null;
    }, 4200);
  }

  function bindEvents() {
    document.querySelectorAll(".tab-btn").forEach((btn) => btn.addEventListener("click", () => showTab(btn.dataset.tab)));
    document.querySelectorAll("[data-tab-jump]").forEach((btn) => btn.addEventListener("click", () => showTab(btn.dataset.tabJump)));
    document.querySelectorAll("[data-open-add]").forEach((btn) => btn.addEventListener("click", () => openAdd(btn.dataset.openAdd)));
    document.querySelectorAll("[data-quick-add-open]").forEach((btn) => btn.addEventListener("click", openQuickAdd));
    document.querySelectorAll("[data-quick-add-cancel]").forEach((btn) => btn.addEventListener("click", closeQuickAdd));
    $("deliveryForm").addEventListener("submit", saveDelivery);
    els.quickAddForm.addEventListener("submit", saveQuickDelivery);
    els.saveSettingsBtn.addEventListener("click", saveSettings);
    els.clearTodayBtn.addEventListener("click", clearToday);
    els.exportBtn.addEventListener("click", () => exportCSV("standard"));
    els.exportTaxBtn.addEventListener("click", () => exportCSV("tax"));
    els.backupBtn.addEventListener("click", exportBackup);
    els.restoreRollbackBtn.addEventListener("click", restoreRollback);
    els.importInput.addEventListener("change", (event) => importBackup(event.target.files?.[0]));
    els.copySummaryBtn.addEventListener("click", copySummary);
    els.shiftBtn.addEventListener("click", toggleShift);
    if (els.heroShiftBtn) els.heroShiftBtn.addEventListener("click", toggleShift);
    els.toast.addEventListener("click", (event) => {
      if (event.target.closest("[data-toast-action]") && toastAction) {
        const action = toastAction;
        toastAction = null;
        action();
      }
    });
    els.screenshotInput.addEventListener("change", (event) => scanScreenshot(event.target.files?.[0]));
    els.saveOcrBtn.addEventListener("click", saveReviewedOCR);
    els.applyOcrBtn.addEventListener("click", () => applyParsedResult(lastOCRParsed));
    els.cancelOcrBtn.addEventListener("click", () => clearOCR(true));
    els.clearOcrBtn.addEventListener("click", () => clearOCR(true));
    [els.ocrCompanyInput, els.ocrEarningsInput, els.ocrMilesInput, els.ocrMinutesInput].forEach((input) => {
      input.addEventListener("input", renderOCRSavePreview);
      input.addEventListener("change", renderOCRSavePreview);
    });
    els.quickSaveAnotherBtn.addEventListener("click", () => saveQuickDelivery({ preventDefault() {} }, { addAnother: true }));
    [els.quickEarningsInput, els.quickMilesInput, els.quickMinutesInput].forEach((input) => input.addEventListener("input", renderQuickAddPreview));
    els.quickCompanyInput.addEventListener("change", renderQuickAddPreview);
    els.saveAddAnotherBtn.addEventListener("click", () => saveDelivery({ preventDefault() {} }, { stayOnForm: true }));
    els.cancelEditBtn.addEventListener("click", () => { clearForm(false); render(); });
    [els.earningsInput, els.milesInput, els.minutesInput].forEach((input) => input.addEventListener("input", renderDeliveryPreview));
    [els.offerPayInput, els.offerMilesInput, els.offerMinutesInput, els.offerCompanyInput, els.offerZoneInput, els.offerNoteInput].forEach((input) => input.addEventListener("input", renderDecision));
    els.calculateOfferBtn.addEventListener("click", () => renderDecision({ announce: true }));
    els.clearOfferBtn.addEventListener("click", () => { clearOfferCalculator(); toast("Calculator cleared."); });
    els.copyDecisionBtn.addEventListener("click", copyDecisionSummary);
    els.saveOfferAsDeliveryBtn.addEventListener("click", saveOfferAsDelivery);
    els.historyList.addEventListener("click", (event) => {
      const action = event.target.closest("[data-delete],[data-edit],[data-duplicate],[data-open-add]");
      if (!action) return;
      if (action.dataset.delete) deleteDelivery(action.dataset.delete);
      else if (action.dataset.edit) editDelivery(action.dataset.edit);
      else if (action.dataset.duplicate) duplicateDelivery(action.dataset.duplicate);
      else if (action.dataset.openAdd) openAdd(action.dataset.openAdd);
    });
    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape" && !els.quickAddSheet.classList.contains("hidden")) closeQuickAdd();
    });
    document.addEventListener("visibilitychange", () => {
      if (!document.hidden) checkDayAndRender(true);
    });
    window.addEventListener("pageshow", () => checkDayAndRender(true));
  }

  function checkDayAndRender(full = false) {
    const key = todayKey();
    if (key !== lastDayKey) {
      lastDayKey = key;
      render();
      return;
    }
    if (full) render();
    else renderLive();
  }

  function registerServiceWorker() {
    if (!document.querySelector('link[rel="manifest"]')) return;
    if ("serviceWorker" in navigator && ["http:", "https:"].includes(location.protocol)) {
      navigator.serviceWorker.register("service-worker.js").catch((err) => console.warn("Service worker registration failed", err));
    }
  }

  function init() {
    persistNormalizedState();
    els.companyInput.value = settings.defaultCompany;
    els.offerCompanyInput.value = settings.defaultCompany;
    els.offerZoneInput.value = settings.defaultZone || "";
    if (els.offerNoteInput) els.offerNoteInput.value = "";
    els.zoneInput.value = settings.defaultZone || "";
    setQuickAddDefaults(true);
    bindEvents();
    render();
    registerServiceWorker();
    setInterval(() => checkDayAndRender(false), 30000);
  }

  init();
})();
