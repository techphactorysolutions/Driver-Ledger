#!/usr/bin/env node
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { webcrypto } = require('node:crypto');

const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const appCode = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const idMatches = [...html.matchAll(/\sid=["']([^"']+)["']/g)].map((m) => m[1]);
const tabNames = [...html.matchAll(/data-tab=["']([^"']+)["']/g)].map((m) => m[1]);
const openAddModes = [...html.matchAll(/data-open-add=["']([^"']+)["']/g)].map((m) => m[1]);
const tabJumpNames = [...html.matchAll(/data-tab-jump=["']([^"']+)["']/g)].map((m) => m[1]);
const quickAddOpenIds = [...html.matchAll(/id=["']([^"']+)["'][^>]*data-quick-add-open/g)].map((m) => m[1]);
const quickAddCancelIds = [...html.matchAll(/id=["']([^"']+)["'][^>]*data-quick-add-cancel/g)].map((m) => m[1]);

class MockClassList {
  constructor() { this.values = new Set(); }
  add(...items) { items.forEach((item) => this.values.add(item)); }
  remove(...items) { items.forEach((item) => this.values.delete(item)); }
  contains(item) { return this.values.has(item); }
}

function createElement(id = '') {
  return {
    id,
    value: '',
    textContent: '',
    innerHTML: '',
    dataset: {},
    style: {},
    files: [],
    classList: new MockClassList(),
    listeners: {},
    addEventListener(type, handler) {
      this.listeners[type] ||= [];
      this.listeners[type].push(handler);
    },
    appendChild() {},
    remove() {},
    click() {},
    focus() { document.activeElement = this; },
    blur() { if (document.activeElement === this) document.activeElement = null; },
    setAttribute(name, value) { this[name] = value; },
    removeAttribute(name) { delete this[name]; },
    closest(selector) {
      if (selector === '[data-toast-action]' && this.dataset.toastAction !== undefined) return this;
      return null;
    }
  };
}

function createHarness(seedStorage = {}, options = {}) {
  const elements = new Map();
  for (const id of idMatches) elements.set(id, createElement(id));

  const trendCard = createElement('trend-card');
  const tabButtons = [...new Set(tabNames)].map((tab) => {
    const el = createElement(`tab-btn-${tab}`);
    el.dataset.tab = tab;
    return el;
  });
  const addButtons = [...new Set(openAddModes)].map((mode) => {
    const el = createElement(`open-add-${mode}`);
    el.dataset.openAdd = mode;
    return el;
  });
  const jumpButtons = [...new Set(tabJumpNames)].map((tab) => {
    const el = createElement(`jump-${tab}`);
    el.dataset.tabJump = tab;
    return el;
  });
  const quickOpenButtons = [...new Set(quickAddOpenIds)].map((id) => elements.get(id)).filter(Boolean);
  const quickCancelButtons = [...new Set(quickAddCancelIds)].map((id) => elements.get(id)).filter(Boolean);
  quickCancelButtons.forEach((el) => { el.dataset.quickAddCancel = ''; });
  const screens = [...new Set(tabNames)].map((tab) => elements.get(`tab-${tab}`)).filter(Boolean);

  const storage = new Map(Object.entries(seedStorage));
  global.document = {
    activeElement: null,
    hidden: false,
    body: createElement('body'),
    getElementById(id) { return elements.get(id) || null; },
    querySelector(selector) {
      if (selector === '.trend-card') return trendCard;
      if (selector === 'link[rel="manifest"]') return createElement('manifest-link');
      const tabMatch = selector.match(/^\.tab-btn\[data-tab="(.+)"\]$/);
      if (tabMatch) return tabButtons.find((button) => button.dataset.tab === tabMatch[1]) || null;
      return null;
    },
    querySelectorAll(selector) {
      if (selector === '.tab-btn') return tabButtons;
      if (selector === '[data-open-add]') return addButtons;
      if (selector === '[data-tab-jump]') return jumpButtons;
      if (selector === '[data-quick-add-open]') return quickOpenButtons;
      if (selector === '[data-quick-add-cancel]') return quickCancelButtons;
      if (selector === '.tab-screen') return screens;
      return [];
    },
    createElement(tag) { return createElement(tag); },
    addEventListener() {}
  };
  const document = global.document;

  const context = {
    console: options.console || console,
    document,
    window: { addEventListener() {} },
    navigator: options.navigator || { clipboard: { writeText: async () => {} } },
    location: { protocol: 'http:', hostname: 'localhost' },
    localStorage: {
      getItem(key) { return storage.has(key) ? storage.get(key) : null; },
      setItem(key, value) { storage.set(key, String(value)); }
    },
    confirm: () => true,
    crypto: webcrypto,
    setInterval: () => 1,
    clearInterval: () => {},
    setTimeout: (fn) => { if (typeof fn === 'function') fn(); return 1; },
    clearTimeout: () => {},
    URL: {
      createObjectURL: () => 'blob:mock',
      revokeObjectURL: () => {}
    },
    Blob,
    File: typeof File === 'function' ? File : class File extends Blob { constructor(parts, name, opts) { super(parts, opts); this.name = name; } },
    Intl,
    Date,
    Math,
    Number,
    String,
    RegExp,
    Map,
    Set,
    Array,
    Object,
    JSON,
    Promise,
    Uint8Array,
    Tesseract: options.Tesseract,
    globalThis: null
  };
  context.globalThis = context;
  return { context, elements, storage };
}

function callFirst(element, type, event = {}) {
  if (!element.listeners[type] || !element.listeners[type].length) throw new Error(`${element.id} has no ${type} listener`);
  return element.listeners[type][0](event);
}

function runStartup(seedStorage) {
  const harness = createHarness(seedStorage);
  vm.runInNewContext(appCode, harness.context, { filename: 'app.js' });

  const form = harness.elements.get('deliveryForm');
  harness.elements.get('companyInput').value = 'DoorDash';
  harness.elements.get('earningsInput').value = '18.75';
  harness.elements.get('milesInput').value = '5.4';
  harness.elements.get('minutesInput').value = '24';
  harness.elements.get('zoneInput').value = 'South City';
  callFirst(form, 'submit', { preventDefault() {} });

  const saved = harness.storage.get('driveledger.deliveries.v1');
  if (!saved || !saved.includes('18.75') || !saved.includes('South City')) {
    throw new Error('manual delivery save did not persist full delivery details to localStorage');
  }
  const firstDelivery = JSON.parse(saved)[0];
  if (firstDelivery.source !== 'manual' || !firstDelivery.updatedAt || !firstDelivery.version) {
    throw new Error('manual delivery did not persist normalized metadata');
  }
  for (const key of ['date', 'note', 'notes', 'tags', 'deleted', 'createdAt', 'updatedAt', 'version']) {
    if (!(key in firstDelivery)) throw new Error(`manual delivery missing normalized ${key} field`);
  }
  if (!harness.elements.get('profitLine').textContent.includes('$17.35')) {
    throw new Error(`central profit engine did not render expected first-delivery profit: ${harness.elements.get('profitLine').textContent}`);
  }
  if (!harness.elements.get('taxDeduction').textContent.includes('$3.62')) {
    throw new Error(`central profit engine did not render expected mileage deduction: ${harness.elements.get('taxDeduction').textContent}`);
  }

  const quickOpen = harness.elements.get('quickAddOpenBtn');
  if (!quickOpen.listeners.click?.length) throw new Error('quick add open button is not wired');
  callFirst(quickOpen, 'click', {});
  if (harness.elements.get('quickAddSheet').classList.contains('hidden')) {
    throw new Error('quick add sheet did not open');
  }
  harness.elements.get('quickEarningsInput').value = '15.25';
  harness.elements.get('quickMilesInput').value = '0';
  harness.elements.get('quickMinutesInput').value = '20';
  harness.elements.get('quickZoneInput').value = 'South City';
  callFirst(harness.elements.get('quickAddForm'), 'submit', { preventDefault() {} });
  const savedAfterQuick = JSON.parse(harness.storage.get('driveledger.deliveries.v1'));
  if (!savedAfterQuick.some((d) => d.earnings === 15.25 && d.miles === 0 && d.zone === 'South City' && d.source === 'manual')) {
    throw new Error('quick add did not persist a zero-mile delivery with metadata');
  }
  if (!harness.elements.get('quickAddSheet').classList.contains('hidden')) {
    throw new Error('quick add sheet did not close after save');
  }
  if (!harness.elements.get('todayEarned').textContent.includes('34.00')) {
    throw new Error('dashboard did not update after quick add save');
  }

  callFirst(quickOpen, 'click', {});
  harness.elements.get('quickEarningsInput').value = '0';
  harness.elements.get('quickMilesInput').value = '2';
  const beforeInvalidQuick = JSON.parse(harness.storage.get('driveledger.deliveries.v1')).length;
  callFirst(harness.elements.get('quickAddForm'), 'submit', { preventDefault() {} });
  const afterInvalidQuick = JSON.parse(harness.storage.get('driveledger.deliveries.v1')).length;
  if (afterInvalidQuick !== beforeInvalidQuick || !harness.elements.get('toast').textContent.includes('earnings')) {
    throw new Error('quick add invalid earnings should be rejected without saving');
  }
  callFirst(harness.elements.get('quickCancelBtn'), 'click', {});

  harness.elements.get('companyInput').value = 'Uber Eats';
  harness.elements.get('earningsInput').value = '11.50';
  harness.elements.get('milesInput').value = '3.1';
  harness.elements.get('minutesInput').value = '18';
  harness.elements.get('zoneInput').value = 'Tower Grove';
  callFirst(harness.elements.get('saveAddAnotherBtn'), 'click', {});
  const afterAddAnother = JSON.parse(harness.storage.get('driveledger.deliveries.v1'));
  if (afterAddAnother.length < 2 || !afterAddAnother.some((d) => d.zone === 'Tower Grove')) {
    throw new Error('save + add another did not persist a second delivery');
  }

  harness.elements.get('offerPayInput').value = '9.75';
  harness.elements.get('offerMilesInput').value = '4.2';
  harness.elements.get('offerMinutesInput').value = '22';
  harness.elements.get('offerZoneInput').value = 'Kirkwood';
  callFirst(harness.elements.get('offerPayInput'), 'input', {});
  if (!harness.elements.get('decisionResult').innerHTML.includes('ACCEPT')) {
    throw new Error('accept calculator did not render an ACCEPT decision for a strong offer');
  }
  callFirst(harness.elements.get('saveOfferAsDeliveryBtn'), 'click', {});
  const savedAfterOffer = JSON.parse(harness.storage.get('driveledger.deliveries.v1'));
  if (savedAfterOffer.length < 3) throw new Error('save offer as delivery did not persist');
  if (!savedAfterOffer.some((d) => d.source === 'calculator' && d.zone === 'Kirkwood')) {
    throw new Error('calculator delivery did not persist source and zone metadata');
  }

  if (!harness.elements.get('heroShiftBtn').listeners.click?.length) {
    throw new Error('hero shift action is not wired');
  }
  callFirst(harness.elements.get('shiftBtn'), 'click', {});
  if (!harness.storage.get('driveledger.shift.v1')?.includes('startedAt')) {
    throw new Error('shift toggle did not persist shift state');
  }
  callFirst(harness.elements.get('shiftBtn'), 'click', {});
  const completedShift = JSON.parse(harness.storage.get('driveledger.shift.v1'));
  if (!Array.isArray(completedShift.shiftHistory) || !completedShift.shiftHistory.length || !completedShift.lastSummary) {
    throw new Error('ending a shift did not persist lastSummary and shiftHistory');
  }

  for (const id of ['projectedTotal', 'goalEta', 'avgDeliveryValue', 'taxMiles', 'vehicleCostToday', 'bestCompanyToday', 'bestZoneToday', 'performanceRecommendation']) {
    const el = harness.elements.get(id);
    if (!el) throw new Error(`phase 3 command center element missing in smoke harness: ${id}`);
    const rendered = `${el.textContent || ''} ${el.innerHTML || ''}`;
    if (/NaN|Infinity|undefined|null/.test(rendered)) {
      throw new Error(`phase 3 command center rendered unsafe value in ${id}: ${rendered}`);
    }
  }

  if (!harness.elements.get('bestCompanyToday').textContent || harness.elements.get('bestCompanyToday').textContent === '—') {
    throw new Error('best company command metric did not update after saved deliveries');
  }
  if (!harness.elements.get('bestZoneToday').textContent || harness.elements.get('bestZoneToday').textContent === '—') {
    throw new Error('best zone command metric did not update after saved deliveries');
  }
}

runStartup({});

function runMigrationSmoke() {
  const legacyDate = new Date().toISOString();
  const legacyDeliveries = [{
    id: 'legacy-1',
    company: 'NotAPlatform',
    earnings: '$22.40',
    miles: '0',
    minutes: 'bad',
    zone: '  South City  ',
    note: 'legacy note',
    createdAt: legacyDate,
    tags: ['Lunch', ' lunch ', '<script>']
  }];
  const legacySettings = {
    dailyGoal: '250',
    defaultCompany: 'BadApp',
    gasPrice: '3.25',
    mpg: '28',
    maintenancePerMile: '0.15',
    taxMileageRate: '0.70',
    minPerMile: '1.75',
    minPerHour: '24',
    minPayout: '8',
    maxMiles: '10',
    theme: 'neon'
  };
  const legacyShift = {
    active: true,
    startedAt: legacyDate,
    lastSummary: 123,
    shiftHistory: [{ startedAt: legacyDate, endedAt: legacyDate, summary: 'old shift' }]
  };
  const harness = createHarness({
    'driveledger.deliveries.v1': JSON.stringify(legacyDeliveries),
    'driveledger.settings.v1': JSON.stringify(legacySettings),
    'driveledger.shift.v1': JSON.stringify(legacyShift)
  });
  vm.runInNewContext(appCode, harness.context, { filename: 'app.js' });
  const migratedDeliveries = JSON.parse(harness.storage.get('driveledger.deliveries.v1'));
  const migratedSettings = JSON.parse(harness.storage.get('driveledger.settings.v1'));
  const migratedShift = JSON.parse(harness.storage.get('driveledger.shift.v1'));

  if (migratedDeliveries.length !== 1) throw new Error('legacy delivery was not preserved during migration');
  const d = migratedDeliveries[0];
  if (d.company !== 'Other' || d.miles !== 0 || d.note !== 'legacy note' || d.notes !== 'legacy note') {
    throw new Error('legacy delivery fields were not normalized safely');
  }
  for (const key of ['date', 'source', 'ocrText', 'ocrConfidence', 'tags', 'deleted', 'version']) {
    if (!(key in d)) throw new Error(`migrated delivery missing ${key}`);
  }
  if (migratedSettings.vehicleMpg !== 28 || migratedSettings.mpg !== 28) {
    throw new Error('settings MPG alias migration failed');
  }
  if (migratedSettings.maintenanceCostPerMile !== 0.15 || migratedSettings.maintenancePerMile !== 0.15) {
    throw new Error('settings maintenance alias migration failed');
  }
  if (migratedSettings.mileageDeductionRate !== 0.7 || migratedSettings.taxMileageRate !== 0.7) {
    throw new Error('settings mileage deduction alias migration failed');
  }
  if (migratedSettings.defaultCompany !== 'DoorDash' || migratedSettings.theme !== 'system' || migratedSettings.appDataVersion !== 4) {
    throw new Error('invalid settings were not defaulted during migration');
  }
  if (!Array.isArray(migratedShift.shiftHistory) || migratedShift.shiftHistory.length !== 1 || migratedShift.appDataVersion !== 4) {
    throw new Error('shift history migration failed');
  }
}


async function runOCRReviewSmoke() {
  const sampleText = 'DoorDash offer Total $14.25 Distance 6.8 miles Estimated time 31 min';
  const harness = createHarness({}, {
    Tesseract: { recognize: async () => ({ data: { text: sampleText } }) }
  });
  vm.runInNewContext(appCode, harness.context, { filename: 'app.js' });

  await callFirst(harness.elements.get('screenshotInput'), 'change', { target: { files: [{ name: 'doordash.png' }] } });
  if (harness.elements.get('ocrReview').classList.contains('hidden')) {
    throw new Error('OCR review card should be visible after successful scan');
  }
  if (!harness.elements.get('ocrCompanyInput').value.includes('DoorDash')) {
    throw new Error('OCR did not parse sample DoorDash company');
  }
  if (harness.elements.get('ocrEarningsInput').value !== '14.25') {
    throw new Error(`OCR did not parse sample earnings: ${harness.elements.get('ocrEarningsInput').value}`);
  }
  if (harness.elements.get('ocrMilesInput').value !== '6.8') {
    throw new Error(`OCR did not parse sample miles: ${harness.elements.get('ocrMilesInput').value}`);
  }
  if (harness.elements.get('ocrMinutesInput').value !== '31') {
    throw new Error(`OCR did not parse sample minutes: ${harness.elements.get('ocrMinutesInput').value}`);
  }
  if (!harness.elements.get('ocrConfidenceLabel').textContent.includes('High confidence')) {
    throw new Error('OCR confidence label should show High confidence for complete sample text');
  }

  const beforeSave = JSON.parse(harness.storage.get('driveledger.deliveries.v1') || '[]').length;
  await callFirst(harness.elements.get('saveOcrBtn'), 'click', {});
  const saved = JSON.parse(harness.storage.get('driveledger.deliveries.v1') || '[]');
  if (saved.length !== beforeSave + 1) throw new Error('saving reviewed OCR did not persist a delivery');
  const ocrDelivery = saved.find((d) => d.source === 'ocr');
  if (!ocrDelivery || ocrDelivery.company !== 'DoorDash' || ocrDelivery.earnings !== 14.25 || ocrDelivery.miles !== 6.8 || ocrDelivery.minutes !== 31 || !ocrDelivery.ocrText) {
    throw new Error('reviewed OCR delivery was not normalized with OCR metadata');
  }

  const lowHarness = createHarness({}, {
    Tesseract: { recognize: async () => ({ data: { text: 'parking garage receipt no pay or miles here' } }) }
  });
  vm.runInNewContext(appCode, lowHarness.context, { filename: 'app.js' });
  await callFirst(lowHarness.elements.get('screenshotInput'), 'change', { target: { files: [{ name: 'low.png' }] } });
  const lowSaved = JSON.parse(lowHarness.storage.get('driveledger.deliveries.v1') || '[]');
  if (lowSaved.length) throw new Error('low-confidence OCR should not autosave');
  if (!lowHarness.elements.get('ocrConfidenceLabel').textContent.includes('Needs review')) {
    throw new Error('low-confidence OCR should be labeled Needs review');
  }
  await callFirst(lowHarness.elements.get('saveOcrBtn'), 'click', {});
  const lowAfterSaveAttempt = JSON.parse(lowHarness.storage.get('driveledger.deliveries.v1') || '[]');
  if (lowAfterSaveAttempt.length) throw new Error('invalid low-confidence OCR fields should be rejected when saving');

  const failHarness = createHarness({}, {
    console: { ...console, error() {} },
    Tesseract: { recognize: async () => { throw new Error('OCR unavailable'); } }
  });
  vm.runInNewContext(appCode, failHarness.context, { filename: 'app.js' });
  await callFirst(failHarness.elements.get('screenshotInput'), 'change', { target: { files: [{ name: 'fail.png' }] } });
  if (!failHarness.elements.get('scanStatus').textContent.includes('Could not scan')) {
    throw new Error('OCR failure should show failed status instead of crashing');
  }
}

function runClipboardUnavailableSmoke() {
  const harness = createHarness({}, { navigator: {} });
  vm.runInNewContext(appCode, harness.context, { filename: 'app.js' });

  const form = harness.elements.get('deliveryForm');
  harness.elements.get('companyInput').value = 'DoorDash';
  harness.elements.get('earningsInput').value = '10.00';
  harness.elements.get('milesInput').value = '2.0';
  callFirst(form, 'submit', { preventDefault() {} });

  callFirst(harness.elements.get('copySummaryBtn'), 'click', {});
  if (!harness.elements.get('toast').textContent.includes('Copy is not available')) {
    throw new Error('copy summary should not claim success when Clipboard API is unavailable');
  }
}


function setOffer(harness, { pay, miles, minutes, company = 'DoorDash', zone = 'South City', note = '' }) {
  harness.elements.get('offerPayInput').value = String(pay ?? '');
  harness.elements.get('offerMilesInput').value = String(miles ?? '');
  harness.elements.get('offerMinutesInput').value = String(minutes ?? '');
  harness.elements.get('offerCompanyInput').value = company;
  harness.elements.get('offerZoneInput').value = zone;
  harness.elements.get('offerNoteInput').value = note;
}

async function runDecisionAssistantSmoke() {
  let copiedDecision = '';
  const harness = createHarness({}, {
    navigator: { clipboard: { writeText: async (text) => { copiedDecision = text; } } }
  });
  vm.runInNewContext(appCode, harness.context, { filename: 'app.js' });

  for (const id of ['calculateOfferBtn', 'clearOfferBtn', 'copyDecisionBtn', 'saveOfferAsDeliveryBtn', 'offerNoteInput']) {
    if (!harness.elements.get(id)) throw new Error(`phase 6 element missing in smoke harness: ${id}`);
  }

  setOffer(harness, { pay: 12, miles: 4, minutes: 20, note: 'Fast restaurant' });
  callFirst(harness.elements.get('calculateOfferBtn'), 'click', {});
  let html = harness.elements.get('decisionResult').innerHTML;
  if (!html.includes('ACCEPT') || !html.includes('Gross $/mile') || !html.includes('Estimated profit') || !html.includes('Pass')) {
    throw new Error('accept calculator did not render transparent ACCEPT decision with threshold rows');
  }
  if (/NaN|Infinity|undefined|null/.test(html)) throw new Error(`accept decision rendered unsafe value: ${html}`);

  await callFirst(harness.elements.get('copyDecisionBtn'), 'click', {});
  if (!copiedDecision.includes('DriveLedger order decision: ACCEPT') || !copiedDecision.includes('Fast restaurant')) {
    throw new Error('copy decision did not include decision summary and note');
  }

  setOffer(harness, { pay: 7.5, miles: 5.2, minutes: 20 });
  callFirst(harness.elements.get('calculateOfferBtn'), 'click', {});
  html = harness.elements.get('decisionResult').innerHTML;
  if (!html.includes('BORDERLINE') || !html.includes('Fail')) {
    throw new Error('borderline calculator case did not render BORDERLINE with a failed rule');
  }
  if (/NaN|Infinity|undefined|null/.test(html)) throw new Error(`borderline decision rendered unsafe value: ${html}`);

  setOffer(harness, { pay: 5, miles: 10, minutes: 45 });
  callFirst(harness.elements.get('calculateOfferBtn'), 'click', {});
  html = harness.elements.get('decisionResult').innerHTML;
  if (!html.includes('DECLINE') || !html.includes('Too weak')) {
    throw new Error('decline calculator case did not render DECLINE with reasons');
  }
  if (/NaN|Infinity|undefined|null/.test(html)) throw new Error(`decline decision rendered unsafe value: ${html}`);

  setOffer(harness, { pay: 0, miles: 0, minutes: 0 });
  const beforeInvalid = JSON.parse(harness.storage.get('driveledger.deliveries.v1') || '[]').length;
  callFirst(harness.elements.get('saveOfferAsDeliveryBtn'), 'click', {});
  const afterInvalid = JSON.parse(harness.storage.get('driveledger.deliveries.v1') || '[]').length;
  html = harness.elements.get('decisionResult').innerHTML;
  if (afterInvalid !== beforeInvalid || !html.includes('Enter a valid offer') || !harness.elements.get('toast').textContent.includes('Enter valid pay')) {
    throw new Error('invalid offer should be rejected without saving');
  }
  if (/NaN|Infinity|undefined|null/.test(html)) throw new Error(`invalid decision rendered unsafe value: ${html}`);

  setOffer(harness, { pay: 13, miles: 4, minutes: 22, company: 'Uber Eats', zone: 'Kirkwood', note: 'Good stack' });
  callFirst(harness.elements.get('saveOfferAsDeliveryBtn'), 'click', {});
  const saved = JSON.parse(harness.storage.get('driveledger.deliveries.v1') || '[]');
  const calculatorDelivery = saved.find((d) => d.source === 'calculator' && d.company === 'Uber Eats' && d.zone === 'Kirkwood');
  if (!calculatorDelivery || calculatorDelivery.notes !== 'Good stack' || !calculatorDelivery.tags.includes('accept')) {
    throw new Error('save offer did not persist calculator source, note, zone, and decision tag');
  }
  if (harness.elements.get('offerPayInput').value || harness.elements.get('offerMilesInput').value || harness.elements.get('offerMinutesInput').value || harness.elements.get('offerNoteInput').value) {
    throw new Error('save offer should clear calculator fields after saving');
  }

  setOffer(harness, { pay: 11, miles: 3, minutes: 18 });
  callFirst(harness.elements.get('clearOfferBtn'), 'click', {});
  if (harness.elements.get('offerPayInput').value || !harness.elements.get('decisionResult').innerHTML.includes('Enter a valid offer')) {
    throw new Error('clear calculator did not reset fields and decision card');
  }

  const strictHarness = createHarness({
    'driveledger.settings.v1': JSON.stringify({ minPerMile: 5, minPerHour: 60, minPayout: 20, maxMiles: 3 })
  });
  vm.runInNewContext(appCode, strictHarness.context, { filename: 'app.js' });
  setOffer(strictHarness, { pay: 12, miles: 4, minutes: 20 });
  callFirst(strictHarness.elements.get('calculateOfferBtn'), 'click', {});
  if (!strictHarness.elements.get('decisionResult').innerHTML.includes('DECLINE')) {
    throw new Error('calculator thresholds from settings did not affect decision result');
  }

  console.log('phase 6 accept calculator cases passed');
}

async function main() {
  runStartup({
    'driveledger.deliveries.v1': '{"not":"an array"}',
    'driveledger.settings.v1': '{"dailyGoal":"bad","defaultCompany":"Unknown","gasPrice":"NaN"}',
    'driveledger.shift.v1': '{"active":true,"startedAt":"not a date"}'
  });
  runClipboardUnavailableSmoke();
  runMigrationSmoke();
  await runDecisionAssistantSmoke();
  await runOCRReviewSmoke();
  console.log('DriveLedger startup smoke test passed');
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
