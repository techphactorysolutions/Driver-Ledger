# Changelog

## 2.9.0

- Completed Phase 9 Platform and Zone Analytics.
- Added a dedicated Analytics tab with platform, zone, and hourly performance sections.
- Added Today best/worst labels for company and zone performance.
- Upgraded Today company/zone breakdowns with estimated profit, gross $/mile, profit $/mile, gross/hour, and profit/hour.
- Added aggregation helpers for platform, zone, and hour groups using the centralized Profit Engine.
- Added plain HTML/CSS performance bars without external chart libraries.
- Added empty-state handling for analytics when no saved delivery data exists.
- Expanded smoke tests for company aggregation, zone aggregation, hourly analytics, empty analytics state, and unsafe output checks.
- Expanded Python static tests for Phase 9 Analytics surfaces and helper functions.
- Bumped package version to `2.9.0`.
- Bumped PWA service worker cache to `driveledger-v13`.

## 2.8.0

- Completed Phase 8 History, Editing, Undo, and Daily Groups.
- Added explicit day metric rows to grouped History: average $/mile, gross/hour when available, and tracked time.
- Upgraded delivery history cards with a compact detail grid for miles, minutes, $/mile, and estimated profit.
- History cards now always show zone state, including `Unassigned`, plus source badges.
- Preserved edit, duplicate, delete, and undo-delete behavior and expanded smoke coverage for each flow.
- Fixed the History empty-state edge case where only deleted records existed.
- Expanded Python static tests for Phase 8 History surfaces.
- Bumped PWA service worker cache to `driveledger-v12`.

## 2.7.0

- Completed Phase 7 Centralized Profit Engine.
- Added a reusable `ProfitEngine` section in `app.js` for fuel cost per mile, maintenance cost, vehicle cost per mile, estimated delivery profit, profit $/mile, gross $/mile, gross hourly, profit hourly, mileage deduction, projected daily earnings, goal ETA, driver score, and row summaries.
- Routed dashboard, calculator, manual add preview, quick-add preview, OCR preview, history rows, day summaries, shift summaries, and CSV exports through centralized math helpers.
- Preserved compatibility wrappers such as `costPerMile()`, `deliveryProfit()`, `safeRate()`, and `hourlyRate()` so existing Phase 6 logic remains stable.
- Hardened numeric setting normalization so malformed values such as `NaN` fall back to defaults while valid zero settings remain supported.
- Added smoke checks for expected profit and mileage deduction output.
- Added Python static coverage confirming the Profit Engine exists and old scattered vehicle-cost formulas were removed.
- Bumped package version to `2.7.0`.
- Bumped PWA service worker cache to `driveledger-v11`.

## 2.6.0

- Completed Phase 6 Accept / Decline Calculator v2.
- Added optional note capture to the Decide tab.
- Added Calculate Only, Clear, Copy Decision, and Save as Completed actions.
- Added transparent decision metrics for gross $/mile, gross hourly pace, estimated profit, profit $/mile, and profit hourly pace.
- Added pass/fail threshold rows for minimum payout, minimum $/mile, minimum $/hour, max miles, and positive estimated profit.
- Hardened invalid calculator input so zero/missing pay, miles, or minutes cannot save a calculator delivery.
- Updated saved calculator deliveries to persist optional notes and decision tags.
- Added copyable decision summaries.
- Fixed missing numeric settings normalization so defaults such as gas price, maintenance, tax rate, and thresholds are preserved correctly.
- Expanded mocked smoke tests for ACCEPT, BORDERLINE, DECLINE, invalid input, save, clear, copy, and settings-driven decisions.
- Expanded Python static tests for Phase 6 DOM surfaces and helper functions.
- Bumped PWA service worker cache to `driveledger-v10`.

## 2.5.0

- Completed Phase 5 Screenshot OCR Review System.
- Rebuilt OCR as a review-first workflow so scanned screenshots never silently save deliveries.
- Added editable OCR review fields for company, earnings, miles, and minutes.
- Added detected minutes parsing and display.
- Added confidence labels: High confidence, Medium confidence, and Needs review.
- Added direct Save Reviewed action that writes deliveries with `source: "ocr"`, OCR text, and OCR confidence metadata.
- Added Use in Form, Cancel, and Clear Scan actions for OCR review.
- Added OCR save preview using estimated profit, gross $/mile, and hourly pace when minutes are present.
- Hardened Tesseract unavailable and scan-failure behavior so OCR issues do not crash the app.
- Expanded mocked smoke tests for OCR parsing, reviewed save, low-confidence no-autosave behavior, and OCR failure handling.
- Expanded Python static tests for Phase 5 OCR review surfaces and helper functions.
- Bumped PWA service worker cache to `driveledger-v9`.

## 2.4.0

- Completed Phase 4 Fast Quick-Add Flow.
- Added a prominent Today-screen Quick Add button that opens a bottom-sheet entry flow instead of switching tabs.
- Added quick-add fields for company, earnings, miles, minutes, zone, and collapsible optional notes.
- Added quick-add validation for valid company, earnings greater than 0, miles 0 or greater, and minutes 0 or greater.
- Added smart quick-add defaults from the most recent saved company/zone, with Settings fallback.
- Added Quick Add Save and Save + Add Another actions with immediate localStorage persistence, dashboard updates, and toast feedback.
- Added quick-add preview support, including safe zero-mile handling without unsafe Infinity math.
- Expanded mocked startup smoke tests for quick-add open/save/invalid-save behavior and dashboard refresh after quick save.
- Expanded Python static tests for Phase 4 bottom-sheet surfaces and helper functions.
- Bumped PWA service worker cache to `driveledger-v8`.

## 2.3.0

- Completed Phase 3 Premium Today Command Center.
- Reworked Today into dedicated Pace, Efficiency, Tax, Performance, and Last Delivery Impact cards.
- Added projected today total and explicit goal ETA metrics.
- Added best company and best zone command metrics.
- Added in-hero Start/End Day action wired to the existing shift toggle.
- Added live pace, efficiency, and performance recommendation text based on real local data.
- Added safe $/mile ranking helper to avoid unsafe Infinity math with zero-mile legacy records.
- Expanded smoke tests for Phase 3 command center rendering and hero shift wiring.
- Expanded Python static tests for Phase 3 Today screen surfaces and helper functions.
- Bumped PWA service worker cache to `driveledger-v7`.

## 2.2.0

- Completed Phase 2 data model and storage upgrade.
- Added full normalized delivery schema fields: date, note/notes, OCR text, tags, deleted flag, and current data version.
- Added long-form settings keys with backward-compatible aliases for existing UI logic.
- Added shift `lastSummary`, `shiftHistory`, and shift-history normalization.
- Added startup persistence for normalized migrated localStorage state.
- Added backup schema metadata to JSON exports.
- Improved backup import source normalization for unknown-source records.
- Expanded smoke tests for legacy data migration and shift-history persistence.
- Expanded Python static tests for Phase 2 schema and migration hooks.
- Bumped PWA service worker cache to `driveledger-v6`.

## 2.1.1

- Completed Phase 1 full audit/stabilization pass on the v2.1 baseline.
- Fixed summary copy feedback so the app no longer claims a summary was copied when the Clipboard API is unavailable.
- Expanded the mocked startup smoke test to cover unavailable Clipboard API behavior.
- Expanded Python static tests to verify service-worker cached assets exist.
- Expanded event-binding checks for Save + Add Another and Cancel Edit.
- Bumped PWA service worker cache to `driveledger-v5`.

## 2.1.0

- Added calculator zone capture.
- Added delivery source metadata normalization.
- Added OCR confidence, updatedAt, and version metadata on normalized delivery records.
- Added source labels in History.
- Added Save + Add Another for faster repeated manual entry.
- Added pre-import rollback snapshots.
- Added Restore Import Rollback control.
- Added source and OCR confidence columns to standard and tax CSV exports.
- Expanded mocked startup smoke coverage.
- Bumped PWA service worker cache to `driveledger-v4`.
