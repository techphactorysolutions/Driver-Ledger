import json
import re
import subprocess
import unittest
from html.parser import HTMLParser
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]


class AssetParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.ids = set()
        self.assets = []
        self.scripts = []
        self.classes = set()

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if 'id' in attrs:
            self.ids.add(attrs['id'])
        for class_name in attrs.get('class', '').split():
            self.classes.add(class_name)
        if tag == 'link' and attrs.get('rel') in {'stylesheet', 'manifest', 'apple-touch-icon', 'icon'}:
            href = attrs.get('href')
            if href and not href.startswith(('http://', 'https://', 'data:')):
                self.assets.append(href)
        if tag == 'script':
            src = attrs.get('src')
            if src:
                self.scripts.append(src)
                if not src.startswith(('http://', 'https://')):
                    self.assets.append(src)


class DriveLedgerStaticAppTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.html = (PROJECT_ROOT / 'index.html').read_text(encoding='utf-8')
        cls.app_js = (PROJECT_ROOT / 'app.js').read_text(encoding='utf-8')
        cls.service_worker = (PROJECT_ROOT / 'service-worker.js').read_text(encoding='utf-8')
        cls.parser = AssetParser()
        cls.parser.feed(cls.html)

    def test_required_package_files_exist(self):
        for rel in ['index.html', 'styles.css', 'app.js', 'manifest.json', 'service-worker.js', 'icons/icon-192.png', 'icons/icon-512.png']:
            self.assertTrue((PROJECT_ROOT / rel).is_file(), f'missing {rel}')

    def test_html_referenced_local_assets_exist(self):
        for rel in self.parser.assets:
            self.assertTrue((PROJECT_ROOT / rel).is_file(), f'HTML references missing asset {rel}')

    def test_manifest_is_valid_and_icon_paths_exist(self):
        manifest = json.loads((PROJECT_ROOT / 'manifest.json').read_text(encoding='utf-8'))
        self.assertEqual(manifest.get('name'), 'DriveLedger')
        self.assertEqual(manifest.get('display'), 'standalone')
        for icon in manifest.get('icons', []):
            self.assertTrue((PROJECT_ROOT / icon['src']).is_file(), f"manifest references missing icon {icon['src']}")


    def test_service_worker_cached_assets_exist(self):
        match = re.search(r'const\s+CORE_ASSETS\s*=\s*\[(.*?)\];', self.service_worker, re.S)
        self.assertIsNotNone(match, 'service worker CORE_ASSETS list not found')
        cached_assets = re.findall(r'["\']([^"\']+)["\']', match.group(1))
        self.assertIn('./index.html', cached_assets)
        self.assertIn('./styles.css', cached_assets)
        self.assertIn('./app.js', cached_assets)
        for rel in cached_assets:
            if rel == './':
                continue
            self.assertTrue((PROJECT_ROOT / rel.replace('./', '', 1)).is_file(), f'service worker references missing cached asset {rel}')

    def test_javascript_syntax_is_valid(self):
        for rel in ['app.js', 'service-worker.js']:
            result = subprocess.run(['node', '--check', rel], cwd=PROJECT_ROOT, text=True, capture_output=True)
            self.assertEqual(result.returncode, 0, result.stderr or result.stdout)

    def test_dom_ids_referenced_by_app_exist(self):
        referenced = set(re.findall(r'\$\("([A-Za-z0-9_-]+)"\)', self.app_js))
        missing = sorted(referenced - self.parser.ids)
        self.assertEqual(missing, [], f'app.js references missing DOM IDs: {missing}')
        self.assertIn('trend-card', self.parser.classes)

    def test_ui_controls_are_bound_to_real_logic(self):
        expected_bindings = [
            'deliveryForm',
            'saveSettingsBtn',
            'clearTodayBtn',
            'exportBtn',
            'exportTaxBtn',
            'backupBtn',
            'restoreRollbackBtn',
            'importInput',
            'saveAddAnotherBtn',
            'quickAddForm',
            'quickSaveAnotherBtn',
            'cancelEditBtn',
            'copySummaryBtn',
            'shiftBtn',
            'screenshotInput',
            'applyOcrBtn',
            'saveOcrBtn',
            'cancelOcrBtn',
            'clearOcrBtn',
            'calculateOfferBtn',
            'clearOfferBtn',
            'copyDecisionBtn',
            'saveOfferAsDeliveryBtn',
            'historyList',
        ]
        for element_id in expected_bindings:
            self.assertIn(element_id, self.parser.ids)
            self.assertRegex(self.app_js, rf'(\$\("{element_id}"\)|els\.{element_id})\.addEventListener')
        self.assertIn('scanScreenshot', self.app_js)
        self.assertIn('evaluateOffer', self.app_js)
        self.assertIn('exportBackup', self.app_js)
        self.assertIn('importBackup', self.app_js)
        self.assertIn('undoDelete', self.app_js)
        self.assertIn('Copy is not available in this browser', self.app_js)
        self.assertNotIn('/api/', self.app_js, 'static UI should not call missing backend API routes')

    def test_storage_is_local_and_namespaced(self):
        self.assertIn('driveledger.deliveries.v1', self.app_js)
        self.assertIn('driveledger.settings.v1', self.app_js)
        self.assertIn('driveledger.shift.v1', self.app_js)
        self.assertIn('driveledger.rollback.v1', self.app_js)
        self.assertIn('DATA_VERSION', self.app_js)
        self.assertNotRegex(self.app_js, r'indexedDB\.open\([^)]*[^a-zA-Z]')
        self.assertNotRegex(self.app_js, r'fetch\(["\']/(api|backend)')


    def test_upgraded_ui_surfaces_are_present(self):
        required_ids = {
            'profitToday', 'profitHour', 'profitMile', 'taxDeduction', 'driverScore',
            'dailySummary', 'zoneBreakdown', 'ocrReview', 'decisionResult',
            'offerPayInput', 'offerMilesInput', 'offerMinutesInput', 'offerNoteInput',
            'calculateOfferBtn', 'clearOfferBtn', 'copyDecisionBtn', 'gasPriceInput',
            'mpgInput', 'maintenanceInput', 'taxRateInput', 'minPerMileInput',
            'minPerHourInput', 'minPayoutInput', 'maxMilesInput', 'backupBtn',
            'importInput', 'exportTaxBtn', 'restoreRollbackBtn', 'saveAddAnotherBtn',
            'offerZoneInput', 'heroShiftBtn', 'heroStatusLabel', 'paceCard',
            'projectedTotal', 'goalEta', 'paceRecommendation', 'efficiencyCard',
            'avgDeliveryValue', 'taxCard', 'taxRateLabel', 'taxMiles',
            'vehicleCostToday', 'performanceCard', 'bestCompanyToday', 'worstCompanyToday',
            'bestZoneToday', 'worstZoneToday', 'performanceRecommendation', 'quickAddSheet',
            'quickAddForm', 'quickCompanyInput', 'quickEarningsInput',
            'quickMilesInput', 'quickMinutesInput', 'quickZoneInput',
            'quickNotesDetails', 'quickNotesInput', 'quickDeliveryPreview',
            'quickSaveBtn', 'quickSaveAnotherBtn', 'quickCancelBtn',
            'quickAddOpenBtn', 'analyticsBestCompany', 'analyticsWorstCompany',
            'analyticsBestZone', 'analyticsWorstZone', 'analyticsBestHourToday',
            'analyticsWeeklyBestHour', 'analyticsCompanyBreakdown',
            'analyticsZoneBreakdown', 'analyticsHourlyBreakdown', 'ocrCompanyInput', 'ocrEarningsInput',
            'ocrMilesInput', 'ocrMinutesInput', 'ocrMinutes',
            'ocrConfidenceLabel', 'ocrSavePreview', 'saveOcrBtn',
            'cancelOcrBtn'
        }
        missing = sorted(required_ids - self.parser.ids)
        self.assertEqual(missing, [], f'upgraded UI IDs missing from index.html: {missing}')
        self.assertIn('data-tab="decide"', self.html)
        self.assertIn('Accept calculator', self.html)

    def test_phase7_profit_engine_is_centralized(self):
        self.assertIn('const ProfitEngine', self.app_js)
        for method in [
            'fuelCostPerMile', 'maintenanceCost', 'vehicleCostPerMile',
            'estimatedDeliveryProfit', 'estimatedProfitPerMile', 'grossDollarPerMile',
            'grossHourlyRate', 'profitHourlyRate', 'mileageDeduction',
            'projectedDailyEarnings', 'goalETA', 'driverScore', 'summarizeRows'
        ]:
            self.assertIn(method, self.app_js)
        self.assertIn('return ProfitEngine.summarizeRows(rows', self.app_js)
        self.assertIn('return ProfitEngine.driverScore(c, settings)', self.app_js)
        self.assertNotIn('earnings - miles * costPerMile()', self.app_js)
        self.assertNotIn('pay - miles * costPerMile()', self.app_js)
        self.assertNotIn('Number(d.miles || 0) * costPerMile()', self.app_js)

    def test_profit_tax_backup_and_decision_logic_exist(self):
        expected_functions = [
            'costPerMile', 'deliveryProfit', 'driverScore', 'evaluateOffer',
            'renderDailySummary', 'renderBreakdown', 'exportBackup', 'importBackup',
            'restoreRollback', 'sourceLabel', 'buildCSV', 'saveOfferAsDelivery', 'normalizeTags', 'normalizeShiftHistoryItem', 'persistNormalizedState',
            'renderCommandMetrics', 'projectedDailyTotal', 'buildGoalEta', 'paceRecommendation', 'efficiencyRecommendation', 'performanceRecommendation', 'setStatusClass',
            'openQuickAdd', 'closeQuickAdd', 'setQuickAddDefaults', 'renderQuickAddPreview', 'saveQuickDelivery', 'readQuickNumber',
            'buildOfferThresholds', 'makeThreshold', 'buildDecisionSummaryText', 'copyDecisionSummary', 'clearOfferCalculator',
            'fuelCostPerMile', 'maintenanceCost', 'vehicleCostPerMile', 'estimatedDeliveryProfit',
            'estimatedProfitPerMile', 'grossDollarPerMile', 'grossHourlyRate', 'profitHourlyRate',
            'mileageDeduction', 'projectedDailyEarnings', 'goalETA'
        ]
        for name in expected_functions:
            self.assertRegex(self.app_js, rf'function\s+{name}\s*\(')
        for metadata_key in ['date', 'source', 'ocrText', 'ocrConfidence', 'tags', 'deleted', 'createdAt', 'updatedAt', 'version']:
            self.assertIn(metadata_key, self.app_js)
        for setting_key in ['gasPrice', 'vehicleMpg', 'maintenanceCostPerMile', 'mileageDeductionRate', 'minimumDollarPerMile', 'minimumDollarPerHour', 'appDataVersion']:
            self.assertIn(setting_key, self.app_js)
        for compatibility_key in ['mpg', 'maintenancePerMile', 'taxMileageRate', 'minPerMile', 'minPerHour']:
            self.assertIn(compatibility_key, self.app_js)
        self.assertIn('const ProfitEngine', self.app_js)
        self.assertIn('summarizeRows(rows', self.app_js)
        self.assertIn('vehicleCostPerMile(config = settings)', self.app_js)


    def test_phase2_storage_schema_and_migration_hooks_exist(self):
        self.assertIn('const DATA_VERSION = 4', self.app_js)
        self.assertIn('const BACKUP_VERSION = 4', self.app_js)
        required_delivery_fields = [
            'date:', 'note:', 'notes,', 'tags:', 'deleted:', 'ocrText:', 'ocrConfidence:'
        ]
        for field in required_delivery_fields:
            self.assertIn(field, self.app_js)
        required_shift_fields = ['lastSummary', 'shiftHistory', 'normalizeShiftHistoryItem']
        for field in required_shift_fields:
            self.assertIn(field, self.app_js)
        self.assertIn('raw.vehicleMpg ?? raw.mpg', self.app_js)
        self.assertIn('raw.maintenanceCostPerMile ?? raw.maintenancePerMile', self.app_js)
        self.assertIn('raw.mileageDeductionRate ?? raw.taxMileageRate', self.app_js)
        self.assertIn('raw.minimumDollarPerMile ?? raw.minPerMile', self.app_js)
        self.assertIn('persistNormalizedState();', self.app_js)
        self.assertIn('schema:', self.app_js)

    def test_phase3_command_center_surfaces_are_present(self):
        required_today_labels = [
            'Pace', 'Projected today', 'Goal ETA', 'Efficiency', 'Avg delivery',
            'Tax estimate', 'Mileage deduction', 'Vehicle cost',
            'Performance', 'Best company', 'Best zone', 'Last delivery impact'
        ]
        for label in required_today_labels:
            self.assertIn(label, self.html)
        for token in ['status-good', 'status-warning', 'status-danger', 'status-neutral']:
            self.assertIn(token, self.app_js + self.html + (PROJECT_ROOT / 'styles.css').read_text(encoding='utf-8'))
        self.assertIn('if (els.heroShiftBtn) els.heroShiftBtn.addEventListener("click", toggleShift);', self.app_js)
        self.assertIn('grossPerMile', self.app_js)

    def test_phase4_quick_add_bottom_sheet_surfaces_are_present(self):
        required_labels = [
            'Quick Add Delivery', 'One-hand entry', 'Save + Add Another', 'Add note'
        ]
        for label in required_labels:
            self.assertIn(label, self.html)
        self.assertIn('data-quick-add-open', self.html)
        self.assertIn('data-quick-add-cancel', self.html)
        self.assertIn('quick-add-sheet', self.html)
        self.assertIn('sheet-panel', self.html)
        self.assertIn('quick-field-grid', self.html)
        self.assertIn('miles === 0', self.app_js)
        self.assertIn('quickDefaultCompany', self.app_js)
        self.assertIn('quickDefaultZone', self.app_js)
        self.assertIn('document.querySelectorAll("[data-quick-add-open]")', self.app_js)
        self.assertIn('els.quickAddForm.addEventListener("submit", saveQuickDelivery)', self.app_js)
        self.assertIn('els.quickSaveAnotherBtn.addEventListener("click"', self.app_js)


    def test_phase5_ocr_review_system_surfaces_are_present(self):
        required_labels = [
            'Review before saving', 'Save Reviewed', 'Use in Form',
            'Clear Scan', 'View scanned text', 'High confidence',
            'Medium confidence', 'Needs review'
        ]
        combined = self.html + self.app_js
        for label in required_labels:
            self.assertIn(label, combined)
        required_functions = [
            'scanScreenshot', 'setScanState', 'confidenceLabel', 'renderOCRReview',
            'renderOCRSavePreview', 'readOCRReviewFields', 'saveReviewedOCR',
            'parseOCR', 'detectPlatform', 'detectEarnings', 'detectMiles', 'detectMinutes'
        ]
        for name in required_functions:
            self.assertRegex(self.app_js, rf'function\s+{name}\s*\(')
        self.assertIn('source: "ocr"', self.app_js)
        self.assertIn('Tesseract.recognize', self.app_js)
        self.assertIn('OCR library is not loaded yet', self.app_js)
        self.assertIn('Could not scan this screenshot', self.app_js)
        self.assertIn('low-confidence OCR should not autosave', (PROJECT_ROOT / 'tools/smoke-startup.js').read_text(encoding='utf-8'))
        self.assertIn('reviewed OCR delivery was not normalized with OCR metadata', (PROJECT_ROOT / 'tools/smoke-startup.js').read_text(encoding='utf-8'))


    def test_phase6_decision_assistant_surfaces_are_present(self):
        combined = self.html + self.app_js + (PROJECT_ROOT / 'styles.css').read_text(encoding='utf-8')
        required_labels = [
            'Calculate Only', 'Copy Decision', 'Save as Completed', 'Note optional',
            'Gross $/mile', 'Gross hourly pace', 'Estimated profit',
            'Minimum payout', 'Maximum distance'
        ]
        for label in required_labels:
            self.assertIn(label, combined)
        required_functions = [
            'evaluateOffer', 'buildOfferThresholds', 'buildDecisionSummaryText',
            'copyDecisionSummary', 'clearOfferCalculator', 'safeRate', 'hourlyRate'
        ]
        for name in required_functions:
            self.assertRegex(self.app_js, rf'function\s+{name}\s*\(')
        self.assertIn('source: "calculator"', self.app_js)
        self.assertIn('threshold-row', combined)
        self.assertIn('Estimated profit is', self.app_js)
        self.assertIn('Enter valid pay, miles, and minutes before saving', self.app_js)
        self.assertIn('phase 6 accept calculator cases passed', (PROJECT_ROOT / 'tools/smoke-startup.js').read_text(encoding='utf-8'))



    def test_phase8_history_editing_and_daily_groups_exist(self):
        combined = self.html + self.app_js + (PROJECT_ROOT / 'styles.css').read_text(encoding='utf-8')
        for token in [
            'renderHistoryDay', 'data-history-day', 'day-metrics', 'history-detail-grid',
            'avg $/mile', 'gross/hour', 'tracked time', 'data-edit', 'data-duplicate',
            'data-delete', 'undoDelete', 'Delivery duplicated for today', 'Delivery deleted.'
        ]:
            self.assertIn(token, combined)
        self.assertRegex(self.app_js, r'function\s+editDelivery\s*\(')
        self.assertRegex(self.app_js, r'function\s+duplicateDelivery\s*\(')
        self.assertRegex(self.app_js, r'function\s+deleteDelivery\s*\(')
        self.assertIn('new Date().toISOString()', self.app_js)
        self.assertIn('history should render grouped day summaries', (PROJECT_ROOT / 'tools/smoke-startup.js').read_text(encoding='utf-8'))
        self.assertIn('undo delete did not restore', (PROJECT_ROOT / 'tools/smoke-startup.js').read_text(encoding='utf-8'))

    def test_phase9_platform_zone_and_hour_analytics_exist(self):
        combined = self.html + self.app_js + (PROJECT_ROOT / 'styles.css').read_text(encoding='utf-8')
        required_labels = [
            'Analytics', 'Platform performance', 'Zone performance', 'Earnings by hour',
            'Best company today', 'Worst company today', 'Best zone today',
            'Worst zone today', 'Best hour today', 'Best saved hour'
        ]
        for label in required_labels:
            self.assertIn(label, combined)
        required_ids = {
            'tab-analytics', 'analyticsBestCompany', 'analyticsWorstCompany',
            'analyticsBestZone', 'analyticsWorstZone', 'analyticsBestHourToday',
            'analyticsWeeklyBestHour', 'analyticsCompanyBreakdown',
            'analyticsZoneBreakdown', 'analyticsHourlyBreakdown',
            'worstCompanyToday', 'worstZoneToday'
        }
        self.assertEqual(sorted(required_ids - self.parser.ids), [])
        required_functions = [
            'activeDeliveries', 'aggregateGroups', 'rankedGroups', 'bestGroup',
            'worstGroup', 'renderAnalytics', 'renderAnalyticsList',
            'deliveriesWithinDays', 'rankedHourGroups', 'hourRangeLabel'
        ]
        for name in required_functions:
            self.assertRegex(self.app_js, rf'function\s+{name}\s*\(')
        self.assertIn('data-tab="analytics"', self.html)
        self.assertIn('analytics-bar', combined)
        smoke = (PROJECT_ROOT / 'tools/smoke-startup.js').read_text(encoding='utf-8')
        self.assertIn('platform analytics should aggregate multiple saved companies', smoke)
        self.assertIn('zone analytics should aggregate multiple saved zones', smoke)
        self.assertIn('hourly analytics should render real saved delivery hour metrics', smoke)
        self.assertIn('runAnalyticsEmptySmoke', smoke)


    def test_startup_smoke_test_with_mock_browser(self):
        result = subprocess.run(['node', 'tools/smoke-startup.js'], cwd=PROJECT_ROOT, text=True, capture_output=True)
        self.assertEqual(result.returncode, 0, result.stderr or result.stdout)
        self.assertIn('passed', result.stdout)


if __name__ == '__main__':
    unittest.main()
